# You have successfully created the organization instance of IAM Identity Center 72234066cab10990.

### Settings summary

Go to settings
Specify a unique name for your instance.
Organizational structure
Account created/joined date
Root -r-u1lv
#### management account: thinkbuntu
REDACTED_AWS_ACCOUNT_ID
  |  
#### thinkbuntu@gmail.com
Instance name
 - Edit
Identity source
Identity Center directory

#### Primary Region: us-east-1
#### Organization ID: o-i8gb04nwxn

Issuer URL (for OIDC applications and clients)
#### https://identitycenter.amazonaws.com/ssoins-72234066cab10990
AWS access portal URLs
Dual-stack
#### https://ssoins-72234066cab10990.portal.us-east-1.app.aws 
IPv4-only - Edit
#### https://d-90660d018c.awsapps.com/start 


##### Default AWS access portal URL (IPv4 only): https://d-90660d018c.awsapps.com/start
##### Dual-stack AWS access portal URL: https://ssoins-72234066cab10990.portal.us-east-1.app.aws
##### Username: hrishvaderidenty
##### One-time password: REDACTED_SECRET#rWE?K.I&F3Nim!X.NNob0qZ@nANzqPn53QIE2^inM>9#B




Default AWS access portal URL (IPv4 only): https://d-90660d018c.awsapps.com/start
Dual-stack AWS access portal URL: https://ssoins-72234066cab10990.portal.us-east-1.app.aws
Username: sivanairidentity
One-time password: REDACTED_SECRET#x2#LjV1M^nhc?1-Ji.>R1OHV#/&19%QXgSL_*