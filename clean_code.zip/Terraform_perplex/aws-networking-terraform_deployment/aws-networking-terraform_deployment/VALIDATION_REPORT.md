# Terraform Validation Report

**Provider:** hashicorp/aws ~> 5.70  
**Terraform:** 1.9.8  
**Date:** 2025-07-15  
**Result:** All 22 modules pass `terraform validate`

---

## Summary

| Module | Status | Notes |
|--------|--------|-------|
| client-vpn | FIXED | See details below |
| cloud-wan | FIXED | See details below |
| direct-connect | FIXED | See details below |
| network-security | FIXED | See details below |
| site-to-site-vpn | FIXED | See details below |
| vpc-additional-features | FIXED | See details below |
| vpc-lattice | FIXED | See details below |
| vpc-network-performance | FIXED | See details below |
| cloudfront | PASS | No changes needed |
| eks-networking | PASS | No changes needed |
| elastic-load-balancing | PASS | No changes needed |
| gateway-load-balancer | PASS | No changes needed |
| hybrid-networks | PASS | No changes needed |
| management-governance | PASS | No changes needed |
| route53 | PASS | No changes needed |
| transit-gateway | PASS | No changes needed |
| vpc-dns-dhcp | PASS | No changes needed |
| vpc-fundamentals | PASS | No changes needed |
| vpc-gateway-endpoints | PASS | No changes needed |
| vpc-interface-endpoints-privatelink | PASS | No changes needed |
| vpc-peering | PASS | No changes needed |
| vpc-traffic-mirroring | PASS | No changes needed |

---

## Fix Details

### modules/client-vpn — FIXED

**Error:** `authentication_options` dynamic block referenced `directory_id`, which is not a valid argument in the AWS provider. The correct argument name is `active_directory_id`.

**Changes:**
- `main.tf`: Renamed `directory_id = authentication_options.value.directory_id` → `active_directory_id = authentication_options.value.active_directory_id`
- `variables.tf`: Renamed `directory_id` field to `active_directory_id` in the `authentication_options` object type, and updated the description accordingly.

---

### modules/cloud-wan — FIXED

**Error:** `aws_networkmanager_core_network` does not accept `policy_document` as an inline argument in AWS provider ≥ 5.x. Policy must be applied via a separate attachment resource.

**Changes:**
- `main.tf`: Removed `policy_document` argument and `ignore_changes = [policy_document]` lifecycle block from `aws_networkmanager_core_network.this`.
- `main.tf`: Added new `aws_networkmanager_core_network_policy_attachment` resource that references `aws_networkmanager_core_network.this.id` and supplies `local.core_policy` as the policy document.

---

### modules/direct-connect — FIXED

**Two errors:**

**(a)** `aws_dx_lag` does not accept a `minimum_links` argument in the current AWS provider (minimum link count is managed out-of-band).

**Changes:**
- `main.tf`: Removed `minimum_links = var.lag_minimum_links` from `aws_dx_lag.this`.
- `variables.tf`: Removed the `lag_minimum_links` variable declaration entirely.

**(b)** `aws_dx_public_virtual_interface` requires `route_filter_prefixes` as a top-level `list(string)` argument, not a `dynamic` nested block.

**Changes:**
- `main.tf`: Replaced the `dynamic "route_filter_prefixes" { for_each = ...; content { cidr = ... } }` block with the direct assignment `route_filter_prefixes = var.public_vif_route_filter_prefixes`.
- `variables.tf`: Changed the `public_vif_route_filter_prefixes` default from `[]` to `["0.0.0.0/0"]` to provide a sensible default.

---

### modules/network-security — FIXED

**Error:** Inside `aws_networkfirewall_rule_group` "stateless", the `match_attributes` block does not support a nested `protocols` block. `protocols` is a top-level `list(number)` argument within `match_attributes`.

**Changes:**
- `main.tf`: Replaced `dynamic "protocols" { for_each = stateless_rule.value.protocols; content { protocol_number = protocols.value } }` with the direct assignment `protocols = stateless_rule.value.protocols`.
- `variables.tf`: No change required — `protocols` was already typed as `optional(list(number), [])`.

---

### modules/site-to-site-vpn — FIXED

**Error:** `aws_vpn_connection` does not accept dynamic blocks for tunnel phase configuration. Arguments like `tunnel1_phase1_dh_group_numbers`, `tunnel1_phase1_encryption_algorithms`, etc., are top-level `list(number)` or `list(string)` arguments, not repeatable nested blocks.

**Changes:**
- `main.tf`: Replaced all 12 dynamic blocks (6 for tunnel1, 6 for tunnel2) with direct top-level argument assignments:
  - `tunnel1_phase1_dh_group_numbers = ...`
  - `tunnel1_phase1_encryption_algorithms = ...`
  - `tunnel1_phase1_integrity_algorithms = ...`
  - `tunnel1_phase2_dh_group_numbers = ...`
  - `tunnel1_phase2_encryption_algorithms = ...`
  - `tunnel1_phase2_integrity_algorithms = ...`
  - (same pattern for `tunnel2_*`)
  
  Each uses a conditional expression returning `null` when the option is not set, allowing users to omit them safely.

---

### modules/vpc-additional-features — FIXED

**Error:** `aws_ec2_network_insights_access_scope` does not exist in the AWS Terraform provider. Only `aws_ec2_network_insights_path` (Reachability Analyzer) is supported; Network Access Analyzer scope creation is not yet available via the provider.

**Changes:**
- `main.tf`: Removed the entire `aws_ec2_network_insights_access_scope` resource block. Added a comment noting the limitation.
- `variables.tf`: Removed the `enable_network_access_scope` variable (no longer referenced).
- `outputs.tf`: Removed `network_access_scope_id` and `network_access_scope_arn` outputs that referenced the removed resource. Added a comment noting the outputs were removed.

---

### modules/vpc-lattice — FIXED

**Two errors (discovered during validation):**

**(a)** `aws_vpclattice_service` does not support a nested `certificate` block. The TLS certificate ARN is a top-level argument `certificate_arn`.

**Changes:**
- `main.tf`: Replaced `dynamic "certificate" { for_each = ...; content { certificate_arn = ... } }` with `certificate_arn = each.value.certificate_arn != "" ? each.value.certificate_arn : null`.

**(b)** The `health_check` block inside `aws_vpclattice_target_group` config does not support `interval_seconds` or `timeout_seconds`.

**Changes:**
- `main.tf`: Removed `interval_seconds = 30` and `timeout_seconds = 5` from the `health_check` block.

---

### modules/vpc-network-performance — FIXED

**Error (discovered during validation):** `aws_instance` does not accept an `ena_support` argument. ENA support is determined by the AMI and instance type automatically.

**Changes:**
- `main.tf`: Removed `ena_support = true` from `aws_instance.ena_demo`. Added a comment explaining ENA support is implicit.

---

## Post-Fix Actions

- `terraform fmt -recursive` applied to all modules.
- All `.terraform/` directories removed from modules.
- All `.terraform.lock.hcl` files removed from modules.
