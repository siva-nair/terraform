# AWS Advanced Networking — Terraform Modules & Diagrams

Production-quality Terraform modules and draw.io architecture diagrams covering every topic in the **AWS Certified Advanced Networking — Specialty** course. Designed for hands-on study, lab building, and as reusable building blocks for real workloads.

- **Terraform:** `>= 1.9.0`
- **AWS Provider:** `hashicorp/aws ~> 5.70`
- **22 modules** under `modules/`
- **22 architecture diagrams** under `diagrams/` (draw.io / diagrams.net XML)

## Module Index

| # | Module | What it builds |
|---|---|---|
| 1 | [`vpc-fundamentals`](modules/vpc-fundamentals) | VPC with IPv4/IPv6, multi-AZ public/private subnets, IGW, NAT GW(s), route tables |
| 2 | [`vpc-additional-features`](modules/vpc-additional-features) | Secondary CIDRs, Flow Logs (CWL + S3), Reachability Analyzer paths |
| 3 | [`vpc-dns-dhcp`](modules/vpc-dns-dhcp) | Custom DHCP options, Route 53 Resolver inbound/outbound endpoints, resolver rules |
| 4 | [`vpc-network-performance`](modules/vpc-network-performance) | Cluster/Spread/Partition placement groups, ENA + jumbo-frame instances |
| 5 | [`vpc-traffic-mirroring`](modules/vpc-traffic-mirroring) | Mirror target/filter/session for packet capture |
| 6 | [`vpc-peering`](modules/vpc-peering) | Same/cross-account/cross-region peering with bidirectional routes |
| 7 | [`vpc-gateway-endpoints`](modules/vpc-gateway-endpoints) | Gateway endpoints for S3 + DynamoDB |
| 8 | [`vpc-interface-endpoints-privatelink`](modules/vpc-interface-endpoints-privatelink) | Interface endpoints + PrivateLink service publishing |
| 9 | [`transit-gateway`](modules/transit-gateway) | TGW hub, attachments, route tables, RAM sharing |
| 10 | [`hybrid-networks`](modules/hybrid-networks) | CGW, VGW, DX Gateway umbrella for hybrid connectivity |
| 11 | [`site-to-site-vpn`](modules/site-to-site-vpn) | S2S VPN to VGW or TGW with full IKE/IPsec parameters |
| 12 | [`client-vpn`](modules/client-vpn) | Client VPN with mutual cert / AD / SAML auth |
| 13 | [`direct-connect`](modules/direct-connect) | DX connections, LAG, private/public/transit VIFs, MACsec |
| 14 | [`cloudfront`](modules/cloudfront) | CloudFront distribution, OAC, signed URLs, WAF, Functions |
| 15 | [`elastic-load-balancing`](modules/elastic-load-balancing) | ALB / NLB / CLB via single switch variable |
| 16 | [`route53`](modules/route53) | Hosted zones, all 7 routing policies, health checks, DNSSEC |
| 17 | [`network-security`](modules/network-security) | NACLs, SGs, Network Firewall, WAFv2, Shield Advanced |
| 18 | [`gateway-load-balancer`](modules/gateway-load-balancer) | GWLB + GWLBe inspection pattern |
| 19 | [`eks-networking`](modules/eks-networking) | EKS cluster, VPC CNI, node group, OIDC/IRSA, Pod Identity |
| 20 | [`management-governance`](modules/management-governance) | Network Manager, Config rules, CloudTrail, CW logs |
| 21 | [`cloud-wan`](modules/cloud-wan) | Cloud WAN core network with multi-segment policy |
| 22 | [`vpc-lattice`](modules/vpc-lattice) | VPC Lattice service network, services, listeners, auth |

## Repository Layout

```
aws-networking-terraform/
├── README.md                          ← you are here
├── modules/
│   └── <topic>/
│       ├── versions.tf                ← TF + provider pins
│       ├── variables.tf               ← typed inputs with descriptions
│       ├── main.tf                    ← AWS resources
│       ├── outputs.tf                 ← IDs, ARNs, endpoints
│       └── README.md                  ← inputs/outputs/usage/concepts
└── diagrams/
    ├── 01-vpc-fundamentals.drawio
    ├── …
    ├── 22-vpc-lattice.drawio
    └── _build_diagrams.py             ← regenerate diagrams from spec
```

## Using a Module

Each module is self-contained and consumed via `module "x" { source = "./modules/<topic>" … }`.

```hcl
provider "aws" {
  region = "us-east-1"
}

module "core_vpc" {
  source = "./modules/vpc-fundamentals"

  name                = "lab-vpc"
  cidr_block          = "10.0.0.0/16"
  enable_ipv6         = true
  az_count            = 2
  single_nat_gateway  = false

  tags = {
    Project = "aws-networking-study"
    Owner   = "ideawaves"
  }
}

module "tgw" {
  source = "./modules/transit-gateway"

  name = "lab-tgw"
  vpc_attachments = {
    core = {
      vpc_id     = module.core_vpc.vpc_id
      subnet_ids = module.core_vpc.private_subnet_ids
    }
  }
}
```

See each module's README for its full input/output reference and a complete usage example.

## Opening the Diagrams

The 22 `.drawio` files are valid diagrams.net XML and can be opened in three ways:

1. **Web:** go to <https://app.diagrams.net> and drag-drop a `.drawio` file onto the canvas, or use `File → Open from → Device…`.
2. **Desktop app:** open the file directly in [draw.io Desktop](https://github.com/jgraph/drawio-desktop/releases).
3. **VS Code:** install the [Draw.io Integration](https://marketplace.visualstudio.com/items?itemName=hediet.vscode-drawio) extension and open the file.

If AWS shapes render as plain rectangles, enable the AWS shape library: in the left sidebar click **`+ More Shapes…`**, scroll to **Networking**, tick **AWS19** / **AWS21**, click **Apply**.

To regenerate all diagrams from the Python spec:

```bash
python3 diagrams/_build_diagrams.py
```

## Validation

All 22 modules have been validated with `terraform validate` against `hashicorp/aws ~> 5.70`. To re-validate locally:

```bash
for d in modules/*/; do
  ( cd "$d" && terraform init -backend=false -input=false -upgrade && terraform validate )
done
```

## Notes & Caveats

- **No backend is configured.** Add an `s3` / `remote` backend in your root module before running these in production.
- **Costs:** several modules provision real billable infrastructure (NAT GWs, TGW, GWLB, DX, Client VPN, EKS, CloudFront). Review each `main.tf` before `terraform apply`.
- **Defaults are lab-friendly, not enterprise-hardened.** Tighten security groups, NACLs, IAM, and encryption settings for production.
- **Cross-account / cross-region** flows in `vpc-peering`, `direct-connect`, `transit-gateway`, and `cloud-wan` require provider aliases — see each module's README for the recommended pattern.

## Source Material

These modules were built to match the topic structure of the *Ultimate AWS Certified Advanced Networking Specialty* course slides (1,300 pages). Topics map 1:1 to the course Table of Contents.

## License

Personal study / lab use. The Terraform code is yours to use, modify, and redistribute. The AWS Networking Specialty course slides themselves are copyrighted by their authors and are NOT redistributed in this repository.
