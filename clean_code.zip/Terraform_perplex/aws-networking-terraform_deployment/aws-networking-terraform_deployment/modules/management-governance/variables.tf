variable "name" {
  description = "Name prefix for all management and governance resources."
  type        = string
}

# ---------------------------------------------------------------------------
# Network Manager
# ---------------------------------------------------------------------------
variable "create_network_manager" {
  description = "Whether to create a Network Manager global network."
  type        = bool
  default     = true
}

variable "network_manager_description" {
  description = "Description for the Network Manager global network."
  type        = string
  default     = "Managed by Terraform"
}

variable "sites" {
  description = "Map of Network Manager sites."
  type = map(object({
    description = optional(string, "")
    address     = optional(string, "")
    latitude    = optional(string, "")
    longitude   = optional(string, "")
  }))
  default = {}
}

variable "devices" {
  description = "Map of Network Manager devices. Key must match a site key."
  type = map(object({
    site_key    = string
    description = optional(string, "")
    model       = optional(string, "")
    vendor      = optional(string, "")
  }))
  default = {}
}

variable "transit_gateway_arns" {
  description = "List of Transit Gateway ARNs to register in the global network."
  type        = list(string)
  default     = []
}

# ---------------------------------------------------------------------------
# AWS Config
# ---------------------------------------------------------------------------
variable "create_config" {
  description = "Whether to create AWS Config recorder and delivery channel."
  type        = bool
  default     = true
}

variable "config_s3_bucket_name" {
  description = "S3 bucket name for AWS Config delivery. Required when create_config = true."
  type        = string
  default     = ""
}

variable "config_include_global_resource_types" {
  description = "Whether to record global resource types (IAM, etc.) in AWS Config."
  type        = bool
  default     = true
}

variable "config_rules" {
  description = "Map of AWS Config managed rules to create. Key is a logical name."
  type = map(object({
    source_identifier = string
    description       = optional(string, "")
    input_parameters  = optional(string, "{}")
    scope_types       = optional(list(string), [])
  }))
  default = {
    vpc-default-security-group-closed = {
      source_identifier = "VPC_DEFAULT_SECURITY_GROUP_CLOSED"
      description       = "Checks that the default security group of any VPC does not allow inbound or outbound traffic."
    }
    restricted-ssh = {
      source_identifier = "RESTRICTED_INCOMING_TRAFFIC"
      description       = "Checks if security groups allow unrestricted SSH access."
      input_parameters  = "{\"blockedPort1\":\"22\"}"
    }
    vpc-flow-logs-enabled = {
      source_identifier = "VPC_FLOW_LOGS_ENABLED"
      description       = "Checks if VPC Flow Logs are enabled."
    }
  }
}

# ---------------------------------------------------------------------------
# CloudTrail
# ---------------------------------------------------------------------------
variable "create_cloudtrail" {
  description = "Whether to create a CloudTrail trail."
  type        = bool
  default     = true
}

variable "cloudtrail_s3_bucket_name" {
  description = "S3 bucket name for CloudTrail logs."
  type        = string
  default     = ""
}

variable "cloudtrail_include_global_service_events" {
  description = "Whether to include global service events (IAM, STS, etc.) in CloudTrail."
  type        = bool
  default     = true
}

variable "cloudtrail_is_multi_region" {
  description = "Whether the trail applies to all regions."
  type        = bool
  default     = true
}

variable "cloudtrail_enable_log_file_validation" {
  description = "Whether to enable log file integrity validation."
  type        = bool
  default     = true
}

# ---------------------------------------------------------------------------
# VPC Flow Logs CloudWatch Log Group
# ---------------------------------------------------------------------------
variable "create_flow_log_group" {
  description = "Whether to create a CloudWatch Log Group for VPC flow logs."
  type        = bool
  default     = true
}

variable "flow_log_retention_days" {
  description = "Retention period in days for the VPC flow logs log group."
  type        = number
  default     = 90
}

# ---------------------------------------------------------------------------
# Organizations SCP
# ---------------------------------------------------------------------------
variable "create_scp" {
  description = "Whether to create an Organizations Service Control Policy."
  type        = bool
  default     = false
}

variable "scp_name" {
  description = "Name of the Service Control Policy."
  type        = string
  default     = "networking-guardrails"
}

variable "scp_content" {
  description = "JSON content of the SCP policy document."
  type        = string
  default     = ""
}

variable "tags" {
  description = "Map of tags to apply to all resources."
  type        = map(string)
  default     = {}
}
