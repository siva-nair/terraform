data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  common_tags = merge(
    {
      Name      = var.name
      ManagedBy = "terraform"
    },
    var.tags
  )
}

# ---------------------------------------------------------------------------
# Network Manager — Global Network
# ---------------------------------------------------------------------------
resource "aws_networkmanager_global_network" "this" {
  count = var.create_network_manager ? 1 : 0

  description = var.network_manager_description

  tags = merge(local.common_tags, { Name = "${var.name}-global-network" })
}

# ---------------------------------------------------------------------------
# Network Manager — Sites
# ---------------------------------------------------------------------------
resource "aws_networkmanager_site" "this" {
  for_each = var.create_network_manager ? var.sites : {}

  global_network_id = aws_networkmanager_global_network.this[0].id
  description       = each.value.description

  dynamic "location" {
    for_each = each.value.address != "" ? [1] : []
    content {
      address   = each.value.address
      latitude  = each.value.latitude
      longitude = each.value.longitude
    }
  }

  tags = merge(local.common_tags, { Name = "${var.name}-site-${each.key}" })
}

# ---------------------------------------------------------------------------
# Network Manager — Devices
# ---------------------------------------------------------------------------
resource "aws_networkmanager_device" "this" {
  for_each = var.create_network_manager ? var.devices : {}

  global_network_id = aws_networkmanager_global_network.this[0].id
  site_id           = aws_networkmanager_site.this[each.value.site_key].id
  description       = each.value.description
  model             = each.value.model
  vendor            = each.value.vendor

  tags = merge(local.common_tags, { Name = "${var.name}-device-${each.key}" })
}

# ---------------------------------------------------------------------------
# Network Manager — Transit Gateway Registrations
# ---------------------------------------------------------------------------
resource "aws_networkmanager_transit_gateway_registration" "this" {
  for_each = var.create_network_manager ? toset(var.transit_gateway_arns) : []

  global_network_id   = aws_networkmanager_global_network.this[0].id
  transit_gateway_arn = each.value
}

# ---------------------------------------------------------------------------
# IAM Role — AWS Config
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "config_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["config.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "config" {
  count = var.create_config ? 1 : 0

  name               = "${var.name}-config-role"
  assume_role_policy = data.aws_iam_policy_document.config_assume.json
  tags               = local.common_tags
}

resource "aws_iam_role_policy_attachment" "config" {
  count = var.create_config ? 1 : 0

  role       = aws_iam_role.config[0].name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/service-role/AWS_ConfigRole"
}

# ---------------------------------------------------------------------------
# AWS Config — Configuration Recorder
# ---------------------------------------------------------------------------
resource "aws_config_configuration_recorder" "this" {
  count = var.create_config ? 1 : 0

  name     = "${var.name}-recorder"
  role_arn = aws_iam_role.config[0].arn

  recording_group {
    all_supported                 = true
    include_global_resource_types = var.config_include_global_resource_types
  }
}

# ---------------------------------------------------------------------------
# AWS Config — Delivery Channel
# ---------------------------------------------------------------------------
resource "aws_config_delivery_channel" "this" {
  count = var.create_config && var.config_s3_bucket_name != "" ? 1 : 0

  name           = "${var.name}-delivery"
  s3_bucket_name = var.config_s3_bucket_name

  depends_on = [aws_config_configuration_recorder.this]
}

resource "aws_config_configuration_recorder_status" "this" {
  count = var.create_config && var.config_s3_bucket_name != "" ? 1 : 0

  name       = aws_config_configuration_recorder.this[0].name
  is_enabled = true

  depends_on = [aws_config_delivery_channel.this]
}

# ---------------------------------------------------------------------------
# AWS Config Rules (VPC/SG compliance)
# ---------------------------------------------------------------------------
resource "aws_config_config_rule" "this" {
  for_each = var.create_config ? var.config_rules : {}

  name        = "${var.name}-${each.key}"
  description = each.value.description

  source {
    owner             = "AWS"
    source_identifier = each.value.source_identifier
  }

  dynamic "scope" {
    for_each = length(each.value.scope_types) > 0 ? [1] : []
    content {
      compliance_resource_types = each.value.scope_types
    }
  }

  input_parameters = each.value.input_parameters != "{}" ? each.value.input_parameters : null

  depends_on = [aws_config_configuration_recorder_status.this]
}

# ---------------------------------------------------------------------------
# CloudTrail
# ---------------------------------------------------------------------------
resource "aws_cloudtrail" "this" {
  count = var.create_cloudtrail && var.cloudtrail_s3_bucket_name != "" ? 1 : 0

  name                          = "${var.name}-trail"
  s3_bucket_name                = var.cloudtrail_s3_bucket_name
  include_global_service_events = var.cloudtrail_include_global_service_events
  is_multi_region_trail         = var.cloudtrail_is_multi_region
  enable_log_file_validation    = var.cloudtrail_enable_log_file_validation

  event_selector {
    read_write_type           = "All"
    include_management_events = true
  }

  tags = merge(local.common_tags, { Name = "${var.name}-trail" })
}

# ---------------------------------------------------------------------------
# CloudWatch Log Group — VPC Flow Logs
# ---------------------------------------------------------------------------
resource "aws_cloudwatch_log_group" "flow_logs" {
  count = var.create_flow_log_group ? 1 : 0

  name              = "/aws/vpc/flow-logs/${var.name}"
  retention_in_days = var.flow_log_retention_days

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Organizations SCP (optional)
# ---------------------------------------------------------------------------
resource "aws_organizations_policy" "networking" {
  count = var.create_scp && var.scp_content != "" ? 1 : 0

  name        = var.scp_name
  description = "Networking guardrails SCP managed by Terraform"
  content     = var.scp_content
  type        = "SERVICE_CONTROL_POLICY"

  tags = local.common_tags
}
