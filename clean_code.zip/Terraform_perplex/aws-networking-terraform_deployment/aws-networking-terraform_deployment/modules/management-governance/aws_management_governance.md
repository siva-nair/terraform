# AWS Management & Governance

## Overview
In AWS, **Management & Governance** is a category of services that help you **control, monitor, audit, and manage** your cloud environment at scale.

It acts as the **control layer** ensuring your infrastructure is secure, compliant, and efficient.

---

## Core Functions

### 1. Account & Access Governance
Manage accounts and permissions.
- AWS Organizations
- AWS Control Tower
- IAM / IAM Identity Center

---

### 2. Monitoring & Observability
Track system performance and activity.
- Amazon CloudWatch
- AWS X-Ray
- AWS Health Dashboard

---

### 3. Audit & Compliance
Ensure compliance and track activity.
- AWS CloudTrail
- AWS Config
- AWS Audit Manager

---

### 4. Infrastructure Management & Automation
Automate deployments and operations.
- AWS CloudFormation
- AWS Systems Manager
- AWS OpsWorks

---

### 5. Cost & Usage Governance
Monitor and control spending.
- AWS Cost Explorer
- AWS Budgets
- AWS Billing Dashboard

---

### 6. Operational Governance
Maintain best practices and reliability.
- AWS Trusted Advisor
- AWS Service Catalog
- AWS Well-Architected Tool

---

## Summary
Management & Governance services help you:
- Maintain security and compliance
- Monitor system health
- Control costs
- Automate operations

---

## Analogy
If AWS were a city:
- Compute/Storage = Buildings
- Networking = Roads
- Management & Governance = City Administration
