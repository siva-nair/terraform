# management-governance

Terraform module for AWS network **management and governance** — AWS Network Manager, AWS Config (VPC/SG compliance rules), CloudTrail, CloudWatch Log Groups for VPC flow logs, and Organizations SCPs.

## Resources Created

| Resource | Description |
|---|---|
| `aws_networkmanager_global_network` | Central network inventory across regions |
| `aws_networkmanager_site` | Physical site representation (data center, branch) |
| `aws_networkmanager_device` | Network device at a site |
| `aws_networkmanager_transit_gateway_registration` | Registers TGW in the global network |
| `aws_config_configuration_recorder` | Records resource configuration changes |
| `aws_config_delivery_channel` | Delivers Config snapshots to S3 |
| `aws_config_config_rule` | Managed rules for VPC/SG compliance |
| `aws_cloudtrail` | API audit trail |
| `aws_cloudwatch_log_group` | Log group for VPC flow logs |
| `aws_organizations_policy` | Service Control Policy (optional) |

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| `name` | Resource name prefix | `string` | — | yes |
| `create_network_manager` | Create Network Manager | `bool` | `true` | no |
| `sites` | Network Manager sites map | `map(object)` | `{}` | no |
| `devices` | Network Manager devices map | `map(object)` | `{}` | no |
| `transit_gateway_arns` | TGW ARNs to register | `list(string)` | `[]` | no |
| `create_config` | Create AWS Config | `bool` | `true` | no |
| `config_s3_bucket_name` | S3 bucket for Config delivery | `string` | `""` | no |
| `config_rules` | Map of Config managed rules | `map(object)` | VPC defaults | no |
| `create_cloudtrail` | Create CloudTrail | `bool` | `true` | no |
| `cloudtrail_s3_bucket_name` | S3 bucket for CloudTrail | `string` | `""` | no |
| `create_flow_log_group` | Create CW Log Group | `bool` | `true` | no |
| `flow_log_retention_days` | Log retention (days) | `number` | `90` | no |
| `create_scp` | Create Organizations SCP | `bool` | `false` | no |
| `scp_content` | SCP JSON policy | `string` | `""` | no |
| `tags` | Tags for all resources | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|---|---|
| `global_network_id` | Network Manager global network ID |
| `global_network_arn` | Network Manager global network ARN |
| `site_ids` | Map of site name → ID |
| `device_ids` | Map of device name → ID |
| `config_recorder_name` | AWS Config recorder name |
| `config_rule_arns` | Map of rule name → ARN |
| `cloudtrail_arn` | CloudTrail trail ARN |
| `flow_log_group_name` | CW Log Group name |
| `flow_log_group_arn` | CW Log Group ARN |
| `scp_id` | SCP ID |

## Usage Example

```hcl
module "governance" {
  source = "./modules/management-governance"

  name = "corp-governance"

  # Network Manager
  create_network_manager = true
  transit_gateway_arns   = [module.transit_gateway.tgw_arn]

  sites = {
    hq = {
      description = "Headquarters"
      address     = "1 Main St, Seattle, WA"
      latitude    = "47.6062"
      longitude   = "-122.3321"
    }
  }

  # AWS Config
  create_config         = true
  config_s3_bucket_name = "my-config-bucket"

  # CloudTrail
  create_cloudtrail          = true
  cloudtrail_s3_bucket_name  = "my-cloudtrail-bucket"

  # VPC Flow Logs CW Log Group
  create_flow_log_group   = true
  flow_log_retention_days = 365

  # SCP
  create_scp  = true
  scp_content = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyVPCPeeringToUnknownAccounts"
        Effect   = "Deny"
        Action   = "ec2:CreateVpcPeeringConnection"
        Resource = "*"
        Condition = {
          StringNotEquals = {
            "ec2:AccepterVpc" = ["REDACTED_AWS_ARN"]
          }
        }
      }
    ]
  })

  tags = { Environment = "prod" }
}
```

## Concepts (Exam Prep)

- **AWS Network Manager**: Centralized network monitoring dashboard. Registers Transit Gateways to get a global view of network topology, reachability, and events. Supports on-premises devices and links for SD-WAN visibility. Route Analyzer tool traces paths through the network.
- **AWS Config**: Continuous configuration recording + compliance evaluation. Rules can be AWS managed (600+), custom Lambda-based, or conformance packs. Non-compliant resources trigger SNS notifications or remediation via SSM Automation.
- **Key VPC Config Rules**: `VPC_FLOW_LOGS_ENABLED`, `VPC_DEFAULT_SECURITY_GROUP_CLOSED`, `RESTRICTED_INCOMING_TRAFFIC` (SSH/RDP), `VPC_SG_OPEN_ONLY_TO_AUTHORIZED_PORTS`, `SUBNET_AUTO_ASSIGN_PUBLIC_IP_DISABLED`.
- **CloudTrail**: Records API calls (management events) and optionally data events (S3 object access, Lambda invocations). Critical for security forensics. Log file validation uses SHA-256 hash + RSA digital signature. For networking: captures VPC, SG, NACl, Route table changes.
- **VPC Flow Logs**: Capture IP traffic metadata (not payload) at VPC, subnet, or ENI level. Publish to CloudWatch Logs, S3, or Kinesis Firehose. Used for security analysis, troubleshooting, and compliance.
- **Organizations SCPs**: JSON policies attached to OUs or accounts. Act as permission guardrails — they cannot grant permissions, only restrict what IAM policies can allow. Use `Deny` statements for hard restrictions like preventing VPC deletion or requiring flow logs on all VPCs.
