output "global_network_id" {
  description = "ID of the Network Manager global network."
  value       = var.create_network_manager ? aws_networkmanager_global_network.this[0].id : null
}

output "global_network_arn" {
  description = "ARN of the Network Manager global network."
  value       = var.create_network_manager ? aws_networkmanager_global_network.this[0].arn : null
}

output "site_ids" {
  description = "Map of site logical name to Network Manager site ID."
  value = {
    for k, v in aws_networkmanager_site.this : k => v.id
  }
}

output "device_ids" {
  description = "Map of device logical name to Network Manager device ID."
  value = {
    for k, v in aws_networkmanager_device.this : k => v.id
  }
}

output "config_recorder_name" {
  description = "Name of the AWS Config configuration recorder."
  value       = var.create_config ? aws_config_configuration_recorder.this[0].name : null
}

output "config_rule_arns" {
  description = "Map of Config rule logical name to ARN."
  value = {
    for k, v in aws_config_config_rule.this : k => v.arn
  }
}

output "cloudtrail_arn" {
  description = "ARN of the CloudTrail trail."
  value       = var.create_cloudtrail && var.cloudtrail_s3_bucket_name != "" ? aws_cloudtrail.this[0].arn : null
}

output "flow_log_group_name" {
  description = "Name of the CloudWatch Log Group for VPC flow logs."
  value       = var.create_flow_log_group ? aws_cloudwatch_log_group.flow_logs[0].name : null
}

output "flow_log_group_arn" {
  description = "ARN of the CloudWatch Log Group for VPC flow logs."
  value       = var.create_flow_log_group ? aws_cloudwatch_log_group.flow_logs[0].arn : null
}

output "scp_id" {
  description = "ID of the Organizations SCP (if created)."
  value       = var.create_scp && var.scp_content != "" ? aws_organizations_policy.networking[0].id : null
}
