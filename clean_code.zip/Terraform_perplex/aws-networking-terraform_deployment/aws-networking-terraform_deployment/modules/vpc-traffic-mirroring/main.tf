##############################################################################
# Traffic Mirror Target
##############################################################################
resource "aws_ec2_traffic_mirror_target" "this" {
  description               = "${var.name} traffic mirror target"
  network_interface_id      = var.target_type == "eni" ? var.target_eni_id : null
  network_load_balancer_arn = var.target_type == "nlb" ? var.target_nlb_arn : null

  tags = merge(var.tags, { Name = "${var.name}-mirror-target" })
}

##############################################################################
# Traffic Mirror Filter
##############################################################################
resource "aws_ec2_traffic_mirror_filter" "this" {
  description      = var.filter_description
  network_services = ["amazon-dns"]

  tags = merge(var.tags, { Name = "${var.name}-mirror-filter" })
}

##############################################################################
# Filter Rules – Ingress
##############################################################################
resource "aws_ec2_traffic_mirror_filter_rule" "ingress" {
  for_each = { for i, r in var.filter_ingress_rules : i => r }

  traffic_mirror_filter_id = aws_ec2_traffic_mirror_filter.this.id
  traffic_direction        = "ingress"
  rule_number              = each.value.rule_number
  rule_action              = each.value.rule_action
  protocol                 = each.value.protocol >= 0 ? each.value.protocol : null
  source_cidr_block        = each.value.source_cidr_block
  destination_cidr_block   = each.value.destination_cidr_block

  dynamic "source_port_range" {
    for_each = each.value.source_port_range != null ? [each.value.source_port_range] : []
    content {
      from_port = source_port_range.value.from
      to_port   = source_port_range.value.to
    }
  }

  dynamic "destination_port_range" {
    for_each = each.value.destination_port_range != null ? [each.value.destination_port_range] : []
    content {
      from_port = destination_port_range.value.from
      to_port   = destination_port_range.value.to
    }
  }
}

##############################################################################
# Filter Rules – Egress
##############################################################################
resource "aws_ec2_traffic_mirror_filter_rule" "egress" {
  for_each = { for i, r in var.filter_egress_rules : i => r }

  traffic_mirror_filter_id = aws_ec2_traffic_mirror_filter.this.id
  traffic_direction        = "egress"
  rule_number              = each.value.rule_number
  rule_action              = each.value.rule_action
  protocol                 = each.value.protocol >= 0 ? each.value.protocol : null
  source_cidr_block        = each.value.source_cidr_block
  destination_cidr_block   = each.value.destination_cidr_block

  dynamic "source_port_range" {
    for_each = each.value.source_port_range != null ? [each.value.source_port_range] : []
    content {
      from_port = source_port_range.value.from
      to_port   = source_port_range.value.to
    }
  }

  dynamic "destination_port_range" {
    for_each = each.value.destination_port_range != null ? [each.value.destination_port_range] : []
    content {
      from_port = destination_port_range.value.from
      to_port   = destination_port_range.value.to
    }
  }
}

##############################################################################
# Traffic Mirror Sessions
##############################################################################
resource "aws_ec2_traffic_mirror_session" "this" {
  for_each = var.mirror_sessions

  description              = each.value.description != null ? each.value.description : "${var.name} session ${each.key}"
  traffic_mirror_filter_id = aws_ec2_traffic_mirror_filter.this.id
  traffic_mirror_target_id = aws_ec2_traffic_mirror_target.this.id
  network_interface_id     = each.value.source_eni_id
  session_number           = each.value.session_number
  packet_length            = each.value.packet_length > 0 ? each.value.packet_length : null
  virtual_network_id       = each.value.virtual_network_id

  tags = merge(var.tags, { Name = "${var.name}-mirror-session-${each.key}" })
}
