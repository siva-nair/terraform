# vpc-traffic-mirroring

Sets up VPC Traffic Mirroring: a mirror target (ENI or NLB), a mirror filter with ingress/egress rules, and one or more mirror sessions that copy traffic from source ENIs to the target.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_ec2_traffic_mirror_target` | Destination for mirrored traffic (ENI or NLB) |
| `aws_ec2_traffic_mirror_filter` | Defines what traffic to copy |
| `aws_ec2_traffic_mirror_filter_rule` (ingress) | Per-rule ingress filter entries |
| `aws_ec2_traffic_mirror_filter_rule` (egress) | Per-rule egress filter entries |
| `aws_ec2_traffic_mirror_session` | Binds a source ENI to the filter and target |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `target_type` | `string` | `eni` | Mirror target type: `eni` or `nlb` |
| `target_eni_id` | `string` | `null` | Monitoring appliance ENI ID |
| `target_nlb_arn` | `string` | `null` | NLB ARN for scaled monitoring |
| `filter_description` | `string` | `"Managed by Terraform"` | Filter description |
| `filter_ingress_rules` | `list(object)` | accept-all | Ingress filter rules |
| `filter_egress_rules` | `list(object)` | accept-all | Egress filter rules |
| `mirror_sessions` | `map(object)` | `{}` | Sessions mapping source ENIs to filter+target |
| `tags` | `map(string)` | `{}` | Tags |

## Outputs

| Name | Description |
|------|-------------|
| `mirror_target_id` | Mirror target ID |
| `mirror_filter_id` | Mirror filter ID |
| `mirror_session_ids` | Map of session name → ID |
| `ingress_filter_rule_ids` | Map of rule index → ID |
| `egress_filter_rule_ids` | Map of rule index → ID |

## Usage Example

```hcl
module "traffic_mirror" {
  source = "./modules/vpc-traffic-mirroring"

  name           = "prod"
  target_type    = "nlb"
  target_nlb_arn = aws_lb.ids_nlb.arn

  filter_ingress_rules = [
    {
      rule_number            = 100
      rule_action            = "accept"
      protocol               = 6  # TCP
      source_cidr_block      = "10.0.0.0/8"
      destination_cidr_block = "0.0.0.0/0"
      destination_port_range = { from = 443, to = 443 }
    },
    {
      rule_number            = 200
      rule_action            = "reject"
      protocol               = -1
      source_cidr_block      = "0.0.0.0/0"
      destination_cidr_block = "0.0.0.0/0"
    }
  ]

  mirror_sessions = {
    web-server-1 = {
      source_eni_id  = "REDACTED_AWS_RESOURCE_ID"
      session_number = 1
      packet_length  = 0  # full packet
    }
  }

  tags = { Environment = "production" }
}
```

## Concepts

### Traffic Mirroring Architecture
Traffic mirroring copies raw network packets from a **source ENI** and forwards them (encapsulated in VXLAN UDP/4789) to a **target**. No impact on production traffic; the source instance is unaware.

**Components:**
- **Mirror Target:** Where copies are sent. Can be an ENI (single appliance) or an NLB (scales to multiple appliance instances).
- **Mirror Filter:** Rules that select which traffic to mirror. Evaluated in rule-number order; lowest number wins. Supports protocol, CIDR, and port ranges. Default allows nothing — you must explicitly accept.
- **Mirror Session:** Links a source ENI to a filter and target. Session number controls priority when multiple sessions compete for the same source.

### Use Cases
- **Intrusion Detection Systems (IDS/IPS):** Send copies to Suricata/Snort running on EC2.
- **Network forensics:** Capture full packet data to a packet broker.
- **Performance monitoring:** Feed NetFlow/IPFIX generators.

### Supported Sources
Nitro-based EC2 instances only. Not supported on C1, M1, M2, M3, or T1 instance types.

### VXLAN Encapsulation
Mirrored packets are encapsulated in VXLAN (UDP/4789). The `virtual_network_id` in a session sets the VXLAN VNI, allowing the target to distinguish traffic from different sessions/sources.
