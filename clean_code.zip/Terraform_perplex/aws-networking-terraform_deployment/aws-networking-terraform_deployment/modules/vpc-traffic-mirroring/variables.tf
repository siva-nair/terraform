variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

# ── Mirror Target ─────────────────────────────────────────────────────────────
variable "target_type" {
  description = "Traffic mirror target type: eni or nlb."
  type        = string
  default     = "eni"

  validation {
    condition     = contains(["eni", "nlb"], var.target_type)
    error_message = "target_type must be 'eni' or 'nlb'."
  }
}

variable "target_eni_id" {
  description = "ENI ID of the monitoring appliance (used when target_type = eni)."
  type        = string
  default     = null
}

variable "target_nlb_arn" {
  description = "ARN of the Network Load Balancer (used when target_type = nlb)."
  type        = string
  default     = null
}

# ── Mirror Filter ─────────────────────────────────────────────────────────────
variable "filter_description" {
  description = "Description of the traffic mirror filter."
  type        = string
  default     = "Managed by Terraform"
}

variable "filter_ingress_rules" {
  description = <<-EOT
    List of ingress filter rules. Each object:
      rule_number    – int, lower wins
      rule_action    – accept | reject
      protocol       – IP protocol number (-1 = all)
      source_cidr_block
      destination_cidr_block
      source_port_range      – object { from, to } (optional)
      destination_port_range – object { from, to } (optional)
  EOT
  type = list(object({
    rule_number            = number
    rule_action            = string
    protocol               = number
    source_cidr_block      = string
    destination_cidr_block = string
    source_port_range = optional(object({
      from = number
      to   = number
    }))
    destination_port_range = optional(object({
      from = number
      to   = number
    }))
  }))
  default = [
    {
      rule_number            = 100
      rule_action            = "accept"
      protocol               = -1
      source_cidr_block      = "0.0.0.0/0"
      destination_cidr_block = "0.0.0.0/0"
    }
  ]
}

variable "filter_egress_rules" {
  description = "List of egress filter rules (same schema as filter_ingress_rules)."
  type = list(object({
    rule_number            = number
    rule_action            = string
    protocol               = number
    source_cidr_block      = string
    destination_cidr_block = string
    source_port_range = optional(object({
      from = number
      to   = number
    }))
    destination_port_range = optional(object({
      from = number
      to   = number
    }))
  }))
  default = [
    {
      rule_number            = 100
      rule_action            = "accept"
      protocol               = -1
      source_cidr_block      = "0.0.0.0/0"
      destination_cidr_block = "0.0.0.0/0"
    }
  ]
}

# ── Mirror Sessions ────────────────────────────────────────────────────────────
variable "mirror_sessions" {
  description = <<-EOT
    Map of traffic mirror sessions to create.
    Key = logical name
    Value = object with:
      source_eni_id – ENI to mirror traffic from
      session_number – unique session priority (lower = higher priority)
      packet_length  – optional truncation length in bytes (0 = full packet)
      virtual_network_id – optional VXLAN ID (1–16777216)
      description    – optional description
  EOT
  type = map(object({
    source_eni_id      = string
    session_number     = number
    packet_length      = optional(number, 0)
    virtual_network_id = optional(number)
    description        = optional(string)
  }))
  default = {}
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
