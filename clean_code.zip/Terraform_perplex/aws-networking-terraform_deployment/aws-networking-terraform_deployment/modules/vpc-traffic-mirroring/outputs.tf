output "mirror_target_id" {
  description = "ID of the traffic mirror target."
  value       = aws_ec2_traffic_mirror_target.this.id
}

output "mirror_filter_id" {
  description = "ID of the traffic mirror filter."
  value       = aws_ec2_traffic_mirror_filter.this.id
}

output "mirror_session_ids" {
  description = "Map of logical session name → mirror session ID."
  value       = { for k, v in aws_ec2_traffic_mirror_session.this : k => v.id }
}

output "ingress_filter_rule_ids" {
  description = "Map of rule index → ingress filter rule ID."
  value       = { for k, v in aws_ec2_traffic_mirror_filter_rule.ingress : k => v.id }
}

output "egress_filter_rule_ids" {
  description = "Map of rule index → egress filter rule ID."
  value       = { for k, v in aws_ec2_traffic_mirror_filter_rule.egress : k => v.id }
}
