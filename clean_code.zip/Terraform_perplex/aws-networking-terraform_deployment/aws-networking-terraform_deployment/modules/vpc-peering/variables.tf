variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

# ── Requester VPC ─────────────────────────────────────────────────────────────
variable "requester_vpc_id" {
  description = "ID of the requester (local) VPC."
  type        = string
}

variable "requester_vpc_cidr" {
  description = "CIDR block of the requester VPC (used to add routes on accepter side)."
  type        = string
}

variable "requester_route_table_ids" {
  description = "List of route table IDs in the requester VPC to add a route pointing to the peering connection."
  type        = list(string)
  default     = []
}

# ── Accepter VPC ──────────────────────────────────────────────────────────────
variable "accepter_vpc_id" {
  description = "ID of the accepter (peer) VPC."
  type        = string
}

variable "accepter_vpc_cidr" {
  description = "CIDR block of the accepter VPC (used to add routes on requester side)."
  type        = string
}

variable "accepter_route_table_ids" {
  description = "List of route table IDs in the accepter VPC to add a route pointing to the peering connection."
  type        = list(string)
  default     = []
}

# ── Cross-Account / Cross-Region ──────────────────────────────────────────────
variable "peer_owner_id" {
  description = "AWS account ID of the accepter VPC owner. Leave blank for same-account peering."
  type        = string
  default     = ""
}

variable "peer_region" {
  description = "AWS region of the accepter VPC. Leave blank for same-region peering."
  type        = string
  default     = ""
}

variable "auto_accept" {
  description = "Automatically accept the peering connection. Only works for same-account, same-region connections."
  type        = bool
  default     = true
}

# ── DNS Options ───────────────────────────────────────────────────────────────
variable "requester_allow_remote_vpc_dns_resolution" {
  description = "Allow the requester VPC to resolve public DNS hostnames to private IPs across the peering."
  type        = bool
  default     = true
}

variable "accepter_allow_remote_vpc_dns_resolution" {
  description = "Allow the accepter VPC to resolve public DNS hostnames to private IPs across the peering."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
