output "peering_connection_id" {
  description = "ID of the VPC peering connection."
  value       = aws_vpc_peering_connection.this.id
}

output "peering_connection_status" {
  description = "Status of the VPC peering connection."
  value       = aws_vpc_peering_connection.this.accept_status
}

output "requester_route_ids" {
  description = "Map of requester route table ID → route resource ID."
  value       = { for k, v in aws_route.requester_to_accepter : k => v.id }
}

output "accepter_route_ids" {
  description = "Map of accepter route table ID → route resource ID."
  value       = { for k, v in aws_route.accepter_to_requester : k => v.id }
}
