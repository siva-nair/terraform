locals {
  is_cross_account = var.peer_owner_id != ""
  is_cross_region  = var.peer_region != ""
  # auto_accept is only valid for same-account same-region
  effective_auto_accept = var.auto_accept && !local.is_cross_account && !local.is_cross_region
}

##############################################################################
# VPC Peering Connection (requester side)
##############################################################################
resource "aws_vpc_peering_connection" "this" {
  vpc_id        = var.requester_vpc_id
  peer_vpc_id   = var.accepter_vpc_id
  peer_owner_id = local.is_cross_account ? var.peer_owner_id : null
  peer_region   = local.is_cross_region ? var.peer_region : null
  auto_accept   = local.effective_auto_accept

  # DNS resolution options (only applicable when auto_accept = true / same account+region)
  dynamic "requester" {
    for_each = local.effective_auto_accept ? [1] : []
    content {
      allow_remote_vpc_dns_resolution = var.requester_allow_remote_vpc_dns_resolution
    }
  }

  dynamic "accepter" {
    for_each = local.effective_auto_accept ? [1] : []
    content {
      allow_remote_vpc_dns_resolution = var.accepter_allow_remote_vpc_dns_resolution
    }
  }

  tags = merge(var.tags, {
    Name = "${var.name}-peering"
    Side = "requester"
  })
}

##############################################################################
# VPC Peering Connection Accepter (cross-account / cross-region)
# Only creates the accepter resource when NOT auto-accepting.
# In cross-account scenarios this would live in a second provider alias block.
##############################################################################
resource "aws_vpc_peering_connection_accepter" "this" {
  count = local.effective_auto_accept ? 0 : 1

  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
  auto_accept               = true

  accepter {
    allow_remote_vpc_dns_resolution = var.accepter_allow_remote_vpc_dns_resolution
  }

  requester {
    allow_remote_vpc_dns_resolution = var.requester_allow_remote_vpc_dns_resolution
  }

  tags = merge(var.tags, {
    Name = "${var.name}-peering-accepter"
    Side = "accepter"
  })
}

##############################################################################
# Routes on Requester Side → accepter CIDR via peering
##############################################################################
resource "aws_route" "requester_to_accepter" {
  for_each = toset(var.requester_route_table_ids)

  route_table_id            = each.value
  destination_cidr_block    = var.accepter_vpc_cidr
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
}

##############################################################################
# Routes on Accepter Side → requester CIDR via peering
##############################################################################
resource "aws_route" "accepter_to_requester" {
  for_each = toset(var.accepter_route_table_ids)

  route_table_id            = each.value
  destination_cidr_block    = var.requester_vpc_cidr
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
}
