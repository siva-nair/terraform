# vpc-peering

Creates a VPC peering connection between two VPCs (same or cross-account, same or cross-region), adds routes on both sides, and configures DNS resolution options.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpc_peering_connection` | Initiates the peering from the requester VPC |
| `aws_vpc_peering_connection_accepter` | Accepts cross-account/cross-region peering |
| `aws_route` (requester side) | Routes accepter CIDR via peering connection |
| `aws_route` (accepter side) | Routes requester CIDR via peering connection |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `requester_vpc_id` | `string` | — | Local VPC ID |
| `requester_vpc_cidr` | `string` | — | Local VPC CIDR |
| `requester_route_table_ids` | `list(string)` | `[]` | Route tables to update on requester side |
| `accepter_vpc_id` | `string` | — | Peer VPC ID |
| `accepter_vpc_cidr` | `string` | — | Peer VPC CIDR |
| `accepter_route_table_ids` | `list(string)` | `[]` | Route tables to update on accepter side |
| `peer_owner_id` | `string` | `""` | Peer AWS account ID (cross-account) |
| `peer_region` | `string` | `""` | Peer region (cross-region) |
| `auto_accept` | `bool` | `true` | Auto-accept (same account+region only) |
| `requester_allow_remote_vpc_dns_resolution` | `bool` | `true` | DNS resolution on requester side |
| `accepter_allow_remote_vpc_dns_resolution` | `bool` | `true` | DNS resolution on accepter side |
| `tags` | `map(string)` | `{}` | Tags for all resources |

## Outputs

| Name | Description |
|------|-------------|
| `peering_connection_id` | Peering connection ID |
| `peering_connection_status` | Peering status (active, pending-acceptance, etc.) |
| `requester_route_ids` | Map of route table → route ID (requester side) |
| `accepter_route_ids` | Map of route table → route ID (accepter side) |

## Usage Example

### Same-Account, Same-Region

```hcl
module "peering" {
  source = "./modules/vpc-peering"

  name             = "app-to-shared"
  requester_vpc_id = module.app_vpc.vpc_id
  requester_vpc_cidr = "10.1.0.0/16"
  requester_route_table_ids = module.app_vpc.private_route_table_ids

  accepter_vpc_id  = module.shared_vpc.vpc_id
  accepter_vpc_cidr = "10.0.0.0/16"
  accepter_route_table_ids = module.shared_vpc.private_route_table_ids

  auto_accept = true
  tags        = { Environment = "production" }
}
```

### Cross-Account (requires provider alias in the accepter account)

```hcl
module "peering_xaccount" {
  source = "./modules/vpc-peering"

  name               = "prod-to-network"
  requester_vpc_id   = "vpc-0abc"
  requester_vpc_cidr = "10.1.0.0/16"

  accepter_vpc_id   = "vpc-0def"
  accepter_vpc_cidr = "10.0.0.0/16"
  peer_owner_id     = "REDACTED_AWS_ACCOUNT_ID"  # accepter account
  auto_accept       = false           # must be accepted in peer account

  tags = { Environment = "production" }
}
```

## Concepts

### VPC Peering
A private, non-transitive connection between two VPCs (same account, same region; or cross-account/cross-region). Traffic stays on the AWS backbone — no IGW, VGW, or NAT required.

**Key characteristics:**
- **Non-transitive:** If A↔B and B↔C, A cannot reach C via B. You must explicitly peer A↔C.
- **No overlapping CIDRs:** Peering fails if VPC CIDRs overlap (including secondary CIDRs).
- **Routes required on both sides:** Creating the peering alone is not enough; you must add routes in both VPCs' route tables.
- **Security groups:** Can reference peered VPC security group IDs by ID (same-region only).

### Cross-Account Peering
1. Requester creates connection → status becomes `pending-acceptance`.
2. Accepter (in the peer account) accepts the connection.
3. Both sides add routes.
In Terraform, use a second `provider` block with `alias` pointing to the accepter account credentials, and target the `aws_vpc_peering_connection_accepter` resource at that provider.

### Cross-Region Peering
Specify `peer_region`. Traffic traverses the AWS global backbone (encrypted). Latency is higher than same-region; consider Transit Gateway for hub-and-spoke across regions instead.

### DNS Resolution
When `allow_remote_vpc_dns_resolution = true`, instances in each VPC can resolve the **public DNS hostnames** of instances in the peer VPC to their **private IPs** (requires `enableDnsHostnames` and `enableDnsSupport` in both VPCs).
