##############################################################################
# Data – latest Amazon Linux 2023 AMI (used when ami_id not provided)
##############################################################################
data "aws_ami" "al2023" {
  count = var.create_ena_instance && var.ami_id == "" ? 1 : 0

  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

locals {
  ami_id = var.create_ena_instance ? (
    var.ami_id != "" ? var.ami_id : data.aws_ami.al2023[0].id
  ) : null
}

##############################################################################
# Placement Groups
##############################################################################
resource "aws_placement_group" "this" {
  for_each = var.placement_groups

  name            = "${var.name}-pg-${each.key}"
  strategy        = each.value.strategy
  partition_count = each.value.strategy == "partition" ? each.value.partition_count : null
  spread_level    = each.value.strategy == "spread" ? each.value.spread_level : null

  tags = merge(var.tags, {
    Name     = "${var.name}-pg-${each.key}"
    Strategy = each.value.strategy
  })
}

##############################################################################
# Enhanced Networking / ENA Demo Instance
##
# Notes:
#   • ena_support = true  → Elastic Network Adapter (up to 100 Gbps on supported types)
#   • ebs_optimized = true → dedicated EBS bandwidth (standard on most modern types)
#   • Jumbo frames (MTU 9001) are supported within the VPC; transit through IGW/VPN
#     is limited to 1500 bytes — set MTU on the OS (`ip link set eth0 mtu 9001`).
#   • SR-IOV / Enhanced Networking (Intel 82599 VF) is older; ENA supersedes it.
##############################################################################
resource "aws_instance" "ena_demo" {
  count = var.create_ena_instance ? 1 : 0

  ami                    = local.ami_id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  key_name               = var.key_name
  vpc_security_group_ids = var.security_group_ids

  # ENA support is determined by the AMI and instance type; no explicit argument needed.
  # Dedicated EBS throughput
  ebs_optimized = true

  # Assign to a placement group (optional)
  placement_group = var.placement_group_key != null ? aws_placement_group.this[var.placement_group_key].id : null

  # User data: set jumbo frame MTU
  user_data = base64encode(<<-EOF
    #!/bin/bash
    # Enable jumbo frames (9001 MTU) for intra-VPC traffic
    ip link set eth0 mtu 9001
    echo 'MTU=9001' >> /etc/sysconfig/network-scripts/ifcfg-eth0
    EOF
  )

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required" # IMDSv2
    http_put_response_hop_limit = 1
  }

  root_block_device {
    volume_type           = "gp3"
    volume_size           = 20
    delete_on_termination = true
    encrypted             = true
  }

  tags = merge(var.tags, {
    Name               = "${var.name}-ena-demo"
    EnhancedNetworking = "ENA"
    JumboFrames        = "9001"
  })
}
