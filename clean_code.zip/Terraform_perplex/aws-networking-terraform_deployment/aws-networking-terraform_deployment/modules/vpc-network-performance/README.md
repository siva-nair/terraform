# vpc-network-performance

Creates EC2 placement groups (cluster, spread, partition), and an optional demo instance with Elastic Network Adapter (ENA) support and jumbo frame configuration. Covers the networking performance features tested in the ANS-C01 exam.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_placement_group` | Cluster, spread, and partition placement groups |
| `aws_instance` (optional) | ENA-enabled instance with jumbo frame user data |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `vpc_id` | `string` | — | Target VPC ID |
| `subnet_id` | `string` | — | Subnet for demo instance |
| `placement_groups` | `map(object)` | cluster+spread+partition | Placement group definitions |
| `create_ena_instance` | `bool` | `false` | Create ENA demo instance |
| `instance_type` | `string` | `c5n.large` | Instance type (must support ENA) |
| `ami_id` | `string` | `""` | AMI ID (auto-selects AL2023 if blank) |
| `key_name` | `string` | `null` | EC2 key pair name |
| `security_group_ids` | `list(string)` | `[]` | Security groups for demo instance |
| `placement_group_key` | `string` | `null` | Placement group to assign to instance |
| `tags` | `map(string)` | `{}` | Tags for all resources |

## Outputs

| Name | Description |
|------|-------------|
| `placement_group_ids` | Map of name → placement group ID |
| `placement_group_arns` | Map of name → placement group ARN |
| `ena_instance_id` | Demo instance ID |
| `ena_instance_private_ip` | Demo instance private IP |
| `ena_instance_eni_id` | Primary ENI ID |
| `ami_id_used` | Resolved AMI ID |

## Usage Example

```hcl
module "network_perf" {
  source = "./modules/vpc-network-performance"

  name      = "prod"
  vpc_id    = module.vpc.vpc_id
  subnet_id = module.vpc.private_subnet_ids[0]

  placement_groups = {
    hpc-cluster = {
      strategy = "cluster"
    }
    ha-spread = {
      strategy     = "spread"
      spread_level = "rack"
    }
  }

  create_ena_instance = true
  instance_type       = "c5n.4xlarge"
  security_group_ids  = [aws_security_group.app.id]
  placement_group_key = "hpc-cluster"

  tags = { Environment = "production" }
}
```

## Concepts

### Placement Groups

| Strategy | Topology | Use Case | Limits |
|----------|----------|----------|--------|
| **Cluster** | Same rack / low-latency spine | HPC, ML training, tightly-coupled MPI | Same AZ; limited to physical rack capacity |
| **Spread** | Different racks (or hosts) | Small critical-instance HA (max 7 instances per AZ) | 7 running instances per AZ |
| **Partition** | Separate partitions (groups of racks) | Large distributed systems (Kafka, Cassandra, Hadoop) | Up to 7 partitions per AZ, unlimited instances |

### Enhanced Networking (ENA vs SR-IOV)
- **SR-IOV (Intel 82599 VF):** Legacy; up to 10 Gbps. Uses `ixgbevf` driver.
- **ENA (Elastic Network Adapter):** Modern; up to 100 Gbps on supported instance families (c5n, m5n, r5n, p4, etc.). Uses `ena` driver, present in Amazon Linux 2+. Enable via `ena_support = true` on the instance resource.
- Verify with: `ethtool -i eth0` → driver should show `ena`.

### Jumbo Frames (MTU 9001)
Supported within a VPC and across VPC peering connections. **Not** supported over IGW, VPN, or Direct Connect (capped at 1500 for VPN, 8500 for DX LAG). Set OS MTU: `ip link set eth0 mtu 9001`. Reduces CPU overhead per-byte on bulk transfers.

### Network Performance by Instance Family
- `c5n` / `m5n` / `r5n`: Up to 100 Gbps ENA
- `p4d.24xlarge`: 400 Gbps (4 × 100 Gbps ENA)
- `hpc6a`: 200 Gbps EFA (Elastic Fabric Adapter) — RDMA-capable, bypasses OS networking stack for MPI workloads

### Elastic Fabric Adapter (EFA)
EFA provides OS-bypass networking for tightly-coupled HPC. Uses `libfabric` API. Not provisioned via `ena_support`; requires a separate EFA interface (`aws_network_interface` with `interface_type = "efa"`) and `libfabric`/MPI installed on the OS.
