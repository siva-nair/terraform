output "placement_group_ids" {
  description = "Map of logical name → placement group ID."
  value       = { for k, v in aws_placement_group.this : k => v.id }
}

output "placement_group_arns" {
  description = "Map of logical name → placement group ARN."
  value       = { for k, v in aws_placement_group.this : k => v.arn }
}

output "ena_instance_id" {
  description = "ID of the ENA demo instance."
  value       = length(aws_instance.ena_demo) > 0 ? aws_instance.ena_demo[0].id : null
}

output "ena_instance_private_ip" {
  description = "Private IP of the ENA demo instance."
  value       = length(aws_instance.ena_demo) > 0 ? aws_instance.ena_demo[0].private_ip : null
}

output "ena_instance_eni_id" {
  description = "Primary ENI ID of the ENA demo instance."
  value       = length(aws_instance.ena_demo) > 0 ? aws_instance.ena_demo[0].primary_network_interface_id : null
}

output "ami_id_used" {
  description = "AMI ID resolved for the demo instance."
  value       = local.ami_id
}
