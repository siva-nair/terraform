variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "vpc_id" {
  description = "VPC ID in which instances and placement groups will be created."
  type        = string
}

variable "subnet_id" {
  description = "Subnet ID for the enhanced-networking demo instance."
  type        = string
}

# ── Placement Groups ──────────────────────────────────────────────────────────
variable "placement_groups" {
  description = <<-EOT
    Map of placement groups to create.
    Key = logical name
    Value = object with:
      strategy  – cluster | spread | partition
      partition_count – number of partitions (only relevant for strategy=partition, default 2)
      spread_level    – host | rack (only relevant for strategy=spread, default rack)
  EOT
  type = map(object({
    strategy        = string
    partition_count = optional(number, 2)
    spread_level    = optional(string, "rack")
  }))
  default = {
    cluster = {
      strategy = "cluster"
    }
    spread = {
      strategy = "spread"
    }
    partition = {
      strategy        = "partition"
      partition_count = 3
    }
  }

  validation {
    condition     = alltrue([for v in values(var.placement_groups) : contains(["cluster", "spread", "partition"], v.strategy)])
    error_message = "Placement group strategy must be cluster, spread, or partition."
  }
}

# ── Enhanced Networking Demo Instance ────────────────────────────────────────
variable "create_ena_instance" {
  description = "Create a demo EC2 instance showing ENA / enhanced networking."
  type        = bool
  default     = false
}

variable "instance_type" {
  description = "EC2 instance type (should support ENA, e.g. c5n.large, m5n.xlarge)."
  type        = string
  default     = "c5n.large"
}

variable "ami_id" {
  description = "AMI ID for the demo instance. Defaults to latest Amazon Linux 2023 x86_64."
  type        = string
  default     = ""
}

variable "key_name" {
  description = "EC2 key pair name for SSH access."
  type        = string
  default     = null
}

variable "security_group_ids" {
  description = "Security group IDs to attach to the demo instance."
  type        = list(string)
  default     = []
}

variable "placement_group_key" {
  description = "Key from var.placement_groups to assign to the demo instance (optional)."
  type        = string
  default     = null
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
