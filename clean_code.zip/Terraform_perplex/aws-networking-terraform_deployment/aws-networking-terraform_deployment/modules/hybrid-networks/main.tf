##############################################################################
# Customer Gateways
# Represent the on-premises routers (data-center edge devices, firewalls, etc.)
##############################################################################
resource "aws_customer_gateway" "this" {
  for_each = var.customer_gateways

  bgp_asn         = each.value.bgp_asn
  ip_address      = each.value.ip_address
  type            = each.value.type
  device_name     = each.value.device_name
  certificate_arn = each.value.certificate_arn

  tags = merge(var.tags, { Name = "${var.name}-cgw-${each.key}" })
}

##############################################################################
# Virtual Private Gateway (VGW)
# Single-region, single-VPC gateway. Used for Site-to-Site VPN and DX.
##############################################################################
resource "aws_vpn_gateway" "this" {
  count = var.create_vpn_gateway ? 1 : 0

  amazon_side_asn = var.vpn_gateway_asn

  tags = merge(var.tags, { Name = "${var.name}-vgw" })
}

resource "aws_vpn_gateway_attachment" "this" {
  count = var.create_vpn_gateway && var.vpc_id != null ? 1 : 0

  vpc_id         = var.vpc_id
  vpn_gateway_id = aws_vpn_gateway.this[0].id
}

##############################################################################
# VGW Route Propagation
# Automatically populates route tables with on-premises routes learned via BGP.
##############################################################################
resource "aws_vpn_gateway_route_propagation" "this" {
  for_each = var.create_vpn_gateway ? toset(var.vgw_route_propagation_route_table_ids) : toset([])

  vpn_gateway_id = aws_vpn_gateway.this[0].id
  route_table_id = each.value

  depends_on = [aws_vpn_gateway_attachment.this]
}

##############################################################################
# Direct Connect Gateway
# A global resource (not region-scoped) that connects multiple VGWs/TGWs
# to Direct Connect Virtual Interfaces.
##############################################################################
resource "aws_dx_gateway" "this" {
  count = var.create_dx_gateway ? 1 : 0

  name            = "${var.name}-dxgw"
  amazon_side_asn = var.dx_gateway_asn
}

##############################################################################
# DX Gateway Associations (DX GW ↔ VGW or TGW)
##############################################################################
resource "aws_dx_gateway_association" "this" {
  for_each = var.create_dx_gateway ? var.dx_gateway_associations : {}

  dx_gateway_id         = aws_dx_gateway.this[0].id
  associated_gateway_id = each.value.associated_gateway_id

  dynamic "timeouts" {
    for_each = [1]
    content {
      create = "30m"
      update = "30m"
      delete = "30m"
    }
  }

  # Prefix list to advertise from on-premises side
  allowed_prefixes = length(each.value.allowed_prefixes) > 0 ? each.value.allowed_prefixes : null
}
