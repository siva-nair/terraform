output "customer_gateway_ids" {
  description = "Map of logical name → Customer Gateway ID."
  value       = { for k, v in aws_customer_gateway.this : k => v.id }
}

output "customer_gateway_arns" {
  description = "Map of logical name → Customer Gateway ARN."
  value       = { for k, v in aws_customer_gateway.this : k => v.arn }
}

output "vpn_gateway_id" {
  description = "ID of the Virtual Private Gateway."
  value       = length(aws_vpn_gateway.this) > 0 ? aws_vpn_gateway.this[0].id : null
}

output "vpn_gateway_arn" {
  description = "ARN of the Virtual Private Gateway."
  value       = length(aws_vpn_gateway.this) > 0 ? aws_vpn_gateway.this[0].arn : null
}

output "vpn_gateway_attachment_id" {
  description = "ID of the VGW-to-VPC attachment."
  value       = length(aws_vpn_gateway_attachment.this) > 0 ? aws_vpn_gateway_attachment.this[0].id : null
}

output "dx_gateway_id" {
  description = "ID of the Direct Connect Gateway."
  value       = length(aws_dx_gateway.this) > 0 ? aws_dx_gateway.this[0].id : null
}

output "dx_gateway_owner_account_id" {
  description = "AWS account ID that owns the DX Gateway."
  value       = length(aws_dx_gateway.this) > 0 ? aws_dx_gateway.this[0].owner_account_id : null
}

output "dx_gateway_association_ids" {
  description = "Map of logical name → DX Gateway association ID."
  value       = { for k, v in aws_dx_gateway_association.this : k => v.id }
}
