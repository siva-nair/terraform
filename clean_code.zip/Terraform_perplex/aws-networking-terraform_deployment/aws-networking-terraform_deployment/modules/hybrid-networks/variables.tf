variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to attach the Virtual Private Gateway to."
  type        = string
  default     = null
}

# ── Customer Gateway ──────────────────────────────────────────────────────────
variable "customer_gateways" {
  description = <<-EOT
    Map of Customer Gateways (on-premises routers) to create.
    Key = logical name (e.g. "dc1", "dc2")
    Value = object with:
      bgp_asn    – BGP ASN of the on-premises router
      ip_address – Public IP of the on-premises router
      type       – "ipsec.1" (only valid value currently)
      device_name – optional label
      certificate_arn – optional ACM certificate ARN for private CGW (without public IP)
  EOT
  type = map(object({
    bgp_asn         = number
    ip_address      = string
    type            = optional(string, "ipsec.1")
    device_name     = optional(string)
    certificate_arn = optional(string)
  }))
  default = {}
}

# ── Virtual Private Gateway ───────────────────────────────────────────────────
variable "create_vpn_gateway" {
  description = "Create a Virtual Private Gateway and attach it to the VPC."
  type        = bool
  default     = false
}

variable "vpn_gateway_asn" {
  description = "BGP ASN for the Virtual Private Gateway (AWS side)."
  type        = number
  default     = 64512
}

variable "vgw_route_propagation_route_table_ids" {
  description = "List of route table IDs to enable VGW route propagation on."
  type        = list(string)
  default     = []
}

# ── Direct Connect Gateway ────────────────────────────────────────────────────
variable "create_dx_gateway" {
  description = "Create a Direct Connect Gateway."
  type        = bool
  default     = false
}

variable "dx_gateway_asn" {
  description = "BGP ASN for the Direct Connect Gateway (must be in 64512–65534 or 4200000000–4294967294, different from VGW ASN)."
  type        = number
  default     = 64513
}

# ── DX Gateway Association ────────────────────────────────────────────────────
variable "dx_gateway_associations" {
  description = <<-EOT
    Map of Direct Connect Gateway associations to VGW or TGW.
    Key = logical name
    Value = object with:
      associated_gateway_id   – VGW or TGW ID to associate with the DX GW
      allowed_prefixes        – list of CIDRs to advertise to the DX GW (optional)
  EOT
  type = map(object({
    associated_gateway_id = string
    allowed_prefixes      = optional(list(string), [])
  }))
  default = {}
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
