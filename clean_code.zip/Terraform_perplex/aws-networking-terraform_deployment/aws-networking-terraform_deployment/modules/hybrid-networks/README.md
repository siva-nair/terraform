# hybrid-networks

Provisions the hybrid connectivity building blocks: Customer Gateways, Virtual Private Gateway (VGW), VGW route propagation, Direct Connect Gateway, and DX Gateway associations. This is the umbrella module for establishing connectivity between AWS and on-premises networks.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_customer_gateway` | Represents the on-premises router |
| `aws_vpn_gateway` | AWS-side gateway for Site-to-Site VPN / DX (single VPC) |
| `aws_vpn_gateway_attachment` | Attaches VGW to the VPC |
| `aws_vpn_gateway_route_propagation` | Propagates on-premises BGP routes to route tables |
| `aws_dx_gateway` | Global Direct Connect Gateway (multi-region, multi-VPC) |
| `aws_dx_gateway_association` | Associates DX GW with VGW or TGW |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `vpc_id` | `string` | `null` | VPC to attach VGW to |
| `customer_gateways` | `map(object)` | `{}` | Customer gateways (on-premises routers) |
| `create_vpn_gateway` | `bool` | `false` | Create a VGW |
| `vpn_gateway_asn` | `number` | `64512` | VGW BGP ASN |
| `vgw_route_propagation_route_table_ids` | `list(string)` | `[]` | Route tables for BGP propagation |
| `create_dx_gateway` | `bool` | `false` | Create a DX Gateway |
| `dx_gateway_asn` | `number` | `64513` | DX GW BGP ASN |
| `dx_gateway_associations` | `map(object)` | `{}` | DX GW associations to VGW or TGW |
| `tags` | `map(string)` | `{}` | Tags |

## Outputs

| Name | Description |
|------|-------------|
| `customer_gateway_ids` | Map of name → CGW ID |
| `customer_gateway_arns` | Map of name → CGW ARN |
| `vpn_gateway_id` | VGW ID |
| `vpn_gateway_arn` | VGW ARN |
| `vpn_gateway_attachment_id` | VGW attachment ID |
| `dx_gateway_id` | DX GW ID |
| `dx_gateway_owner_account_id` | Owning account ID |
| `dx_gateway_association_ids` | Map of name → association ID |

## Usage Example

```hcl
module "hybrid" {
  source = "./modules/hybrid-networks"

  name   = "prod"
  vpc_id = module.vpc.vpc_id

  customer_gateways = {
    dc-primary = {
      bgp_asn    = 65000
      ip_address = "203.0.113.1"
    }
    dc-backup = {
      bgp_asn    = 65000
      ip_address = "203.0.113.2"
    }
  }

  create_vpn_gateway = true
  vpn_gateway_asn    = 64512
  vgw_route_propagation_route_table_ids = module.vpc.private_route_table_ids

  create_dx_gateway  = true
  dx_gateway_asn     = 64513

  dx_gateway_associations = {
    vgw-assoc = {
      associated_gateway_id = module.hybrid.vpn_gateway_id
      allowed_prefixes      = ["10.100.0.0/16", "192.168.0.0/16"]
    }
  }

  tags = { Environment = "production" }
}
```

## Concepts

### Customer Gateway (CGW)
A logical representation of the on-premises router in AWS. You provide:
- **Public IP** of the on-premises device (or ACM certificate ARN for private CGW).
- **BGP ASN** (for dynamic routing) or leave as 65000 for static-only.
The CGW itself creates no AWS infrastructure — it's just a configuration object referenced by VPN connections.

### Virtual Private Gateway (VGW)
The AWS-side VPN concentrator, attached to a single VPC. Supports:
- Up to 10 VPN connections per VGW.
- BGP (dynamic routing) or static routing.
- Can connect to a DX Virtual Interface for Direct Connect.
VGW is region-scoped and VPC-scoped; for multi-VPC/multi-region, use Transit Gateway instead.

### VGW Route Propagation
When enabled on a route table, AWS automatically populates routes learned from the VGW (via BGP or static VPN routes) into that route table. Eliminates manual route management when CIDRs change on-premises.

### Direct Connect Gateway (DX Gateway)
A **global** (non-regional) resource that connects a single DX connection to multiple VGWs or Transit Gateways across any AWS region in the same account. Architecture:
```
On-premises → DX Location → DX Connection → Virtual Interface → DX Gateway → VGW/TGW → VPC
```
A DX Gateway can be associated with up to 20 VGWs (across regions) and 3 TGWs.

### VGW vs TGW for Hybrid Connectivity

| Feature | VGW | TGW |
|---------|-----|-----|
| VPC scope | Single VPC | Multiple VPCs |
| VPN connections | 10 | 5,000 |
| BGP ECMP | No | Yes |
| Direct Connect | Yes (via DX GW) | Yes (via DX GW) |
| Routing complexity | Low | High |
| Cost | Per connection | Per hour + per GB |

Use TGW for hub-and-spoke architectures serving many VPCs; use VGW for simple single-VPC scenarios.
