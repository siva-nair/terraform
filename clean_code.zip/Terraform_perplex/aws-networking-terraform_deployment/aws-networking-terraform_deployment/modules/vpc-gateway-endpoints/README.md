# vpc-gateway-endpoints

Creates VPC Gateway Endpoints for Amazon S3 and DynamoDB, associates them with specified route tables, and exposes the managed prefix list IDs for use in security group rules and NACLs.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpc_endpoint` (S3) | Gateway endpoint for Amazon S3 |
| `aws_vpc_endpoint` (DynamoDB) | Gateway endpoint for Amazon DynamoDB |
| `data.aws_prefix_list` (S3) | Managed prefix list for S3 CIDRs |
| `data.aws_prefix_list` (DynamoDB) | Managed prefix list for DynamoDB CIDRs |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `vpc_id` | `string` | — | Target VPC ID |
| `route_table_ids` | `list(string)` | `[]` | Route tables to associate with endpoints |
| `enable_s3_endpoint` | `bool` | `true` | Create S3 gateway endpoint |
| `s3_endpoint_policy` | `string` | `""` | Custom IAM policy for S3 endpoint |
| `enable_dynamodb_endpoint` | `bool` | `true` | Create DynamoDB gateway endpoint |
| `dynamodb_endpoint_policy` | `string` | `""` | Custom IAM policy for DynamoDB endpoint |
| `tags` | `map(string)` | `{}` | Tags for all resources |

## Outputs

| Name | Description |
|------|-------------|
| `s3_endpoint_id` | S3 endpoint ID |
| `s3_endpoint_arn` | S3 endpoint ARN |
| `s3_prefix_list_id` | S3 managed prefix list ID |
| `s3_prefix_list_cidr_blocks` | S3 IP ranges |
| `dynamodb_endpoint_id` | DynamoDB endpoint ID |
| `dynamodb_endpoint_arn` | DynamoDB endpoint ARN |
| `dynamodb_prefix_list_id` | DynamoDB managed prefix list ID |
| `dynamodb_prefix_list_cidr_blocks` | DynamoDB IP ranges |

## Usage Example

```hcl
module "gateway_endpoints" {
  source = "./modules/vpc-gateway-endpoints"

  name            = "prod"
  vpc_id          = module.vpc.vpc_id
  route_table_ids = module.vpc.private_route_table_ids

  enable_s3_endpoint       = true
  enable_dynamodb_endpoint = true

  # Restrict S3 endpoint to your organization's buckets
  s3_endpoint_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = "*"
      Action    = ["s3:GetObject", "s3:PutObject", "s3:ListBucket"]
      Resource  = ["REDACTED_AWS_ARN", "REDACTED_AWS_ARN"]
    }]
  })

  tags = { Environment = "production" }
}

# Use prefix list in security group rules
resource "aws_security_group_rule" "allow_s3" {
  type              = "egress"
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  prefix_list_ids   = [module.gateway_endpoints.s3_prefix_list_id]
  security_group_id = aws_security_group.app.id
}
```

## Concepts

### Gateway Endpoints
VPC Gateway Endpoints are a **free** way to privately route traffic to S3 and DynamoDB without leaving the Amazon network — no NAT Gateway, IGW, or per-GB data processing charge.

**How they work:**
1. AWS adds a route in the specified route tables: destination = prefix list (S3 or DynamoDB CIDRs) → target = endpoint ID.
2. Traffic destined for S3/DynamoDB exits the VPC via the endpoint rather than the NAT GW or IGW.
3. No ENI is created; the endpoint is a route table entry.

**Currently supports only:** S3 and DynamoDB (all other AWS services use Interface Endpoints).

### Endpoint Policies
Gateway endpoints support resource-based IAM policies that restrict which S3 buckets or DynamoDB tables are accessible via the endpoint. This is separate from bucket/table policies — both must allow the action.

### Prefix Lists
AWS publishes managed prefix lists for S3 and DynamoDB per region (e.g., `com.amazonaws.us-east-1.s3`). Use the prefix list ID in:
- Security group egress rules (reference as `prefix_list_ids`)
- NACLs: expand the `cidr_blocks` from the data source
- Route table entries (done automatically by the gateway endpoint)

### Cost Benefit
For workloads with heavy S3 access (data lakes, backup, ML training), gateway endpoints eliminate NAT Gateway data processing charges that can otherwise reach hundreds of dollars/month.
