##############################################################################
# Data – current region (used to build service names)
##############################################################################
data "aws_region" "current" {}

##############################################################################
# S3 Gateway Endpoint
##############################################################################
resource "aws_vpc_endpoint" "s3" {
  count = var.enable_s3_endpoint ? 1 : 0

  vpc_id            = var.vpc_id
  service_name      = "com.amazonaws.${data.aws_region.current.name}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = var.route_table_ids
  policy            = var.s3_endpoint_policy != "" ? var.s3_endpoint_policy : null

  tags = merge(var.tags, { Name = "${var.name}-s3-gateway-endpoint" })
}

##############################################################################
# DynamoDB Gateway Endpoint
##############################################################################
resource "aws_vpc_endpoint" "dynamodb" {
  count = var.enable_dynamodb_endpoint ? 1 : 0

  vpc_id            = var.vpc_id
  service_name      = "com.amazonaws.${data.aws_region.current.name}.dynamodb"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = var.route_table_ids
  policy            = var.dynamodb_endpoint_policy != "" ? var.dynamodb_endpoint_policy : null

  tags = merge(var.tags, { Name = "${var.name}-dynamodb-gateway-endpoint" })
}

##############################################################################
# Data – Prefix Lists (managed prefix list IDs for S3 and DynamoDB)
##############################################################################
data "aws_prefix_list" "s3" {
  count = var.enable_s3_endpoint ? 1 : 0

  filter {
    name   = "prefix-list-name"
    values = ["com.amazonaws.${data.aws_region.current.name}.s3"]
  }
}

data "aws_prefix_list" "dynamodb" {
  count = var.enable_dynamodb_endpoint ? 1 : 0

  filter {
    name   = "prefix-list-name"
    values = ["com.amazonaws.${data.aws_region.current.name}.dynamodb"]
  }
}
