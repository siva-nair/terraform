output "s3_endpoint_id" {
  description = "ID of the S3 gateway endpoint."
  value       = length(aws_vpc_endpoint.s3) > 0 ? aws_vpc_endpoint.s3[0].id : null
}

output "s3_endpoint_arn" {
  description = "ARN of the S3 gateway endpoint."
  value       = length(aws_vpc_endpoint.s3) > 0 ? aws_vpc_endpoint.s3[0].arn : null
}

output "s3_prefix_list_id" {
  description = "Managed prefix list ID for S3 (use in security group rules)."
  value       = length(data.aws_prefix_list.s3) > 0 ? data.aws_prefix_list.s3[0].id : null
}

output "s3_prefix_list_cidr_blocks" {
  description = "CIDR blocks covered by the S3 prefix list."
  value       = length(data.aws_prefix_list.s3) > 0 ? data.aws_prefix_list.s3[0].cidr_blocks : []
}

output "dynamodb_endpoint_id" {
  description = "ID of the DynamoDB gateway endpoint."
  value       = length(aws_vpc_endpoint.dynamodb) > 0 ? aws_vpc_endpoint.dynamodb[0].id : null
}

output "dynamodb_endpoint_arn" {
  description = "ARN of the DynamoDB gateway endpoint."
  value       = length(aws_vpc_endpoint.dynamodb) > 0 ? aws_vpc_endpoint.dynamodb[0].arn : null
}

output "dynamodb_prefix_list_id" {
  description = "Managed prefix list ID for DynamoDB (use in security group rules)."
  value       = length(data.aws_prefix_list.dynamodb) > 0 ? data.aws_prefix_list.dynamodb[0].id : null
}

output "dynamodb_prefix_list_cidr_blocks" {
  description = "CIDR blocks covered by the DynamoDB prefix list."
  value       = length(data.aws_prefix_list.dynamodb) > 0 ? data.aws_prefix_list.dynamodb[0].cidr_blocks : []
}
