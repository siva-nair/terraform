variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to attach gateway endpoints to."
  type        = string
}

variable "route_table_ids" {
  description = "List of route table IDs that should have routes added for the gateway endpoints."
  type        = list(string)
  default     = []
}

# ── S3 Gateway Endpoint ───────────────────────────────────────────────────────
variable "enable_s3_endpoint" {
  description = "Create a Gateway endpoint for Amazon S3."
  type        = bool
  default     = true
}

variable "s3_endpoint_policy" {
  description = "IAM resource policy JSON for the S3 gateway endpoint. If empty, uses the default full-access policy."
  type        = string
  default     = ""
}

# ── DynamoDB Gateway Endpoint ─────────────────────────────────────────────────
variable "enable_dynamodb_endpoint" {
  description = "Create a Gateway endpoint for Amazon DynamoDB."
  type        = bool
  default     = true
}

variable "dynamodb_endpoint_policy" {
  description = "IAM resource policy JSON for the DynamoDB gateway endpoint. If empty, uses the default full-access policy."
  type        = string
  default     = ""
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
