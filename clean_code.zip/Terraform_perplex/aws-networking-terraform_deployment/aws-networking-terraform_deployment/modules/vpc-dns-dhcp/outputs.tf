output "dhcp_options_id" {
  description = "ID of the DHCP options set."
  value       = aws_vpc_dhcp_options.this.id
}

output "dhcp_options_association_id" {
  description = "ID of the DHCP options set association."
  value       = aws_vpc_dhcp_options_association.this.id
}

output "resolver_inbound_endpoint_id" {
  description = "ID of the Route 53 Resolver inbound endpoint."
  value       = length(aws_route53_resolver_endpoint.inbound) > 0 ? aws_route53_resolver_endpoint.inbound[0].id : null
}

output "resolver_inbound_endpoint_ips" {
  description = "IP addresses assigned to the inbound resolver endpoint ENIs."
  value       = length(aws_route53_resolver_endpoint.inbound) > 0 ? aws_route53_resolver_endpoint.inbound[0].ip_address : []
}

output "resolver_outbound_endpoint_id" {
  description = "ID of the Route 53 Resolver outbound endpoint."
  value       = length(aws_route53_resolver_endpoint.outbound) > 0 ? aws_route53_resolver_endpoint.outbound[0].id : null
}

output "resolver_rule_ids" {
  description = "Map of logical rule name → resolver rule ID."
  value       = { for k, v in aws_route53_resolver_rule.this : k => v.id }
}

output "resolver_rule_arns" {
  description = "Map of logical rule name → resolver rule ARN."
  value       = { for k, v in aws_route53_resolver_rule.this : k => v.arn }
}

output "resolver_rule_association_ids" {
  description = "Map of logical rule name → rule association ID."
  value       = { for k, v in aws_route53_resolver_rule_association.this : k => v.id }
}
