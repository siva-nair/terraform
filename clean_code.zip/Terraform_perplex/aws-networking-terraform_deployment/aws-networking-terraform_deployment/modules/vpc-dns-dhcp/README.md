# vpc-dns-dhcp

Configures DNS and DHCP services for an existing VPC: custom DHCP options sets, Route 53 Resolver inbound/outbound endpoints, and resolver forwarding rules.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpc_dhcp_options` | Custom DHCP options (DNS servers, domain name, NTP) |
| `aws_vpc_dhcp_options_association` | Associates the DHCP options set with the VPC |
| `aws_route53_resolver_endpoint` (inbound) | Allows on-premises DNS to query Route 53 |
| `aws_route53_resolver_endpoint` (outbound) | Allows VPC instances to query on-premises DNS |
| `aws_route53_resolver_rule` | Forwarding/system rules for specific domains |
| `aws_route53_resolver_rule_association` | Associates resolver rules with the VPC |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `vpc_id` | `string` | — | Target VPC ID |
| `domain_name` | `string` | `""` | Custom DHCP domain name |
| `domain_name_servers` | `list(string)` | `["AmazonProvidedDNS"]` | DNS servers |
| `ntp_servers` | `list(string)` | `[]` | NTP servers |
| `netbios_name_servers` | `list(string)` | `[]` | NetBIOS name servers |
| `netbios_node_type` | `string` | `""` | NetBIOS node type |
| `create_resolver_inbound` | `bool` | `false` | Create inbound resolver endpoint |
| `resolver_inbound_subnet_ids` | `list(string)` | `[]` | Subnets for inbound ENIs |
| `resolver_inbound_security_group_ids` | `list(string)` | `[]` | SGs for inbound endpoint |
| `create_resolver_outbound` | `bool` | `false` | Create outbound resolver endpoint |
| `resolver_outbound_subnet_ids` | `list(string)` | `[]` | Subnets for outbound ENIs |
| `resolver_outbound_security_group_ids` | `list(string)` | `[]` | SGs for outbound endpoint |
| `resolver_rules` | `map(object)` | `{}` | Resolver forwarding rules |
| `tags` | `map(string)` | `{}` | Tags for all resources |

## Outputs

| Name | Description |
|------|-------------|
| `dhcp_options_id` | DHCP options set ID |
| `dhcp_options_association_id` | Association ID |
| `resolver_inbound_endpoint_id` | Inbound endpoint ID |
| `resolver_inbound_endpoint_ips` | Inbound endpoint IP addresses |
| `resolver_outbound_endpoint_id` | Outbound endpoint ID |
| `resolver_rule_ids` | Map of rule name → rule ID |
| `resolver_rule_arns` | Map of rule name → rule ARN |
| `resolver_rule_association_ids` | Map of rule name → association ID |

## Usage Example

```hcl
module "dns_dhcp" {
  source = "./modules/vpc-dns-dhcp"

  name   = "prod"
  vpc_id = module.vpc.vpc_id

  domain_name         = "corp.internal"
  domain_name_servers = ["10.0.0.2", "10.0.0.3"]
  ntp_servers         = ["169.254.169.123"]

  create_resolver_outbound             = true
  resolver_outbound_subnet_ids         = module.vpc.private_subnet_ids
  resolver_outbound_security_group_ids = [aws_security_group.resolver.id]

  resolver_rules = {
    corp-forward = {
      domain_name = "corp.internal"
      rule_type   = "FORWARD"
      target_ips  = [
        { ip = "10.1.0.10", port = 53 },
        { ip = "10.1.0.11", port = 53 },
      ]
    }
  }

  tags = { Environment = "production" }
}
```

## Concepts

### DHCP Options Sets
AWS VPCs use DHCP options sets to distribute network configuration to EC2 instances at boot. Key fields: `domain-name-servers` (default: AmazonProvidedDNS = 169.254.169.253 / VPC+2 address), `domain-name`, `ntp-servers`. Only one DHCP options set can be active per VPC at a time. Changes take effect on the next DHCP lease renewal.

### Amazon-Provided DNS (Route 53 Resolver)
Available at VPC CIDR base + 2 (e.g., 10.0.0.2 for 10.0.0.0/16) and at 169.254.169.253. Resolves public DNS, private hosted zone records, and internal AWS service endpoints. Must have `enableDnsSupport = true` in the VPC.

### Route 53 Resolver Endpoints
- **Inbound endpoint:** Creates ENIs in selected subnets. On-premises DNS servers forward queries for `aws.internal` zones to these IPs.
- **Outbound endpoint:** Creates ENIs that proxy outbound DNS queries. Forwarding rules direct specific domains to on-premises resolvers.
- Require at least 2 subnets in different AZs for HA.
- Resolver rules can be shared via AWS RAM for centralized DNS architectures.

### DNS in Hybrid Architectures
Exam scenario: VPN/DX-connected datacenter needs to resolve Route 53 private hosted zone records. Solution: Route 53 Resolver inbound endpoint + conditional forwarder on-premises pointing to the endpoint IPs. Reverse: outbound endpoint + FORWARD rules pointing at on-premises DNS.
