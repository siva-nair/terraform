##############################################################################
# DHCP Options Set
##############################################################################
resource "aws_vpc_dhcp_options" "this" {
  domain_name          = var.domain_name != "" ? var.domain_name : null
  domain_name_servers  = var.domain_name_servers
  ntp_servers          = length(var.ntp_servers) > 0 ? var.ntp_servers : null
  netbios_name_servers = length(var.netbios_name_servers) > 0 ? var.netbios_name_servers : null
  netbios_node_type    = var.netbios_node_type != "" ? var.netbios_node_type : null

  tags = merge(var.tags, { Name = "${var.name}-dhcp-options" })
}

resource "aws_vpc_dhcp_options_association" "this" {
  vpc_id          = var.vpc_id
  dhcp_options_id = aws_vpc_dhcp_options.this.id
}

##############################################################################
# Route 53 Resolver – Inbound Endpoint
##############################################################################
resource "aws_route53_resolver_endpoint" "inbound" {
  count = var.create_resolver_inbound ? 1 : 0

  name      = "${var.name}-resolver-inbound"
  direction = "INBOUND"

  security_group_ids = var.resolver_inbound_security_group_ids

  dynamic "ip_address" {
    for_each = var.resolver_inbound_subnet_ids
    content {
      subnet_id = ip_address.value
    }
  }

  tags = merge(var.tags, { Name = "${var.name}-resolver-inbound" })
}

##############################################################################
# Route 53 Resolver – Outbound Endpoint
##############################################################################
resource "aws_route53_resolver_endpoint" "outbound" {
  count = var.create_resolver_outbound ? 1 : 0

  name      = "${var.name}-resolver-outbound"
  direction = "OUTBOUND"

  security_group_ids = var.resolver_outbound_security_group_ids

  dynamic "ip_address" {
    for_each = var.resolver_outbound_subnet_ids
    content {
      subnet_id = ip_address.value
    }
  }

  tags = merge(var.tags, { Name = "${var.name}-resolver-outbound" })
}

##############################################################################
# Route 53 Resolver Rules
##############################################################################
resource "aws_route53_resolver_rule" "this" {
  for_each = var.create_resolver_outbound ? var.resolver_rules : {}

  name                 = "${var.name}-rule-${each.key}"
  domain_name          = each.value.domain_name
  rule_type            = each.value.rule_type
  resolver_endpoint_id = each.value.rule_type == "FORWARD" ? aws_route53_resolver_endpoint.outbound[0].id : null

  dynamic "target_ip" {
    for_each = each.value.rule_type == "FORWARD" ? each.value.target_ips : []
    content {
      ip   = target_ip.value.ip
      port = target_ip.value.port
    }
  }

  tags = merge(var.tags, { Name = "${var.name}-rule-${each.key}" })
}

resource "aws_route53_resolver_rule_association" "this" {
  for_each = var.create_resolver_outbound ? var.resolver_rules : {}

  resolver_rule_id = aws_route53_resolver_rule.this[each.key].id
  vpc_id           = var.vpc_id
}
