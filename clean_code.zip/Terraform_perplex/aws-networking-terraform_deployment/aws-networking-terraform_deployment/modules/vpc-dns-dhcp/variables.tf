variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to configure DNS/DHCP for."
  type        = string
}

# ── DHCP Options ──────────────────────────────────────────────────────────────
variable "domain_name" {
  description = "DHCP option: custom domain name (e.g. corp.internal)."
  type        = string
  default     = ""
}

variable "domain_name_servers" {
  description = "DHCP option: list of DNS server IPs. Use [\"AmazonProvidedDNS\"] to keep the default."
  type        = list(string)
  default     = ["AmazonProvidedDNS"]
}

variable "ntp_servers" {
  description = "DHCP option: list of NTP server IPs."
  type        = list(string)
  default     = []
}

variable "netbios_name_servers" {
  description = "DHCP option: NetBIOS name servers."
  type        = list(string)
  default     = []
}

variable "netbios_node_type" {
  description = "DHCP option: NetBIOS node type (1, 2, 4, or 8)."
  type        = string
  default     = ""
}

# ── Route 53 Resolver Inbound Endpoint ───────────────────────────────────────
variable "create_resolver_inbound" {
  description = "Create a Route 53 Resolver inbound endpoint."
  type        = bool
  default     = false
}

variable "resolver_inbound_subnet_ids" {
  description = "Subnet IDs for the inbound resolver endpoint ENIs (min 2 for HA)."
  type        = list(string)
  default     = []
}

variable "resolver_inbound_security_group_ids" {
  description = "Security group IDs for the inbound resolver endpoint."
  type        = list(string)
  default     = []
}

# ── Route 53 Resolver Outbound Endpoint ──────────────────────────────────────
variable "create_resolver_outbound" {
  description = "Create a Route 53 Resolver outbound endpoint."
  type        = bool
  default     = false
}

variable "resolver_outbound_subnet_ids" {
  description = "Subnet IDs for the outbound resolver endpoint ENIs (min 2 for HA)."
  type        = list(string)
  default     = []
}

variable "resolver_outbound_security_group_ids" {
  description = "Security group IDs for the outbound resolver endpoint."
  type        = list(string)
  default     = []
}

# ── Resolver Rules ────────────────────────────────────────────────────────────
variable "resolver_rules" {
  description = <<-EOT
    Map of Route 53 Resolver rules to create (requires create_resolver_outbound = true).
    Key = logical name
    Value = object with:
      domain_name    – DNS domain to forward (e.g. "corp.internal")
      rule_type      – FORWARD | SYSTEM | RECURSIVE
      target_ips     – list of { ip, port } objects for FORWARD rules
  EOT
  type = map(object({
    domain_name = string
    rule_type   = string
    target_ips = optional(list(object({
      ip   = string
      port = optional(number, 53)
    })), [])
  }))
  default = {}
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
