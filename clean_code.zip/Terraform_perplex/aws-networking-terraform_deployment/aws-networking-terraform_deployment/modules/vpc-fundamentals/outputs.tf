output "vpc_id" {
  description = "ID of the VPC."
  value       = aws_vpc.this.id
}

output "vpc_arn" {
  description = "ARN of the VPC."
  value       = aws_vpc.this.arn
}

output "vpc_cidr_block" {
  description = "Primary IPv4 CIDR block of the VPC."
  value       = aws_vpc.this.cidr_block
}

output "vpc_ipv6_cidr_block" {
  description = "Amazon-provided IPv6 CIDR block of the VPC (empty when IPv6 disabled)."
  value       = aws_vpc.this.ipv6_cidr_block
}

output "internet_gateway_id" {
  description = "ID of the Internet Gateway."
  value       = aws_internet_gateway.this.id
}

output "public_subnet_ids" {
  description = "List of public subnet IDs."
  value       = [for s in aws_subnet.public : s.id]
}

output "private_subnet_ids" {
  description = "List of private subnet IDs."
  value       = [for s in aws_subnet.private : s.id]
}

output "public_route_table_id" {
  description = "ID of the shared public route table."
  value       = aws_route_table.public.id
}

output "private_route_table_ids" {
  description = "List of private route table IDs (one per private subnet)."
  value       = [for rt in aws_route_table.private : rt.id]
}

output "nat_gateway_ids" {
  description = "List of NAT Gateway IDs."
  value       = [for ng in aws_nat_gateway.this : ng.id]
}

output "nat_gateway_public_ips" {
  description = "List of public Elastic IPs associated with the NAT Gateways."
  value       = [for eip in aws_eip.nat : eip.public_ip]
}

output "default_security_group_id" {
  description = "ID of the default (locked-down) security group."
  value       = aws_default_security_group.this.id
}

output "default_network_acl_id" {
  description = "ID of the default Network ACL."
  value       = aws_default_network_acl.this.id
}
