# vpc-fundamentals

Creates a production-ready VPC with public and private subnets spread across multiple Availability Zones, an Internet Gateway, NAT Gateways, route tables, and locked-down default NACL/SG.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpc` | Primary VPC with optional IPv6 |
| `aws_internet_gateway` | Provides outbound internet access for public subnets |
| `aws_subnet` (public) | One per AZ, `map_public_ip_on_launch = true` |
| `aws_subnet` (private) | One per AZ, no public IPs |
| `aws_eip` | Elastic IPs for NAT Gateways |
| `aws_nat_gateway` | One per AZ or one shared (single_nat_gateway) |
| `aws_route_table` (public) | Single table with 0.0.0.0/0 → IGW |
| `aws_route_table` (private) | One per private subnet, 0.0.0.0/0 → NAT GW |
| `aws_default_network_acl` | Tagged; preserves allow-all default rules |
| `aws_default_security_group` | Locked down (no ingress/egress rules) |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix for all resources |
| `cidr_block` | `string` | `10.0.0.0/16` | Primary VPC IPv4 CIDR |
| `enable_ipv6` | `bool` | `false` | Assign Amazon-provided IPv6 /56 |
| `az_count` | `number` | `2` | Number of AZs to use |
| `public_subnet_count` | `number` | `2` | Public subnets to create |
| `private_subnet_count` | `number` | `2` | Private subnets to create |
| `public_subnet_newbits` | `number` | `8` | Subnet size extension bits (public) |
| `private_subnet_newbits` | `number` | `8` | Subnet size extension bits (private) |
| `enable_nat_gateway` | `bool` | `true` | Create NAT Gateway(s) |
| `single_nat_gateway` | `bool` | `false` | Use one shared NAT GW instead of one-per-AZ |
| `enable_dns_hostnames` | `bool` | `true` | Enable DNS hostnames |
| `enable_dns_support` | `bool` | `true` | Enable DNS resolver |
| `tags` | `map(string)` | `{}` | Tags merged on all resources |

## Outputs

| Name | Description |
|------|-------------|
| `vpc_id` | VPC ID |
| `vpc_arn` | VPC ARN |
| `vpc_cidr_block` | Primary IPv4 CIDR |
| `vpc_ipv6_cidr_block` | IPv6 CIDR (if enabled) |
| `internet_gateway_id` | IGW ID |
| `public_subnet_ids` | List of public subnet IDs |
| `private_subnet_ids` | List of private subnet IDs |
| `public_route_table_id` | Public route table ID |
| `private_route_table_ids` | List of private route table IDs |
| `nat_gateway_ids` | List of NAT Gateway IDs |
| `nat_gateway_public_ips` | List of NAT Gateway EIPs |
| `default_security_group_id` | Default SG ID |
| `default_network_acl_id` | Default NACL ID |

## Usage Example

```hcl
module "vpc" {
  source = "./modules/vpc-fundamentals"

  name                 = "prod"
  cidr_block           = "10.10.0.0/16"
  enable_ipv6          = true
  az_count             = 3
  public_subnet_count  = 3
  private_subnet_count = 3
  single_nat_gateway   = false   # HA: one NAT GW per AZ

  tags = {
    Environment = "production"
    Owner       = "platform-team"
  }
}
```

## Concepts

### VPC Fundamentals (ANS-C01 Exam Prep)

**VPC (Virtual Private Cloud):** Logically isolated network within AWS. You control the IPv4 CIDR (RFC 1918 recommended), routing, subnets, and firewall rules. IPv6 is dual-stack; AWS assigns a /56 and you carve /64s per subnet.

**Subnets:** A subnet lives in a single AZ. _Public_ subnets have a route to an IGW; _private_ subnets do not. Spreading across AZs provides fault isolation (key exam concept: subnets are AZ-scoped, VPCs are region-scoped).

**Internet Gateway:** Horizontally scaled, redundant, HA component that allows direct internet access. One per VPC. Performs 1:1 NAT for instances with public IPs.

**NAT Gateway:** Managed, HA service for outbound-only internet access from private subnets. Deployed in a _public_ subnet with an Elastic IP. For HA, deploy one per AZ and route each private subnet to its own AZ's NAT GW — this avoids cross-AZ traffic charges and single points of failure.

**Route Tables:** Each subnet is associated with exactly one route table. The most-specific route wins (longest prefix match). The local route (VPC CIDR) is implicit and non-deletable.

**Network ACLs (NACLs):** Stateless, numbered rules applied at the subnet boundary. Evaluate both inbound and outbound. Default NACL allows all traffic. Custom NACLs deny all by default.

**Default Security Group:** Applied automatically to new resources if no SG is specified. Best practice: lock it down (no rules) so it acts as a deny-all catch-all.
