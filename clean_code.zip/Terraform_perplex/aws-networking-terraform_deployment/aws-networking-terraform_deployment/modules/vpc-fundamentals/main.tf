##############################################################################
# Data
##############################################################################
data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  az_names             = slice(data.aws_availability_zones.available.names, 0, var.az_count)
  public_subnet_count  = min(var.public_subnet_count, var.az_count)
  private_subnet_count = min(var.private_subnet_count, var.az_count)

  # NAT GW count: either 1 (shared) or one per private AZ
  nat_count = var.enable_nat_gateway ? (var.single_nat_gateway ? 1 : local.private_subnet_count) : 0
}

##############################################################################
# VPC
##############################################################################
resource "aws_vpc" "this" {
  cidr_block                       = var.cidr_block
  assign_generated_ipv6_cidr_block = var.enable_ipv6
  enable_dns_hostnames             = var.enable_dns_hostnames
  enable_dns_support               = var.enable_dns_support

  tags = merge(var.tags, { Name = var.name })
}

##############################################################################
# Internet Gateway
##############################################################################
resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id

  tags = merge(var.tags, { Name = "${var.name}-igw" })
}

##############################################################################
# Public Subnets
##############################################################################
resource "aws_subnet" "public" {
  for_each = { for i in range(local.public_subnet_count) : i => local.az_names[i] }

  vpc_id                          = aws_vpc.this.id
  availability_zone               = each.value
  cidr_block                      = cidrsubnet(var.cidr_block, var.public_subnet_newbits, each.key)
  map_public_ip_on_launch         = true
  assign_ipv6_address_on_creation = var.enable_ipv6
  ipv6_cidr_block                 = var.enable_ipv6 ? cidrsubnet(aws_vpc.this.ipv6_cidr_block, 8, each.key) : null

  tags = merge(var.tags, {
    Name = "${var.name}-public-${each.value}"
    Tier = "public"
  })
}

##############################################################################
# Private Subnets
##############################################################################
resource "aws_subnet" "private" {
  for_each = { for i in range(local.private_subnet_count) : i => local.az_names[i] }

  vpc_id                          = aws_vpc.this.id
  availability_zone               = each.value
  cidr_block                      = cidrsubnet(var.cidr_block, var.private_subnet_newbits, each.key + 128)
  assign_ipv6_address_on_creation = false

  tags = merge(var.tags, {
    Name = "${var.name}-private-${each.value}"
    Tier = "private"
  })
}

##############################################################################
# Public Route Table
##############################################################################
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }

  dynamic "route" {
    for_each = var.enable_ipv6 ? [1] : []
    content {
      ipv6_cidr_block = "::/0"
      gateway_id      = aws_internet_gateway.this.id
    }
  }

  tags = merge(var.tags, { Name = "${var.name}-public-rt" })
}

resource "aws_route_table_association" "public" {
  for_each = aws_subnet.public

  subnet_id      = each.value.id
  route_table_id = aws_route_table.public.id
}

##############################################################################
# NAT Gateways
##############################################################################
resource "aws_eip" "nat" {
  for_each = { for i in range(local.nat_count) : i => i }

  domain = "vpc"

  tags = merge(var.tags, { Name = "${var.name}-nat-eip-${each.key}" })
}

resource "aws_nat_gateway" "this" {
  for_each = { for i in range(local.nat_count) : i => i }

  allocation_id = aws_eip.nat[each.key].id
  # Place each NAT GW in the corresponding public subnet
  subnet_id = aws_subnet.public[each.key].id

  depends_on = [aws_internet_gateway.this]

  tags = merge(var.tags, { Name = "${var.name}-nat-${each.key}" })
}

##############################################################################
# Private Route Tables (one per private subnet / AZ)
##############################################################################
resource "aws_route_table" "private" {
  for_each = aws_subnet.private

  vpc_id = aws_vpc.this.id

  tags = merge(var.tags, { Name = "${var.name}-private-rt-${each.key}" })
}

# Default route via NAT GW (if enabled)
resource "aws_route" "private_nat" {
  for_each = var.enable_nat_gateway ? aws_subnet.private : {}

  route_table_id         = aws_route_table.private[each.key].id
  destination_cidr_block = "0.0.0.0/0"
  # In single-NAT mode, all private subnets route through NAT GW 0
  nat_gateway_id = var.single_nat_gateway ? aws_nat_gateway.this[0].id : aws_nat_gateway.this[each.key].id
}

resource "aws_route_table_association" "private" {
  for_each = aws_subnet.private

  subnet_id      = each.value.id
  route_table_id = aws_route_table.private[each.key].id
}

##############################################################################
# Default Network ACL (leave as-is, just tag it)
##############################################################################
resource "aws_default_network_acl" "this" {
  default_network_acl_id = aws_vpc.this.default_network_acl_id

  # Preserve default allow-all rules
  ingress {
    rule_no    = 100
    protocol   = "-1"
    action     = "allow"
    cidr_block = "0.0.0.0/0"
    from_port  = 0
    to_port    = 0
  }

  egress {
    rule_no    = 100
    protocol   = "-1"
    action     = "allow"
    cidr_block = "0.0.0.0/0"
    from_port  = 0
    to_port    = 0
  }

  tags = merge(var.tags, { Name = "${var.name}-default-nacl" })

  lifecycle {
    ignore_changes = [subnet_ids]
  }
}

##############################################################################
# Default Security Group (restrict all traffic)
##############################################################################
resource "aws_default_security_group" "this" {
  vpc_id = aws_vpc.this.id

  # No ingress/egress rules — locked-down default SG
  tags = merge(var.tags, { Name = "${var.name}-default-sg" })
}
