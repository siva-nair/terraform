variable "name" {
  description = "Name prefix applied to all resources."
  type        = string
}

variable "cidr_block" {
  description = "Primary IPv4 CIDR block for the VPC (e.g. 10.0.0.0/16)."
  type        = string
  default     = "10.0.0.0/16"
}

variable "enable_ipv6" {
  description = "Assign an Amazon-provided IPv6 /56 CIDR to the VPC."
  type        = bool
  default     = false
}

variable "az_count" {
  description = "Number of Availability Zones to use. Must be <= number of AZs in the region."
  type        = number
  default     = 2
}

variable "public_subnet_count" {
  description = "Number of public subnets to create (one per AZ up to az_count)."
  type        = number
  default     = 2
}

variable "private_subnet_count" {
  description = "Number of private subnets to create (one per AZ up to az_count)."
  type        = number
  default     = 2
}

variable "public_subnet_newbits" {
  description = "Number of additional bits to extend the VPC CIDR for each public subnet."
  type        = number
  default     = 8
}

variable "private_subnet_newbits" {
  description = "Number of additional bits to extend the VPC CIDR for each private subnet."
  type        = number
  default     = 8
}

variable "single_nat_gateway" {
  description = "If true, create one shared NAT Gateway in the first AZ instead of one per AZ."
  type        = bool
  default     = false
}

variable "enable_nat_gateway" {
  description = "If true, provision NAT Gateway(s) and route private subnets through them."
  type        = bool
  default     = true
}

variable "enable_dns_hostnames" {
  description = "Enable DNS hostnames in the VPC."
  type        = bool
  default     = true
}

variable "enable_dns_support" {
  description = "Enable DNS support (resolver) in the VPC."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
