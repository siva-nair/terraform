# transit-gateway

Creates an AWS Transit Gateway with VPC attachments, custom route tables, associations, propagations, static routes, and optional Resource Access Manager (RAM) sharing for cross-account connectivity.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_ec2_transit_gateway` | The TGW itself |
| `aws_ec2_transit_gateway_vpc_attachment` | VPC attachments (one per entry in `vpc_attachments`) |
| `aws_ec2_transit_gateway_route_table` | Custom route tables |
| `aws_ec2_transit_gateway_route_table_association` | Maps attachments to route tables |
| `aws_ec2_transit_gateway_route_table_propagation` | Propagates attachment routes into route tables |
| `aws_ec2_transit_gateway_route` | Static routes (including blackhole) |
| `aws_ram_resource_share` | RAM share for cross-account TGW sharing |
| `aws_ram_resource_association` | Associates TGW with the RAM share |
| `aws_ram_principal_association` | Grants RAM share access to accounts/OUs |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `amazon_side_asn` | `number` | `64512` | BGP ASN |
| `auto_accept_shared_attachments` | `string` | `disable` | Auto-accept cross-account attachments |
| `default_route_table_association` | `string` | `enable` | Use default route table for associations |
| `default_route_table_propagation` | `string` | `enable` | Use default route table for propagations |
| `dns_support` | `string` | `enable` | Enable DNS support |
| `vpn_ecmp_support` | `string` | `enable` | Enable ECMP for VPN |
| `multicast_support` | `string` | `disable` | Enable multicast |
| `vpc_attachments` | `map(object)` | `{}` | VPCs to attach |
| `route_tables` | `map(object)` | `{}` | Custom route tables to create |
| `route_table_associations` | `map(string)` | `{}` | Attachment → route table associations |
| `route_table_propagations` | `list(object)` | `[]` | Attachment → route table propagations |
| `static_routes` | `list(object)` | `[]` | Static TGW routes |
| `ram_share_enabled` | `bool` | `false` | Create RAM share |
| `ram_principals` | `list(string)` | `[]` | Account IDs or OU ARNs to share with |
| `ram_allow_external_principals` | `bool` | `false` | Allow external principals |
| `tags` | `map(string)` | `{}` | Tags |

## Outputs

| Name | Description |
|------|-------------|
| `transit_gateway_id` | TGW ID |
| `transit_gateway_arn` | TGW ARN |
| `transit_gateway_owner_id` | Owning account ID |
| `transit_gateway_default_route_table_id` | Default route table ID |
| `vpc_attachment_ids` | Map of name → attachment ID |
| `route_table_ids` | Map of name → route table ID |
| `ram_resource_share_arn` | RAM share ARN |

## Usage Example

```hcl
module "tgw" {
  source = "./modules/transit-gateway"

  name            = "prod"
  amazon_side_asn = 64512

  vpc_attachments = {
    app = {
      vpc_id     = module.app_vpc.vpc_id
      subnet_ids = module.app_vpc.private_subnet_ids
    }
    shared = {
      vpc_id     = module.shared_vpc.vpc_id
      subnet_ids = module.shared_vpc.private_subnet_ids
    }
    inspection = {
      vpc_id                 = module.inspection_vpc.vpc_id
      subnet_ids             = module.inspection_vpc.private_subnet_ids
      appliance_mode_support = "enable"  # stateful firewall
    }
  }

  route_tables = {
    prod      = {}
    shared    = {}
    inspection = {}
  }

  route_table_associations = {
    app       = "prod"
    shared    = "shared"
    inspection = "inspection"
  }

  route_table_propagations = [
    { attachment = "app",    route_table = "shared" },
    { attachment = "shared", route_table = "prod" },
  ]

  static_routes = [
    # Default route in prod table → inspection VPC (security inspection)
    { route_table = "prod", cidr = "0.0.0.0/0", attachment = "inspection" },
    # Blackhole RFC 1918 in inspection table to prevent loops
    { route_table = "inspection", cidr = "10.0.0.0/8", blackhole = true },
  ]

  ram_share_enabled = true
  ram_principals    = ["REDACTED_AWS_ARN"]

  tags = { Environment = "production" }
}
```

## Concepts

### Transit Gateway Architecture
TGW is a **regional** hub-and-spoke router that replaces complex VPC peering meshes. Attachments: VPC, VPN, Direct Connect Gateway, TGW Connect (GRE/BGP), peering (cross-region).

**Route tables separate traffic domains:**
- Each attachment associates to exactly one route table (lookup table for outbound traffic).
- Propagation adds the attachment's CIDR to a route table automatically.
- Static routes override or supplement propagations.

**Key design patterns:**
- **Flat:** All VPCs in the default route table → full mesh connectivity.
- **Segmented:** Separate route tables per environment (prod/dev/shared) → no lateral movement between environments.
- **Inspection:** Default route (0.0.0.0/0) in spoke route tables points to inspection VPC attachment (enable `appliance_mode_support` to keep flow symmetry for stateful firewalls).

### Appliance Mode
When a VPC hosts a stateful firewall or NAT appliance, `appliance_mode_support = "enable"` ensures that forward and return traffic use the same AZ's ENI — required for stateful inspection.

### RAM Sharing
TGW is a shareable resource. When shared to an account:
1. The receiving account sees the TGW and can create VPC attachments.
2. If `auto_accept_shared_attachments = "enable"` on the TGW, attachments are accepted automatically; otherwise the TGW owner must accept.
3. Route tables are NOT shared; only the TGW owner manages routing.

### ECMP for VPN
`vpn_ecmp_support = "enable"` allows multiple VPN tunnels or DX connections to load-balance traffic (requires matching BGP routes and active/active configuration).
