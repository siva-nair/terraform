output "transit_gateway_id" {
  description = "ID of the Transit Gateway."
  value       = aws_ec2_transit_gateway.this.id
}

output "transit_gateway_arn" {
  description = "ARN of the Transit Gateway."
  value       = aws_ec2_transit_gateway.this.arn
}

output "transit_gateway_owner_id" {
  description = "AWS account ID that owns the Transit Gateway."
  value       = aws_ec2_transit_gateway.this.owner_id
}

output "transit_gateway_default_route_table_id" {
  description = "ID of the default TGW route table."
  value       = aws_ec2_transit_gateway.this.association_default_route_table_id
}

output "vpc_attachment_ids" {
  description = "Map of logical attachment name → attachment ID."
  value       = { for k, v in aws_ec2_transit_gateway_vpc_attachment.this : k => v.id }
}

output "route_table_ids" {
  description = "Map of logical route table name → route table ID."
  value       = { for k, v in aws_ec2_transit_gateway_route_table.this : k => v.id }
}

output "ram_resource_share_arn" {
  description = "ARN of the RAM resource share for the TGW."
  value       = length(aws_ram_resource_share.tgw) > 0 ? aws_ram_resource_share.tgw[0].arn : null
}
