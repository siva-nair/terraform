##############################################################################
# Transit Gateway
##############################################################################
resource "aws_ec2_transit_gateway" "this" {
  description                     = "${var.name} Transit Gateway"
  amazon_side_asn                 = var.amazon_side_asn
  auto_accept_shared_attachments  = var.auto_accept_shared_attachments
  default_route_table_association = var.default_route_table_association
  default_route_table_propagation = var.default_route_table_propagation
  dns_support                     = var.dns_support
  vpn_ecmp_support                = var.vpn_ecmp_support
  multicast_support               = var.multicast_support

  tags = merge(var.tags, { Name = "${var.name}-tgw" })
}

##############################################################################
# VPC Attachments
##############################################################################
resource "aws_ec2_transit_gateway_vpc_attachment" "this" {
  for_each = var.vpc_attachments

  transit_gateway_id                              = aws_ec2_transit_gateway.this.id
  vpc_id                                          = each.value.vpc_id
  subnet_ids                                      = each.value.subnet_ids
  dns_support                                     = each.value.dns_support
  ipv6_support                                    = each.value.ipv6_support
  appliance_mode_support                          = each.value.appliance_mode_support
  transit_gateway_default_route_table_association = each.value.transit_gateway_default_route_table_association
  transit_gateway_default_route_table_propagation = each.value.transit_gateway_default_route_table_propagation

  tags = merge(var.tags, { Name = "${var.name}-tgw-attach-${each.key}" })
}

##############################################################################
# Custom TGW Route Tables
##############################################################################
resource "aws_ec2_transit_gateway_route_table" "this" {
  for_each = var.route_tables

  transit_gateway_id = aws_ec2_transit_gateway.this.id

  tags = merge(var.tags, { Name = "${var.name}-tgw-rt-${each.key}" })
}

##############################################################################
# Route Table Associations (attachment → route table)
##############################################################################
resource "aws_ec2_transit_gateway_route_table_association" "this" {
  for_each = var.route_table_associations

  transit_gateway_attachment_id  = aws_ec2_transit_gateway_vpc_attachment.this[each.key].id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.this[each.value].id
}

##############################################################################
# Route Table Propagations
##############################################################################
resource "aws_ec2_transit_gateway_route_table_propagation" "this" {
  for_each = {
    for p in var.route_table_propagations :
    "${p.attachment}-to-${p.route_table}" => p
  }

  transit_gateway_attachment_id  = aws_ec2_transit_gateway_vpc_attachment.this[each.value.attachment].id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.this[each.value.route_table].id
}

##############################################################################
# Static Routes
##############################################################################
resource "aws_ec2_transit_gateway_route" "this" {
  for_each = {
    for r in var.static_routes :
    "${r.route_table}-${r.cidr}" => r
  }

  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.this[each.value.route_table].id
  destination_cidr_block         = each.value.cidr
  transit_gateway_attachment_id  = each.value.blackhole ? null : (each.value.attachment != null ? aws_ec2_transit_gateway_vpc_attachment.this[each.value.attachment].id : null)
  blackhole                      = each.value.blackhole
}

##############################################################################
# Resource Access Manager Share
##############################################################################
resource "aws_ram_resource_share" "tgw" {
  count = var.ram_share_enabled ? 1 : 0

  name                      = "${var.name}-tgw-ram-share"
  allow_external_principals = var.ram_allow_external_principals

  tags = merge(var.tags, { Name = "${var.name}-tgw-ram-share" })
}

resource "aws_ram_resource_association" "tgw" {
  count = var.ram_share_enabled ? 1 : 0

  resource_share_arn = aws_ram_resource_share.tgw[0].arn
  resource_arn       = aws_ec2_transit_gateway.this.arn
}

resource "aws_ram_principal_association" "tgw" {
  for_each = var.ram_share_enabled ? toset(var.ram_principals) : toset([])

  resource_share_arn = aws_ram_resource_share.tgw[0].arn
  principal          = each.value
}
