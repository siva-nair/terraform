variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

# ── Transit Gateway ────────────────────────────────────────────────────────────
variable "amazon_side_asn" {
  description = "BGP ASN for the Transit Gateway (64512–65534 or 4200000000–4294967294)."
  type        = number
  default     = 64512
}

variable "auto_accept_shared_attachments" {
  description = "Auto-accept cross-account VPC attachment requests."
  type        = string
  default     = "disable"

  validation {
    condition     = contains(["enable", "disable"], var.auto_accept_shared_attachments)
    error_message = "Must be 'enable' or 'disable'."
  }
}

variable "default_route_table_association" {
  description = "Associate attachments with the default TGW route table automatically."
  type        = string
  default     = "enable"
}

variable "default_route_table_propagation" {
  description = "Propagate attachment routes to the default TGW route table automatically."
  type        = string
  default     = "enable"
}

variable "dns_support" {
  description = "Enable DNS support on the TGW."
  type        = string
  default     = "enable"
}

variable "vpn_ecmp_support" {
  description = "Enable Equal Cost Multipath for VPN connections."
  type        = string
  default     = "enable"
}

variable "multicast_support" {
  description = "Enable multicast on the Transit Gateway."
  type        = string
  default     = "disable"
}

# ── VPC Attachments ────────────────────────────────────────────────────────────
variable "vpc_attachments" {
  description = <<-EOT
    Map of VPC attachments.
    Key = logical name (e.g. "app", "shared")
    Value = object with:
      vpc_id         – ID of the VPC to attach
      subnet_ids     – List of subnet IDs (one per AZ) for the TGW ENIs
      dns_support    – "enable" | "disable" (default "enable")
      ipv6_support   – "enable" | "disable" (default "disable")
      appliance_mode_support – "enable" | "disable" (default "disable")
      transit_gateway_default_route_table_association – bool (default true)
      transit_gateway_default_route_table_propagation – bool (default true)
  EOT
  type = map(object({
    vpc_id                                          = string
    subnet_ids                                      = list(string)
    dns_support                                     = optional(string, "enable")
    ipv6_support                                    = optional(string, "disable")
    appliance_mode_support                          = optional(string, "disable")
    transit_gateway_default_route_table_association = optional(bool, true)
    transit_gateway_default_route_table_propagation = optional(bool, true)
  }))
  default = {}
}

# ── TGW Route Tables ───────────────────────────────────────────────────────────
variable "route_tables" {
  description = <<-EOT
    Map of custom TGW route tables to create.
    Key = logical name (e.g. "prod", "shared", "inspection")
  EOT
  type        = map(object({}))
  default     = {}
}

variable "route_table_associations" {
  description = <<-EOT
    Map of attachment→route table associations.
    Key = attachment logical name (must match key in vpc_attachments)
    Value = route table logical name (must match key in route_tables)
  EOT
  type        = map(string)
  default     = {}
}

variable "route_table_propagations" {
  description = <<-EOT
    List of attachment→route table propagation pairs.
    Each entry: { attachment = "app", route_table = "shared" }
  EOT
  type = list(object({
    attachment  = string
    route_table = string
  }))
  default = []
}

variable "static_routes" {
  description = <<-EOT
    List of static routes to add to TGW route tables.
    Each entry:
      route_table   – logical name matching key in route_tables
      cidr          – destination CIDR block
      attachment    – logical name matching key in vpc_attachments (null = blackhole)
      blackhole     – bool (default false)
  EOT
  type = list(object({
    route_table = string
    cidr        = string
    attachment  = optional(string)
    blackhole   = optional(bool, false)
  }))
  default = []
}

# ── Resource Access Manager (RAM) ─────────────────────────────────────────────
variable "ram_share_enabled" {
  description = "Create a RAM resource share to share the TGW with other accounts/OUs."
  type        = bool
  default     = false
}

variable "ram_principals" {
  description = "List of account IDs or OU ARNs to share the TGW with."
  type        = list(string)
  default     = []
}

variable "ram_allow_external_principals" {
  description = "Allow sharing with principals outside the AWS Organization."
  type        = bool
  default     = false
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
