output "nacl_id" {
  description = "ID of the Network ACL (if created)."
  value       = var.create_nacl ? aws_network_acl.this[0].id : null
}

output "security_group_ids" {
  description = "Map of security group logical name to ID."
  value = {
    for k, v in aws_security_group.this : k => v.id
  }
}

output "security_group_arns" {
  description = "Map of security group logical name to ARN."
  value = {
    for k, v in aws_security_group.this : k => v.arn
  }
}

output "firewall_id" {
  description = "ID of the AWS Network Firewall (if created)."
  value       = var.create_network_firewall ? aws_networkfirewall_firewall.this[0].id : null
}

output "firewall_arn" {
  description = "ARN of the AWS Network Firewall (if created)."
  value       = var.create_network_firewall ? aws_networkfirewall_firewall.this[0].arn : null
}

output "firewall_status" {
  description = "Firewall status including sync state and endpoint IDs per AZ."
  value       = var.create_network_firewall ? aws_networkfirewall_firewall.this[0].firewall_status : null
}

output "firewall_policy_arn" {
  description = "ARN of the firewall policy (if created)."
  value       = var.create_network_firewall ? aws_networkfirewall_firewall_policy.this[0].arn : null
}

output "waf_web_acl_id" {
  description = "ID of the WAFv2 Web ACL (if created)."
  value       = var.create_waf ? aws_wafv2_web_acl.this[0].id : null
}

output "waf_web_acl_arn" {
  description = "ARN of the WAFv2 Web ACL (if created)."
  value       = var.create_waf ? aws_wafv2_web_acl.this[0].arn : null
}

output "shield_protection_ids" {
  description = "Map of resource ARN to Shield Advanced protection ID."
  value = {
    for k, v in aws_shield_protection.this : k => v.id
  }
}
