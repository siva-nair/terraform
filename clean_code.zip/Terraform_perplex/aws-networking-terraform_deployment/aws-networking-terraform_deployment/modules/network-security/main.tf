data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  common_tags = merge(
    {
      Name      = var.name
      ManagedBy = "terraform"
    },
    var.tags
  )
}

# ---------------------------------------------------------------------------
# Network ACL
# ---------------------------------------------------------------------------
resource "aws_network_acl" "this" {
  count = var.create_nacl ? 1 : 0

  vpc_id     = var.vpc_id
  subnet_ids = var.nacl_subnet_ids

  dynamic "ingress" {
    for_each = var.nacl_ingress_rules
    content {
      rule_no    = ingress.value.rule_no
      protocol   = ingress.value.protocol
      action     = ingress.value.action
      cidr_block = ingress.value.cidr_block
      from_port  = ingress.value.from_port
      to_port    = ingress.value.to_port
      icmp_type  = ingress.value.icmp_type
      icmp_code  = ingress.value.icmp_code
    }
  }

  dynamic "egress" {
    for_each = var.nacl_egress_rules
    content {
      rule_no    = egress.value.rule_no
      protocol   = egress.value.protocol
      action     = egress.value.action
      cidr_block = egress.value.cidr_block
      from_port  = egress.value.from_port
      to_port    = egress.value.to_port
      icmp_type  = egress.value.icmp_type
      icmp_code  = egress.value.icmp_code
    }
  }

  tags = merge(local.common_tags, { Name = "${var.name}-nacl" })
}

# ---------------------------------------------------------------------------
# Security Groups
# ---------------------------------------------------------------------------
resource "aws_security_group" "this" {
  for_each = var.security_groups

  name        = "${var.name}-${each.key}"
  description = each.value.description
  vpc_id      = var.vpc_id

  dynamic "ingress" {
    for_each = each.value.ingress_rules
    content {
      description = ingress.value.description
      protocol    = ingress.value.protocol
      from_port   = ingress.value.from_port
      to_port     = ingress.value.to_port
      cidr_blocks = length(ingress.value.cidr_blocks) > 0 ? ingress.value.cidr_blocks : null
      self        = ingress.value.self
    }
  }

  dynamic "egress" {
    for_each = each.value.egress_rules
    content {
      description = egress.value.description
      protocol    = egress.value.protocol
      from_port   = egress.value.from_port
      to_port     = egress.value.to_port
      cidr_blocks = egress.value.cidr_blocks
    }
  }

  tags = merge(local.common_tags, { Name = "${var.name}-${each.key}" })

  lifecycle {
    create_before_destroy = true
  }
}

# ---------------------------------------------------------------------------
# Network Firewall — Stateless Rule Group
# ---------------------------------------------------------------------------
resource "aws_networkfirewall_rule_group" "stateless" {
  count = var.create_network_firewall && length(var.stateless_rules) > 0 ? 1 : 0

  name        = "${var.name}-stateless-rg"
  capacity    = 100
  type        = "STATELESS"
  description = "Stateless rule group for ${var.name}"

  rule_group {
    rules_source {
      stateless_rules_and_custom_actions {
        dynamic "stateless_rule" {
          for_each = var.stateless_rules
          content {
            priority = stateless_rule.value.priority
            rule_definition {
              actions = stateless_rule.value.actions
              match_attributes {
                dynamic "source" {
                  for_each = stateless_rule.value.source_cidrs
                  content {
                    address_definition = source.value
                  }
                }
                dynamic "destination" {
                  for_each = stateless_rule.value.dest_cidrs
                  content {
                    address_definition = destination.value
                  }
                }
                protocols = stateless_rule.value.protocols
              }
            }
          }
        }
      }
    }
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Network Firewall — Stateful Rule Groups (Suricata IDS format)
# ---------------------------------------------------------------------------
resource "aws_networkfirewall_rule_group" "stateful" {
  for_each = var.create_network_firewall ? {
    for rg in var.stateful_rule_groups : rg.name => rg
  } : {}

  name        = "${var.name}-${each.key}-stateful-rg"
  capacity    = each.value.capacity
  type        = "STATEFUL"
  description = "Stateful rule group ${each.key}"

  rule_group {
    rules_source {
      rules_string = each.value.rules
    }
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Network Firewall Policy
# ---------------------------------------------------------------------------
resource "aws_networkfirewall_firewall_policy" "this" {
  count = var.create_network_firewall ? 1 : 0

  name        = "${var.name}-fw-policy"
  description = "Firewall policy for ${var.name}"

  firewall_policy {
    stateless_default_actions          = var.stateless_default_actions
    stateless_fragment_default_actions = var.stateless_fragment_default_actions

    dynamic "stateless_rule_group_reference" {
      for_each = length(var.stateless_rules) > 0 ? [1] : []
      content {
        priority     = 1
        resource_arn = aws_networkfirewall_rule_group.stateless[0].arn
      }
    }

    dynamic "stateful_rule_group_reference" {
      for_each = aws_networkfirewall_rule_group.stateful
      content {
        resource_arn = stateful_rule_group_reference.value.arn
      }
    }
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Network Firewall
# ---------------------------------------------------------------------------
resource "aws_networkfirewall_firewall" "this" {
  count = var.create_network_firewall ? 1 : 0

  name                = "${var.name}-firewall"
  vpc_id              = var.vpc_id
  firewall_policy_arn = aws_networkfirewall_firewall_policy.this[0].arn
  delete_protection   = var.firewall_delete_protection

  dynamic "subnet_mapping" {
    for_each = var.firewall_subnet_ids
    content {
      subnet_id = subnet_mapping.value
    }
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# WAFv2 Web ACL
# ---------------------------------------------------------------------------
resource "aws_wafv2_web_acl" "this" {
  count = var.create_waf ? 1 : 0

  name  = "${var.name}-waf"
  scope = var.waf_scope

  default_action {
    dynamic "allow" {
      for_each = var.waf_default_action == "allow" ? [1] : []
      content {}
    }
    dynamic "block" {
      for_each = var.waf_default_action == "block" ? [1] : []
      content {}
    }
  }

  dynamic "rule" {
    for_each = var.waf_managed_rule_groups
    content {
      name     = rule.value.name
      priority = rule.value.priority

      override_action {
        dynamic "none" {
          for_each = rule.value.override_action == "none" ? [1] : []
          content {}
        }
        dynamic "count" {
          for_each = rule.value.override_action == "count" ? [1] : []
          content {}
        }
      }

      statement {
        managed_rule_group_statement {
          name        = rule.value.name
          vendor_name = rule.value.vendor_name
        }
      }

      visibility_config {
        cloudwatch_metrics_enabled = true
        metric_name                = "${var.name}-${rule.value.name}"
        sampled_requests_enabled   = true
      }
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "${var.name}-waf"
    sampled_requests_enabled   = true
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# AWS Shield Advanced Protection
# ---------------------------------------------------------------------------
resource "aws_shield_protection" "this" {
  for_each = var.enable_shield_advanced ? toset(var.shield_resource_arns) : []

  name         = "${var.name}-shield-${index(var.shield_resource_arns, each.value)}"
  resource_arn = each.value

  tags = local.common_tags
}
