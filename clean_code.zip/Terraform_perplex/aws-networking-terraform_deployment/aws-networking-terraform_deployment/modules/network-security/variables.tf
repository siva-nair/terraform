variable "name" {
  description = "Name prefix for all network security resources."
  type        = string
}

variable "vpc_id" {
  description = "VPC ID where security resources will be created."
  type        = string
}

# ---------------------------------------------------------------------------
# Network ACL
# ---------------------------------------------------------------------------
variable "create_nacl" {
  description = "Whether to create a Network ACL."
  type        = bool
  default     = true
}

variable "nacl_subnet_ids" {
  description = "Subnet IDs to associate with the Network ACL."
  type        = list(string)
  default     = []
}

variable "nacl_ingress_rules" {
  description = "List of NACL ingress rules."
  type = list(object({
    rule_no    = number
    protocol   = string
    action     = string
    cidr_block = string
    from_port  = optional(number, 0)
    to_port    = optional(number, 0)
    icmp_type  = optional(number, null)
    icmp_code  = optional(number, null)
  }))
  default = [
    {
      rule_no    = 100
      protocol   = "-1"
      action     = "allow"
      cidr_block = "0.0.0.0/0"
    }
  ]
}

variable "nacl_egress_rules" {
  description = "List of NACL egress rules."
  type = list(object({
    rule_no    = number
    protocol   = string
    action     = string
    cidr_block = string
    from_port  = optional(number, 0)
    to_port    = optional(number, 0)
    icmp_type  = optional(number, null)
    icmp_code  = optional(number, null)
  }))
  default = [
    {
      rule_no    = 100
      protocol   = "-1"
      action     = "allow"
      cidr_block = "0.0.0.0/0"
    }
  ]
}

# ---------------------------------------------------------------------------
# Security Groups
# ---------------------------------------------------------------------------
variable "security_groups" {
  description = "Map of security group definitions. Key is a logical name."
  type = map(object({
    description = string
    ingress_rules = optional(list(object({
      description = optional(string, "")
      protocol    = string
      from_port   = number
      to_port     = number
      cidr_blocks = optional(list(string), [])
      self        = optional(bool, false)
    })), [])
    egress_rules = optional(list(object({
      description = optional(string, "")
      protocol    = string
      from_port   = number
      to_port     = number
      cidr_blocks = optional(list(string), ["0.0.0.0/0"])
    })), [{ description = "Allow all egress", protocol = "-1", from_port = 0, to_port = 0, cidr_blocks = ["0.0.0.0/0"] }])
  }))
  default = {}
}

# ---------------------------------------------------------------------------
# AWS Network Firewall
# ---------------------------------------------------------------------------
variable "create_network_firewall" {
  description = "Whether to create an AWS Network Firewall."
  type        = bool
  default     = false
}

variable "firewall_subnet_ids" {
  description = "Subnet IDs for Network Firewall endpoints (one per AZ)."
  type        = list(string)
  default     = []
}

variable "firewall_delete_protection" {
  description = "Prevent the firewall from being deleted."
  type        = bool
  default     = false
}

variable "stateless_default_actions" {
  description = "Default action for packets that don't match any stateless rule. e.g. ['aws:forward_to_sfe']."
  type        = list(string)
  default     = ["aws:forward_to_sfe"]
}

variable "stateless_fragment_default_actions" {
  description = "Default action for fragmented packets."
  type        = list(string)
  default     = ["aws:forward_to_sfe"]
}

variable "stateless_rules" {
  description = "List of stateless firewall rules."
  type = list(object({
    priority     = number
    actions      = list(string)
    protocols    = optional(list(number), [])
    source_cidrs = optional(list(string), [])
    dest_cidrs   = optional(list(string), [])
  }))
  default = []
}

variable "stateful_rule_groups" {
  description = "List of stateful rule group configurations (Suricata IDS rules as strings)."
  type = list(object({
    name     = string
    capacity = optional(number, 100)
    rules    = optional(string, "")
  }))
  default = []
}

# ---------------------------------------------------------------------------
# WAFv2
# ---------------------------------------------------------------------------
variable "create_waf" {
  description = "Whether to create a WAFv2 Web ACL."
  type        = bool
  default     = false
}

variable "waf_scope" {
  description = "WAFv2 scope: REGIONAL (for ALB/API GW) or CLOUDFRONT (must be us-east-1)."
  type        = string
  default     = "REGIONAL"
}

variable "waf_managed_rule_groups" {
  description = "List of AWS managed rule groups to attach to the WAF."
  type = list(object({
    name            = string
    vendor_name     = optional(string, "AWS")
    priority        = number
    override_action = optional(string, "none") # none or count
  }))
  default = [
    {
      name     = "AWSManagedRulesCommonRuleSet"
      priority = 10
    },
    {
      name     = "AWSManagedRulesKnownBadInputsRuleSet"
      priority = 20
    }
  ]
}

variable "waf_default_action" {
  description = "Default action when no rule matches: allow or block."
  type        = string
  default     = "allow"
}

# ---------------------------------------------------------------------------
# Shield Advanced
# ---------------------------------------------------------------------------
variable "enable_shield_advanced" {
  description = "Whether to enable AWS Shield Advanced protection on specified resources."
  type        = bool
  default     = false
}

variable "shield_resource_arns" {
  description = "List of resource ARNs to protect with Shield Advanced."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Map of tags to apply to all resources."
  type        = map(string)
  default     = {}
}
