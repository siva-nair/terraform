# network-security

Terraform module for AWS network security services — **Network ACLs**, **Security Groups**, **AWS Network Firewall**, **WAFv2**, and **AWS Shield Advanced**.

## Resources Created

| Resource | Description |
|---|---|
| `aws_network_acl` | Stateless subnet-level packet filter with ordered rules |
| `aws_security_group` | Instance-level stateful firewall with ingress/egress rules |
| `aws_networkfirewall_rule_group` | Stateless and stateful (Suricata IDS) rule groups |
| `aws_networkfirewall_firewall_policy` | Policy combining rule groups |
| `aws_networkfirewall_firewall` | Network Firewall endpoints in specified subnets |
| `aws_wafv2_web_acl` | WAFv2 Web ACL with AWS managed rule groups |
| `aws_shield_protection` | Shield Advanced protection for resources (optional) |

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| `name` | Resource name prefix | `string` | — | yes |
| `vpc_id` | VPC ID | `string` | — | yes |
| `create_nacl` | Create a Network ACL | `bool` | `true` | no |
| `nacl_subnet_ids` | Subnets for NACL association | `list(string)` | `[]` | no |
| `nacl_ingress_rules` | NACL ingress rule list | `list(object)` | allow-all | no |
| `nacl_egress_rules` | NACL egress rule list | `list(object)` | allow-all | no |
| `security_groups` | Map of security group definitions | `map(object)` | `{}` | no |
| `create_network_firewall` | Create AWS Network Firewall | `bool` | `false` | no |
| `firewall_subnet_ids` | Subnets for firewall endpoints | `list(string)` | `[]` | no |
| `stateless_rules` | Stateless firewall rules | `list(object)` | `[]` | no |
| `stateful_rule_groups` | Stateful Suricata rule groups | `list(object)` | `[]` | no |
| `create_waf` | Create WAFv2 Web ACL | `bool` | `false` | no |
| `waf_scope` | `REGIONAL` or `CLOUDFRONT` | `string` | `REGIONAL` | no |
| `waf_managed_rule_groups` | Managed rule groups for WAF | `list(object)` | Common + KnownBad | no |
| `enable_shield_advanced` | Enable Shield Advanced | `bool` | `false` | no |
| `shield_resource_arns` | ARNs to protect | `list(string)` | `[]` | no |
| `tags` | Tags for all resources | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|---|---|
| `nacl_id` | Network ACL ID |
| `security_group_ids` | Map of SG name → ID |
| `security_group_arns` | Map of SG name → ARN |
| `firewall_id` | Network Firewall ID |
| `firewall_arn` | Network Firewall ARN |
| `firewall_status` | Firewall sync state and endpoint IDs |
| `firewall_policy_arn` | Firewall Policy ARN |
| `waf_web_acl_id` | WAFv2 Web ACL ID |
| `waf_web_acl_arn` | WAFv2 Web ACL ARN |
| `shield_protection_ids` | Map of resource ARN → Shield protection ID |

## Usage Example

```hcl
module "network_security" {
  source = "./modules/network-security"

  name   = "prod-security"
  vpc_id = module.vpc.vpc_id

  # NACL with specific rules
  create_nacl     = true
  nacl_subnet_ids = module.vpc.private_subnet_ids
  nacl_ingress_rules = [
    { rule_no = 100, protocol = "6", action = "allow", cidr_block = "10.0.0.0/8", from_port = 443, to_port = 443 },
    { rule_no = 200, protocol = "6", action = "allow", cidr_block = "0.0.0.0/0", from_port = 1024, to_port = 65535 },
    { rule_no = 32766, protocol = "-1", action = "deny", cidr_block = "0.0.0.0/0" }
  ]

  security_groups = {
    web = {
      description = "Web tier security group"
      ingress_rules = [
        { protocol = "tcp", from_port = 443, to_port = 443, cidr_blocks = ["0.0.0.0/0"] },
        { protocol = "tcp", from_port = 80, to_port = 80, cidr_blocks = ["0.0.0.0/0"] }
      ]
    }
  }

  create_network_firewall = true
  firewall_subnet_ids     = module.vpc.firewall_subnet_ids
  stateful_rule_groups = [
    {
      name     = "block-bad-domains"
      capacity = 100
      rules    = "drop dns any any -> any any (dns.query; content:\"malware.example.com\"; sid:1;)"
    }
  ]

  create_waf = true
  waf_scope  = "REGIONAL"

  enable_shield_advanced = true
  shield_resource_arns   = [module.alb.lb_arn]

  tags = { Environment = "prod" }
}
```

## Concepts (Exam Prep)

- **NACLs vs Security Groups**:
  - NACLs are **stateless** (must allow return traffic explicitly), applied at the **subnet** level, processed in **rule number order** (lowest first), and have explicit DENY rules.
  - Security Groups are **stateful** (return traffic auto-allowed), applied at the **ENI** level, **all rules evaluated** before decision, and only support ALLOW rules.
- **AWS Network Firewall**: Managed, scalable, stateful network firewall deployed in subnet endpoints. Supports Suricata-compatible IDS/IPS rules, domain lists, and 5-tuple stateless rules. Traffic is routed to the firewall via route table entries pointing to GWLBe or firewall endpoints.
- **WAFv2**: Layer 7 firewall protecting HTTP/HTTPS traffic against OWASP Top 10 and custom threats. Supports managed rule groups, rate limiting, IP sets, regex patterns, and geo-match conditions. REGIONAL scope for ALB/API GW/App Runner; CLOUDFRONT scope (us-east-1 only) for distributions.
- **Shield Standard vs Advanced**: Standard is free and automatic (Layer 3/4 DDoS). Advanced ($3000/month + data transfer) adds Layer 7 protection, DRT access, cost protection, and Route 53 and CloudFront health-based detection.
- **Layered security**: Best practice is to use NACLs as a coarse subnet-level filter, Security Groups as the primary instance-level control, and Network Firewall / WAF for deep packet inspection and application-layer filtering.
