variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "customer_gateway_id" {
  description = "ID of the Customer Gateway (on-premises router)."
  type        = string
}

# ── Gateway Target (VGW or TGW) ───────────────────────────────────────────────
variable "gateway_type" {
  description = "Target gateway type: vgw (Virtual Private Gateway) or tgw (Transit Gateway)."
  type        = string
  default     = "vgw"

  validation {
    condition     = contains(["vgw", "tgw"], var.gateway_type)
    error_message = "gateway_type must be 'vgw' or 'tgw'."
  }
}

variable "vpn_gateway_id" {
  description = "ID of the Virtual Private Gateway (used when gateway_type = vgw)."
  type        = string
  default     = null
}

variable "transit_gateway_id" {
  description = "ID of the Transit Gateway (used when gateway_type = tgw)."
  type        = string
  default     = null
}

# ── Routing ───────────────────────────────────────────────────────────────────
variable "static_routes_only" {
  description = "Use static routing only (no BGP). Set to false to enable BGP/dynamic routing."
  type        = bool
  default     = false
}

variable "static_routes" {
  description = "List of on-premises CIDR blocks for static routing (used when static_routes_only = true)."
  type        = list(string)
  default     = []
}

# ── Accelerated VPN ───────────────────────────────────────────────────────────
variable "enable_acceleration" {
  description = "Enable AWS Global Accelerator for the VPN connection (reduces latency). Requires transit_gateway_id."
  type        = bool
  default     = false
}

# ── Tunnel Options ─────────────────────────────────────────────────────────────
variable "tunnel_options" {
  description = <<-EOT
    List of exactly 0, 1, or 2 tunnel option objects (one per tunnel).
    If empty, AWS auto-generates all parameters.
    Each object:
      dpd_timeout_action          – "clear" | "none" | "restart" (default "clear")
      dpd_timeout_seconds         – int (default 30)
      ike_versions                – list of strings ["ikev1"] | ["ikev2"] | ["ikev1","ikev2"]
      phase1_dh_group_numbers     – list of ints
      phase1_encryption_algorithms – list of strings
      phase1_integrity_algorithms – list of strings
      phase1_lifetime_seconds     – int (default 28800)
      phase2_dh_group_numbers     – list of ints
      phase2_encryption_algorithms – list of strings
      phase2_integrity_algorithms – list of strings
      phase2_lifetime_seconds     – int (default 3600)
      rekey_fuzz_percentage       – int (0–100, default 100)
      replay_window_size          – int (default 1024)
      startup_action              – "add" | "start" (default "add")
      tunnel_cidr                 – /30 CIDR from 169.254.0.0/16 for tunnel inside IP
      preshared_key               – pre-shared key string (min 8 chars, alphanumeric + _)
  EOT
  type = list(object({
    dpd_timeout_action           = optional(string, "clear")
    dpd_timeout_seconds          = optional(number, 30)
    ike_versions                 = optional(list(string), ["ikev2"])
    phase1_dh_group_numbers      = optional(list(number))
    phase1_encryption_algorithms = optional(list(string))
    phase1_integrity_algorithms  = optional(list(string))
    phase1_lifetime_seconds      = optional(number, 28800)
    phase2_dh_group_numbers      = optional(list(number))
    phase2_encryption_algorithms = optional(list(string))
    phase2_integrity_algorithms  = optional(list(string))
    phase2_lifetime_seconds      = optional(number, 3600)
    rekey_fuzz_percentage        = optional(number, 100)
    replay_window_size           = optional(number, 1024)
    startup_action               = optional(string, "add")
    tunnel_cidr                  = optional(string)
    preshared_key                = optional(string)
  }))
  default = []

  validation {
    condition     = length(var.tunnel_options) <= 2
    error_message = "At most 2 tunnel option objects can be specified (one per tunnel)."
  }
}

variable "local_ipv4_network_cidr" {
  description = "IPv4 CIDR on the AWS side to allow through the VPN (default 0.0.0.0/0)."
  type        = string
  default     = "0.0.0.0/0"
}

variable "remote_ipv4_network_cidr" {
  description = "IPv4 CIDR on the on-premises side to allow through the VPN (default 0.0.0.0/0)."
  type        = string
  default     = "0.0.0.0/0"
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
