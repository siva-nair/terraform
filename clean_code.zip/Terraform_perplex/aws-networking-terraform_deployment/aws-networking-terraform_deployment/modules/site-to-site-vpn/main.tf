##############################################################################
# Locals – split tunnel options into tunnel1 / tunnel2 blocks
##############################################################################
locals {
  tunnel1_opts = length(var.tunnel_options) >= 1 ? var.tunnel_options[0] : null
  tunnel2_opts = length(var.tunnel_options) >= 2 ? var.tunnel_options[1] : null
}

##############################################################################
# Site-to-Site VPN Connection
##############################################################################
resource "aws_vpn_connection" "this" {
  customer_gateway_id      = var.customer_gateway_id
  type                     = "ipsec.1"
  static_routes_only       = var.static_routes_only
  enable_acceleration      = var.enable_acceleration
  local_ipv4_network_cidr  = var.local_ipv4_network_cidr
  remote_ipv4_network_cidr = var.remote_ipv4_network_cidr

  # VGW or TGW target
  vpn_gateway_id     = var.gateway_type == "vgw" ? var.vpn_gateway_id : null
  transit_gateway_id = var.gateway_type == "tgw" ? var.transit_gateway_id : null

  ##########################################################################
  # Tunnel 1 options (dynamic block renders only when tunnel_options[0] set)
  ##########################################################################
  dynamic "tunnel1_log_options" {
    for_each = local.tunnel1_opts != null ? [1] : []
    content {
      cloudwatch_log_options {
        log_enabled       = true
        log_group_arn     = aws_cloudwatch_log_group.vpn_tunnel1[0].arn
        log_output_format = "json"
      }
    }
  }

  tunnel1_inside_cidr   = local.tunnel1_opts != null ? local.tunnel1_opts.tunnel_cidr : null
  tunnel1_preshared_key = local.tunnel1_opts != null ? local.tunnel1_opts.preshared_key : null

  tunnel1_phase1_dh_group_numbers      = (local.tunnel1_opts != null && local.tunnel1_opts.phase1_dh_group_numbers != null) ? local.tunnel1_opts.phase1_dh_group_numbers : null
  tunnel1_phase1_encryption_algorithms = (local.tunnel1_opts != null && local.tunnel1_opts.phase1_encryption_algorithms != null) ? local.tunnel1_opts.phase1_encryption_algorithms : null
  tunnel1_phase1_integrity_algorithms  = (local.tunnel1_opts != null && local.tunnel1_opts.phase1_integrity_algorithms != null) ? local.tunnel1_opts.phase1_integrity_algorithms : null
  tunnel1_phase2_dh_group_numbers      = (local.tunnel1_opts != null && local.tunnel1_opts.phase2_dh_group_numbers != null) ? local.tunnel1_opts.phase2_dh_group_numbers : null
  tunnel1_phase2_encryption_algorithms = (local.tunnel1_opts != null && local.tunnel1_opts.phase2_encryption_algorithms != null) ? local.tunnel1_opts.phase2_encryption_algorithms : null
  tunnel1_phase2_integrity_algorithms  = (local.tunnel1_opts != null && local.tunnel1_opts.phase2_integrity_algorithms != null) ? local.tunnel1_opts.phase2_integrity_algorithms : null

  tunnel1_ike_versions            = local.tunnel1_opts != null ? local.tunnel1_opts.ike_versions : null
  tunnel1_phase1_lifetime_seconds = local.tunnel1_opts != null ? local.tunnel1_opts.phase1_lifetime_seconds : null
  tunnel1_phase2_lifetime_seconds = local.tunnel1_opts != null ? local.tunnel1_opts.phase2_lifetime_seconds : null
  tunnel1_dpd_timeout_action      = local.tunnel1_opts != null ? local.tunnel1_opts.dpd_timeout_action : null
  tunnel1_dpd_timeout_seconds     = local.tunnel1_opts != null ? local.tunnel1_opts.dpd_timeout_seconds : null
  tunnel1_rekey_fuzz_percentage   = local.tunnel1_opts != null ? local.tunnel1_opts.rekey_fuzz_percentage : null
  tunnel1_replay_window_size      = local.tunnel1_opts != null ? local.tunnel1_opts.replay_window_size : null
  tunnel1_startup_action          = local.tunnel1_opts != null ? local.tunnel1_opts.startup_action : null

  ##########################################################################
  # Tunnel 2 options
  ##########################################################################
  dynamic "tunnel2_log_options" {
    for_each = local.tunnel2_opts != null ? [1] : []
    content {
      cloudwatch_log_options {
        log_enabled       = true
        log_group_arn     = aws_cloudwatch_log_group.vpn_tunnel2[0].arn
        log_output_format = "json"
      }
    }
  }

  tunnel2_inside_cidr   = local.tunnel2_opts != null ? local.tunnel2_opts.tunnel_cidr : null
  tunnel2_preshared_key = local.tunnel2_opts != null ? local.tunnel2_opts.preshared_key : null

  tunnel2_phase1_dh_group_numbers      = (local.tunnel2_opts != null && local.tunnel2_opts.phase1_dh_group_numbers != null) ? local.tunnel2_opts.phase1_dh_group_numbers : null
  tunnel2_phase1_encryption_algorithms = (local.tunnel2_opts != null && local.tunnel2_opts.phase1_encryption_algorithms != null) ? local.tunnel2_opts.phase1_encryption_algorithms : null
  tunnel2_phase1_integrity_algorithms  = (local.tunnel2_opts != null && local.tunnel2_opts.phase1_integrity_algorithms != null) ? local.tunnel2_opts.phase1_integrity_algorithms : null
  tunnel2_phase2_dh_group_numbers      = (local.tunnel2_opts != null && local.tunnel2_opts.phase2_dh_group_numbers != null) ? local.tunnel2_opts.phase2_dh_group_numbers : null
  tunnel2_phase2_encryption_algorithms = (local.tunnel2_opts != null && local.tunnel2_opts.phase2_encryption_algorithms != null) ? local.tunnel2_opts.phase2_encryption_algorithms : null
  tunnel2_phase2_integrity_algorithms  = (local.tunnel2_opts != null && local.tunnel2_opts.phase2_integrity_algorithms != null) ? local.tunnel2_opts.phase2_integrity_algorithms : null

  tunnel2_ike_versions            = local.tunnel2_opts != null ? local.tunnel2_opts.ike_versions : null
  tunnel2_phase1_lifetime_seconds = local.tunnel2_opts != null ? local.tunnel2_opts.phase1_lifetime_seconds : null
  tunnel2_phase2_lifetime_seconds = local.tunnel2_opts != null ? local.tunnel2_opts.phase2_lifetime_seconds : null
  tunnel2_dpd_timeout_action      = local.tunnel2_opts != null ? local.tunnel2_opts.dpd_timeout_action : null
  tunnel2_dpd_timeout_seconds     = local.tunnel2_opts != null ? local.tunnel2_opts.dpd_timeout_seconds : null
  tunnel2_rekey_fuzz_percentage   = local.tunnel2_opts != null ? local.tunnel2_opts.rekey_fuzz_percentage : null
  tunnel2_replay_window_size      = local.tunnel2_opts != null ? local.tunnel2_opts.replay_window_size : null
  tunnel2_startup_action          = local.tunnel2_opts != null ? local.tunnel2_opts.startup_action : null

  tags = merge(var.tags, { Name = "${var.name}-vpn" })
}

##############################################################################
# Static Routes (used when static_routes_only = true)
##############################################################################
resource "aws_vpn_connection_route" "this" {
  for_each = var.static_routes_only ? toset(var.static_routes) : toset([])

  vpn_connection_id      = aws_vpn_connection.this.id
  destination_cidr_block = each.value
}

##############################################################################
# CloudWatch Log Groups for VPN tunnel logs
##############################################################################
resource "aws_cloudwatch_log_group" "vpn_tunnel1" {
  count = length(var.tunnel_options) >= 1 ? 1 : 0

  name              = "/aws/vpn/${var.name}/tunnel1"
  retention_in_days = 30

  tags = merge(var.tags, { Name = "${var.name}-vpn-tunnel1-logs" })
}

resource "aws_cloudwatch_log_group" "vpn_tunnel2" {
  count = length(var.tunnel_options) >= 2 ? 1 : 0

  name              = "/aws/vpn/${var.name}/tunnel2"
  retention_in_days = 30

  tags = merge(var.tags, { Name = "${var.name}-vpn-tunnel2-logs" })
}
