output "vpn_connection_id" {
  description = "ID of the Site-to-Site VPN connection."
  value       = aws_vpn_connection.this.id
}

output "vpn_connection_arn" {
  description = "ARN of the Site-to-Site VPN connection."
  value       = aws_vpn_connection.this.arn
}

output "tunnel1_address" {
  description = "Public IP address of tunnel 1 (AWS endpoint)."
  value       = aws_vpn_connection.this.tunnel1_address
}

output "tunnel2_address" {
  description = "Public IP address of tunnel 2 (AWS endpoint)."
  value       = aws_vpn_connection.this.tunnel2_address
}

output "tunnel1_cgw_inside_address" {
  description = "Customer Gateway inside IP for tunnel 1 (/30 from 169.254.x.x)."
  value       = aws_vpn_connection.this.tunnel1_cgw_inside_address
}

output "tunnel1_vgw_inside_address" {
  description = "VGW/TGW inside IP for tunnel 1 (/30 from 169.254.x.x)."
  value       = aws_vpn_connection.this.tunnel1_vgw_inside_address
}

output "tunnel2_cgw_inside_address" {
  description = "Customer Gateway inside IP for tunnel 2."
  value       = aws_vpn_connection.this.tunnel2_cgw_inside_address
}

output "tunnel2_vgw_inside_address" {
  description = "VGW/TGW inside IP for tunnel 2."
  value       = aws_vpn_connection.this.tunnel2_vgw_inside_address
}

output "tunnel1_bgp_asn" {
  description = "BGP ASN for tunnel 1."
  value       = aws_vpn_connection.this.tunnel1_bgp_asn
}

output "tunnel2_bgp_asn" {
  description = "BGP ASN for tunnel 2."
  value       = aws_vpn_connection.this.tunnel2_bgp_asn
}

output "customer_gateway_configuration" {
  description = "XML configuration document for the customer gateway device."
  value       = aws_vpn_connection.this.customer_gateway_configuration
  sensitive   = true
}

output "static_route_destination_cidrs" {
  description = "List of static route destination CIDRs configured on the VPN connection."
  value       = [for r in aws_vpn_connection_route.this : r.destination_cidr_block]
}

output "tunnel1_log_group_arn" {
  description = "ARN of the CloudWatch log group for tunnel 1 logs."
  value       = length(aws_cloudwatch_log_group.vpn_tunnel1) > 0 ? aws_cloudwatch_log_group.vpn_tunnel1[0].arn : null
}

output "tunnel2_log_group_arn" {
  description = "ARN of the CloudWatch log group for tunnel 2 logs."
  value       = length(aws_cloudwatch_log_group.vpn_tunnel2) > 0 ? aws_cloudwatch_log_group.vpn_tunnel2[0].arn : null
}
