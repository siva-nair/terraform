# site-to-site-vpn

Creates an AWS Site-to-Site VPN connection with full tunnel option customization (IKE versions, cipher suites, DH groups, PSK, inside CIDRs), static or BGP routing, and optional Accelerated VPN via AWS Global Accelerator.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpn_connection` | The IPsec VPN connection (2 tunnels) |
| `aws_vpn_connection_route` | Static destination CIDRs (one per static route) |
| `aws_cloudwatch_log_group` | Log groups for tunnel 1 and 2 IKE/data logs |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `customer_gateway_id` | `string` | — | CGW ID |
| `gateway_type` | `string` | `vgw` | Target: `vgw` or `tgw` |
| `vpn_gateway_id` | `string` | `null` | VGW ID (when gateway_type = vgw) |
| `transit_gateway_id` | `string` | `null` | TGW ID (when gateway_type = tgw) |
| `static_routes_only` | `bool` | `false` | Use static routing |
| `static_routes` | `list(string)` | `[]` | On-premises CIDRs for static routing |
| `enable_acceleration` | `bool` | `false` | AWS Global Accelerator (TGW only) |
| `tunnel_options` | `list(object)` | `[]` | Per-tunnel IKE/IPsec options |
| `local_ipv4_network_cidr` | `string` | `0.0.0.0/0` | AWS-side allowed CIDR |
| `remote_ipv4_network_cidr` | `string` | `0.0.0.0/0` | On-premises allowed CIDR |
| `tags` | `map(string)` | `{}` | Tags |

## Outputs

| Name | Description |
|------|-------------|
| `vpn_connection_id` | VPN connection ID |
| `vpn_connection_arn` | VPN connection ARN |
| `tunnel1_address` | Tunnel 1 AWS public IP |
| `tunnel2_address` | Tunnel 2 AWS public IP |
| `tunnel1_cgw_inside_address` | Tunnel 1 CGW inside IP |
| `tunnel1_vgw_inside_address` | Tunnel 1 VGW/TGW inside IP |
| `tunnel2_cgw_inside_address` | Tunnel 2 CGW inside IP |
| `tunnel2_vgw_inside_address` | Tunnel 2 VGW/TGW inside IP |
| `tunnel1_bgp_asn` | Tunnel 1 BGP ASN |
| `tunnel2_bgp_asn` | Tunnel 2 BGP ASN |
| `customer_gateway_configuration` | XML config for CGW device (sensitive) |
| `static_route_destination_cidrs` | Static route CIDRs |
| `tunnel1_log_group_arn` | CWL log group for tunnel 1 |
| `tunnel2_log_group_arn` | CWL log group for tunnel 2 |

## Usage Example

### BGP (Dynamic Routing) with Custom Tunnel Options

```hcl
module "vpn" {
  source = "./modules/site-to-site-vpn"

  name                = "prod-dc1"
  customer_gateway_id = module.hybrid.customer_gateway_ids["dc-primary"]
  gateway_type        = "vgw"
  vpn_gateway_id      = module.hybrid.vpn_gateway_id
  static_routes_only  = false

  tunnel_options = [
    {
      tunnel_cidr   = "169.254.10.0/30"
      preshared_key = "S3cur3P@ssw0rd1"
      ike_versions  = ["ikev2"]
      phase1_encryption_algorithms = ["AES256"]
      phase1_integrity_algorithms  = ["SHA2-256"]
      phase1_dh_group_numbers      = [20]
      phase2_encryption_algorithms = ["AES256-GCM-16"]
      phase2_integrity_algorithms  = ["SHA2-256"]
      phase2_dh_group_numbers      = [20]
      dpd_timeout_action           = "restart"
      startup_action               = "start"
    },
    {
      tunnel_cidr   = "169.254.11.0/30"
      preshared_key = "S3cur3P@ssw0rd2"
      ike_versions  = ["ikev2"]
      startup_action = "start"
    }
  ]

  tags = { Environment = "production" }
}
```

### Static Routing via TGW with Acceleration

```hcl
module "vpn_static" {
  source = "./modules/site-to-site-vpn"

  name                = "prod-dc2"
  customer_gateway_id = module.hybrid.customer_gateway_ids["dc-backup"]
  gateway_type        = "tgw"
  transit_gateway_id  = module.tgw.transit_gateway_id
  static_routes_only  = true
  enable_acceleration = true

  static_routes = ["10.100.0.0/16", "192.168.50.0/24"]

  tags = { Environment = "production" }
}
```

## Concepts

### AWS Site-to-Site VPN Architecture
Every VPN connection has **two tunnels** (active/active or active/passive) for redundancy. Each tunnel terminates on a different AWS endpoint. Both tunnels can carry traffic simultaneously when BGP ECMP is enabled (requires TGW with `vpn_ecmp_support = "enable"`).

**Tunnel inside addresses:** Link-local /30 CIDRs from 169.254.x.x, used for BGP peering over the tunnel. Custom CIDRs can be specified to avoid conflicts with existing infrastructure.

### IKE (Internet Key Exchange)
| Phase | Purpose | Key Parameters |
|-------|---------|----------------|
| **IKE Phase 1** (ISAKMP SA) | Authenticate + establish secure channel | Encryption (AES128/256), Integrity (SHA1/SHA2), DH Group, IKE version |
| **IKE Phase 2** (IPsec SA) | Negotiate data encryption | Encryption (AES128/256/GCM), Integrity, DH Group, lifetime |

**IKEv2 vs IKEv1:**
- IKEv2: Faster, simpler, built-in NAT-T, supports multiple traffic selectors. Recommended.
- IKEv1: Legacy; required for old on-premises hardware.

### DPD (Dead Peer Detection)
Monitors tunnel health. Actions on timeout:
- `clear` — delete SA and wait for CGW to reinitiate (default)
- `restart` — immediately reinitiate IKE negotiation from AWS side
- `none` — do nothing

### Accelerated VPN
When enabled, AWS Global Accelerator provides dedicated connectivity from on-premises to AWS edge locations, bypassing unpredictable internet routing. Requires TGW (not VGW). Reduces jitter and latency by keeping traffic on the AWS global network backbone longer.

### Static vs BGP Routing

| Feature | Static | BGP (Dynamic) |
|---------|--------|---------------|
| Route updates | Manual | Automatic |
| Failover | Manual route change | Automatic via BGP |
| ECMP | Not supported | Supported with TGW |
| Config complexity | Low | Higher (requires BGP ASN) |

For production, BGP is strongly recommended to enable automatic failover between tunnels.

### CGW Configuration Document
The `customer_gateway_configuration` output contains a vendor-agnostic XML document with all parameters needed to configure the on-premises router. Download and use this with Cisco IOS, Juniper, Palo Alto, Fortinet, etc. Mark this output as `sensitive` and manage it via Secrets Manager in production.
