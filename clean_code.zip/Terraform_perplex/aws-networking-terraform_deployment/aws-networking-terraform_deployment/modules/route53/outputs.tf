output "public_zone_id" {
  description = "Zone ID of the public hosted zone."
  value       = var.public_zone_name != "" ? aws_route53_zone.public[0].zone_id : null
}

output "public_zone_name_servers" {
  description = "Name servers for the public hosted zone."
  value       = var.public_zone_name != "" ? aws_route53_zone.public[0].name_servers : []
}

output "private_zone_id" {
  description = "Zone ID of the private hosted zone."
  value       = var.create_private_zone ? aws_route53_zone.private[0].zone_id : null
}

output "health_check_ids" {
  description = "Map of health check logical name to health check ID."
  value = {
    for k, v in aws_route53_health_check.this : k => v.id
  }
}

output "dnssec_key_signing_key_id" {
  description = "ID of the DNSSEC Key Signing Key (if created)."
  value       = var.enable_dnssec && var.dnssec_kms_key_arn != "" ? aws_route53_key_signing_key.this[0].id : null
}

output "query_log_config_id" {
  description = "ID of the Resolver Query Log Config (if created)."
  value       = var.enable_query_logging && var.query_log_destination_arn != "" ? aws_route53_resolver_query_log_config.this[0].id : null
}
