data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  common_tags = merge(
    {
      Name      = var.name
      ManagedBy = "terraform"
    },
    var.tags
  )

  # Partition records by zone
  public_records  = [for r in var.records : r if r.zone == "public"]
  private_records = [for r in var.records : r if r.zone == "private"]
}

# ---------------------------------------------------------------------------
# Public Hosted Zone
# ---------------------------------------------------------------------------
resource "aws_route53_zone" "public" {
  count = var.public_zone_name != "" ? 1 : 0

  name    = var.public_zone_name
  comment = "${var.name} public zone managed by Terraform"

  tags = merge(local.common_tags, { Name = var.public_zone_name })
}

# ---------------------------------------------------------------------------
# Private Hosted Zone
# ---------------------------------------------------------------------------
resource "aws_route53_zone" "private" {
  count = var.create_private_zone ? 1 : 0

  name    = var.private_zone_name
  comment = "${var.name} private zone managed by Terraform"

  dynamic "vpc" {
    for_each = var.private_zone_vpc_ids
    content {
      vpc_id = vpc.value
    }
  }

  tags = merge(local.common_tags, { Name = var.private_zone_name })
}

# Additional VPC associations for private zone (cross-account, secondary VPCs)
resource "aws_route53_zone_association" "additional" {
  for_each = {
    for v in var.private_zone_additional_vpcs :
    "${v.vpc_id}-${v.region}" => v
    if var.create_private_zone
  }

  zone_id    = aws_route53_zone.private[0].id
  vpc_id     = each.value.vpc_id
  vpc_region = each.value.region
}

# ---------------------------------------------------------------------------
# Health Checks
# ---------------------------------------------------------------------------
resource "aws_route53_health_check" "this" {
  for_each = var.health_checks

  fqdn              = each.value.fqdn != "" ? each.value.fqdn : null
  ip_address        = each.value.ip_address != "" ? each.value.ip_address : null
  port              = each.value.port
  type              = each.value.type
  resource_path     = each.value.type != "TCP" ? each.value.resource_path : null
  failure_threshold = each.value.failure_threshold
  request_interval  = each.value.request_interval
  enable_sni        = each.value.enable_sni

  regions = length(each.value.regions) > 0 ? each.value.regions : null

  tags = merge(local.common_tags, { Name = "${var.name}-hc-${each.key}" })
}

# ---------------------------------------------------------------------------
# DNS Records (public zone)
# ---------------------------------------------------------------------------
resource "aws_route53_record" "public" {
  for_each = {
    for idx, r in local.public_records :
    "${r.name}-${r.type}-${idx}" => r
    if var.public_zone_name != ""
  }

  zone_id        = aws_route53_zone.public[0].zone_id
  name           = each.value.name
  type           = each.value.type
  ttl            = each.value.alias == null ? each.value.ttl : null
  records        = each.value.alias == null ? each.value.records : null
  set_identifier = each.value.set_identifier

  health_check_id = (
    each.value.health_check_key != null && contains(keys(var.health_checks), each.value.health_check_key)
    ? aws_route53_health_check.this[each.value.health_check_key].id
    : null
  )

  dynamic "alias" {
    for_each = each.value.alias != null ? [each.value.alias] : []
    content {
      name                   = alias.value.name
      zone_id                = alias.value.zone_id
      evaluate_target_health = alias.value.evaluate_target_health
    }
  }

  dynamic "weighted_routing_policy" {
    for_each = each.value.routing_policy == "weighted" ? [each.value.weight] : []
    content {
      weight = weighted_routing_policy.value
    }
  }

  dynamic "latency_routing_policy" {
    for_each = each.value.routing_policy == "latency" ? [each.value.latency_region] : []
    content {
      region = latency_routing_policy.value
    }
  }

  dynamic "failover_routing_policy" {
    for_each = each.value.routing_policy == "failover" ? [each.value.failover_type] : []
    content {
      type = failover_routing_policy.value
    }
  }

  dynamic "geolocation_routing_policy" {
    for_each = each.value.routing_policy == "geolocation" && each.value.geo_location != null ? [each.value.geo_location] : []
    content {
      continent   = geolocation_routing_policy.value.continent
      country     = geolocation_routing_policy.value.country
      subdivision = geolocation_routing_policy.value.subdivision
    }
  }

  dynamic "geoproximity_routing_policy" {
    for_each = each.value.routing_policy == "geoproximity" && each.value.geoproximity != null ? [each.value.geoproximity] : []
    content {
      aws_region       = geoproximity_routing_policy.value.aws_region
      bias             = geoproximity_routing_policy.value.bias
      local_zone_group = geoproximity_routing_policy.value.local_zone_group
    }
  }

  multivalue_answer_routing_policy = each.value.routing_policy == "multivalue" ? each.value.multivalue_answer : null
}

# ---------------------------------------------------------------------------
# DNS Records (private zone)
# ---------------------------------------------------------------------------
resource "aws_route53_record" "private" {
  for_each = {
    for idx, r in local.private_records :
    "${r.name}-${r.type}-${idx}" => r
    if var.create_private_zone
  }

  zone_id        = aws_route53_zone.private[0].zone_id
  name           = each.value.name
  type           = each.value.type
  ttl            = each.value.alias == null ? each.value.ttl : null
  records        = each.value.alias == null ? each.value.records : null
  set_identifier = each.value.set_identifier

  dynamic "alias" {
    for_each = each.value.alias != null ? [each.value.alias] : []
    content {
      name                   = alias.value.name
      zone_id                = alias.value.zone_id
      evaluate_target_health = alias.value.evaluate_target_health
    }
  }

  dynamic "weighted_routing_policy" {
    for_each = each.value.routing_policy == "weighted" ? [each.value.weight] : []
    content {
      weight = weighted_routing_policy.value
    }
  }

  dynamic "failover_routing_policy" {
    for_each = each.value.routing_policy == "failover" ? [each.value.failover_type] : []
    content {
      type = failover_routing_policy.value
    }
  }
}

# ---------------------------------------------------------------------------
# DNSSEC
# ---------------------------------------------------------------------------
resource "aws_route53_key_signing_key" "this" {
  count = var.enable_dnssec && var.public_zone_name != "" && var.dnssec_kms_key_arn != "" ? 1 : 0

  hosted_zone_id             = aws_route53_zone.public[0].zone_id
  key_management_service_arn = var.dnssec_kms_key_arn
  name                       = var.dnssec_key_name
}

resource "aws_route53_hosted_zone_dnssec" "this" {
  count = var.enable_dnssec && var.public_zone_name != "" && var.dnssec_kms_key_arn != "" ? 1 : 0

  hosted_zone_id = aws_route53_key_signing_key.this[0].hosted_zone_id

  depends_on = [aws_route53_key_signing_key.this]
}

# ---------------------------------------------------------------------------
# Resolver Query Logging
# ---------------------------------------------------------------------------
resource "aws_route53_resolver_query_log_config" "this" {
  count = var.enable_query_logging && var.query_log_destination_arn != "" ? 1 : 0

  name            = "${var.name}-query-log"
  destination_arn = var.query_log_destination_arn

  tags = local.common_tags
}

resource "aws_route53_resolver_query_log_config_association" "public" {
  count = var.enable_query_logging && var.public_zone_name != "" && var.query_log_destination_arn != "" ? 1 : 0

  resolver_query_log_config_id = aws_route53_resolver_query_log_config.this[0].id
  resource_id                  = aws_route53_zone.public[0].zone_id
}
