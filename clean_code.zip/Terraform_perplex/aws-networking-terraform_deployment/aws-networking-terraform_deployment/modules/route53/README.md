# route53

Terraform module for **Amazon Route 53** — a highly available and scalable cloud DNS web service supporting public and private hosted zones, multiple routing policies, DNSSEC, and query logging.

## Resources Created

| Resource | Description |
|---|---|
| `aws_route53_zone` (public) | Public hosted zone for internet DNS |
| `aws_route53_zone` (private) | Private hosted zone for VPC-internal DNS |
| `aws_route53_zone_association` | Additional VPC associations for private zone |
| `aws_route53_record` | DNS records (all routing policy types) |
| `aws_route53_health_check` | Endpoint health checks |
| `aws_route53_key_signing_key` | DNSSEC Key Signing Key |
| `aws_route53_hosted_zone_dnssec` | Enables DNSSEC on the zone |
| `aws_route53_resolver_query_log_config` | Query log configuration |
| `aws_route53_resolver_query_log_config_association` | Binds query log to the hosted zone |

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| `name` | Resource name prefix | `string` | — | yes |
| `public_zone_name` | Public zone domain | `string` | `""` | no |
| `create_private_zone` | Create private zone | `bool` | `false` | no |
| `private_zone_name` | Private zone domain | `string` | `""` | no |
| `private_zone_vpc_ids` | VPCs for private zone | `list(string)` | `[]` | no |
| `records` | List of DNS record objects | `list(object)` | `[]` | no |
| `health_checks` | Map of health check objects | `map(object)` | `{}` | no |
| `enable_dnssec` | Enable DNSSEC | `bool` | `false` | no |
| `dnssec_kms_key_arn` | KMS key ARN for DNSSEC | `string` | `""` | no |
| `enable_query_logging` | Enable resolver query logging | `bool` | `false` | no |
| `query_log_destination_arn` | CW/S3/Firehose ARN for logs | `string` | `""` | no |
| `tags` | Tags for all resources | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|---|---|
| `public_zone_id` | Public zone ID |
| `public_zone_name_servers` | Public zone NS records |
| `private_zone_id` | Private zone ID |
| `health_check_ids` | Map of health check name → ID |
| `dnssec_key_signing_key_id` | DNSSEC KSK ID |
| `query_log_config_id` | Query log config ID |

## Usage Example

```hcl
module "route53" {
  source = "./modules/route53"

  name             = "corp"
  public_zone_name = "example.com"

  create_private_zone  = true
  private_zone_name    = "internal.example.com"
  private_zone_vpc_ids = [module.vpc.vpc_id]

  health_checks = {
    web-primary = {
      fqdn          = "example.com"
      port          = 443
      type          = "HTTPS"
      resource_path = "/health"
    }
  }

  records = [
    # Simple A record
    {
      name    = "www"
      type    = "A"
      zone    = "public"
      records = ["1.2.3.4"]
    },
    # Weighted routing
    {
      name           = "api"
      type           = "A"
      zone           = "public"
      routing_policy = "weighted"
      weight         = 80
      set_identifier = "primary"
      records        = ["1.2.3.4"]
    },
    # Failover with health check
    {
      name             = "service"
      type             = "A"
      zone             = "public"
      routing_policy   = "failover"
      failover_type    = "PRIMARY"
      set_identifier   = "primary"
      health_check_key = "web-primary"
      records          = ["1.2.3.4"]
    },
    # Alias to ALB
    {
      name = "app"
      type = "A"
      zone = "public"
      alias = {
        name                   = module.alb.lb_dns_name
        zone_id                = module.alb.lb_zone_id
        evaluate_target_health = true
      }
    }
  ]

  enable_dnssec     = true
  dnssec_kms_key_arn = "REDACTED_AWS_ARN"

  enable_query_logging      = true
  query_log_destination_arn = "REDACTED_AWS_ARN"

  tags = { Environment = "prod" }
}
```

## Concepts (Exam Prep)

**Amazon Route 53** provides authoritative DNS, health checking, and traffic routing. Key exam points:

- **Hosted zones**: Public (internet-resolvable), Private (VPC-internal only). Private zones can be associated with multiple VPCs including cross-account.
- **Routing policies**:
  - **Simple**: One record, one value. No health checks.
  - **Weighted**: Distribute traffic by percentage. `weight=0` removes from rotation.
  - **Latency**: Routes to the region with the lowest latency to the client.
  - **Failover**: Active-passive. Routes to SECONDARY when PRIMARY health check fails.
  - **Geolocation**: Routes based on client's geographic location (continent, country, subdivision). Must include a default record.
  - **Geoproximity**: Routes based on geographic proximity with bias adjustments. Requires Traffic Flow.
  - **Multivalue Answer**: Returns up to 8 healthy records at random — NOT a substitute for load balancing.
- **Health checks**: Monitor endpoints (HTTP/HTTPS/TCP), other health checks (calculated), or CloudWatch alarms. Used with failover and weighted routing. Health checks originate from multiple AWS regions.
- **Alias records**: Route 53-specific extension — free, auto-updates with target IP changes. Can point to ALB, NLB, CloudFront, S3, API GW, Elastic Beanstalk, VPC endpoints.
- **DNSSEC**: Cryptographically signs zone records. Route 53 supports DNSSEC signing using KMS (ECC_NIST_P256, must be in us-east-1). Adds a Key Signing Key (KSK) and Zone Signing Key (ZSK).
- **Resolver**: Route 53 Resolver handles DNS for VPCs. Inbound endpoints allow on-prem DNS to resolve AWS records; Outbound endpoints allow VPC DNS to query on-prem.
