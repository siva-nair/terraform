variable "name" {
  description = "Name prefix for resources."
  type        = string
}

# ---------------------------------------------------------------------------
# Hosted Zones
# ---------------------------------------------------------------------------
variable "public_zone_name" {
  description = "Domain name for the public hosted zone. Set to empty string to skip."
  type        = string
  default     = ""
}

variable "create_private_zone" {
  description = "Whether to create a private hosted zone."
  type        = bool
  default     = false
}

variable "private_zone_name" {
  description = "Domain name for the private hosted zone."
  type        = string
  default     = ""
}

variable "private_zone_vpc_ids" {
  description = "List of VPC IDs to associate with the private hosted zone."
  type        = list(string)
  default     = []
}

variable "private_zone_additional_vpcs" {
  description = "Additional VPCs to associate with the private zone (for cross-account or secondary associations). Each object needs vpc_id and region."
  type = list(object({
    vpc_id = string
    region = string
  }))
  default = []
}

# ---------------------------------------------------------------------------
# DNS Records
# ---------------------------------------------------------------------------
variable "records" {
  description = "List of DNS record objects to create."
  type = list(object({
    name    = string
    type    = string
    ttl     = optional(number, 300)
    zone    = optional(string, "public") # "public" or "private"
    records = optional(list(string), [])

    # Routing policy
    routing_policy = optional(string, "simple") # simple, weighted, latency, failover, geolocation, geoproximity, multivalue

    # Alias target
    alias = optional(object({
      name                   = string
      zone_id                = string
      evaluate_target_health = optional(bool, true)
    }), null)

    # Weighted
    weight = optional(number, null)

    # Latency
    latency_region = optional(string, null)

    # Failover
    failover_type = optional(string, null) # PRIMARY or SECONDARY

    # Geolocation
    geo_location = optional(object({
      continent   = optional(string, null)
      country     = optional(string, null)
      subdivision = optional(string, null)
    }), null)

    # Geoproximity
    geoproximity = optional(object({
      aws_region       = optional(string, null)
      bias             = optional(number, 0)
      local_zone_group = optional(string, null)
    }), null)

    # Multivalue
    multivalue_answer = optional(bool, null)

    # Set identifier (required for all except simple)
    set_identifier = optional(string, null)

    # Health check association
    health_check_key = optional(string, null)
  }))
  default = []
}

# ---------------------------------------------------------------------------
# Health Checks
# ---------------------------------------------------------------------------
variable "health_checks" {
  description = "Map of health check objects. Key is a logical name used in records."
  type = map(object({
    fqdn              = optional(string, "")
    ip_address        = optional(string, "")
    port              = optional(number, 80)
    type              = optional(string, "HTTP") # HTTP, HTTPS, HTTP_STR_MATCH, TCP, CALCULATED, CLOUDWATCH_METRIC
    resource_path     = optional(string, "/")
    failure_threshold = optional(number, 3)
    request_interval  = optional(number, 30)
    regions           = optional(list(string), [])
    enable_sni        = optional(bool, false)
  }))
  default = {}
}

# ---------------------------------------------------------------------------
# DNSSEC
# ---------------------------------------------------------------------------
variable "enable_dnssec" {
  description = "Whether to enable DNSSEC on the public hosted zone."
  type        = bool
  default     = false
}

variable "dnssec_key_name" {
  description = "Name for the DNSSEC Key Signing Key."
  type        = string
  default     = "ksk"
}

variable "dnssec_kms_key_arn" {
  description = "ARN of the KMS key (in us-east-1, ECC_NIST_P256) used for DNSSEC signing."
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Resolver Query Logging
# ---------------------------------------------------------------------------
variable "enable_query_logging" {
  description = "Whether to enable Route 53 Resolver query logging."
  type        = bool
  default     = false
}

variable "query_log_destination_arn" {
  description = "ARN of the CloudWatch Log Group, S3 bucket, or Kinesis Firehose for query logs."
  type        = string
  default     = ""
}

variable "tags" {
  description = "Map of tags to apply to all resources."
  type        = map(string)
  default     = {}
}
