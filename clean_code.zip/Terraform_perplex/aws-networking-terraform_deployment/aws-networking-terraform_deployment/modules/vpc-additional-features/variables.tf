variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "vpc_id" {
  description = "ID of the existing VPC to attach additional features to."
  type        = string
}

# ── Secondary CIDRs ──────────────────────────────────────────────────────────
variable "secondary_cidr_blocks" {
  description = "List of additional IPv4 CIDR blocks to associate with the VPC."
  type        = list(string)
  default     = []
}

# ── Flow Logs ─────────────────────────────────────────────────────────────────
variable "enable_flow_logs_cloudwatch" {
  description = "Enable VPC Flow Logs to CloudWatch Logs."
  type        = bool
  default     = true
}

variable "enable_flow_logs_s3" {
  description = "Enable VPC Flow Logs to S3."
  type        = bool
  default     = false
}

variable "flow_logs_s3_bucket_arn" {
  description = "ARN of the S3 bucket to deliver flow logs (required when enable_flow_logs_s3 = true)."
  type        = string
  default     = ""
}

variable "flow_log_traffic_type" {
  description = "Flow log traffic type: ACCEPT, REJECT, or ALL."
  type        = string
  default     = "ALL"

  validation {
    condition     = contains(["ACCEPT", "REJECT", "ALL"], var.flow_log_traffic_type)
    error_message = "flow_log_traffic_type must be ACCEPT, REJECT, or ALL."
  }
}

variable "flow_log_retention_days" {
  description = "CloudWatch log group retention in days."
  type        = number
  default     = 30
}

# ── Reachability Analyzer ─────────────────────────────────────────────────────
variable "reachability_paths" {
  description = <<-EOT
    Map of Reachability Analyzer paths to create.
    Key  = logical name
    Value = object with:
      source_id       – ENI, IGW, VGW, etc.
      destination_id  – ENI, IGW, VGW, etc.
      protocol        – tcp | udp (optional)
      destination_port – number (optional)
  EOT
  type = map(object({
    source_id        = string
    destination_id   = string
    protocol         = optional(string)
    destination_port = optional(number)
  }))
  default = {}
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
