output "secondary_cidr_association_ids" {
  description = "Map of secondary CIDR block → association ID."
  value       = { for k, v in aws_vpc_ipv4_cidr_block_association.secondary : k => v.id }
}

output "flow_log_cloudwatch_id" {
  description = "ID of the CloudWatch Flow Log (empty when disabled)."
  value       = length(aws_flow_log.cloudwatch) > 0 ? aws_flow_log.cloudwatch[0].id : null
}

output "flow_log_s3_id" {
  description = "ID of the S3 Flow Log (empty when disabled)."
  value       = length(aws_flow_log.s3) > 0 ? aws_flow_log.s3[0].id : null
}

output "flow_log_cloudwatch_log_group_arn" {
  description = "ARN of the CloudWatch Log Group for flow logs."
  value       = length(aws_cloudwatch_log_group.flow_logs) > 0 ? aws_cloudwatch_log_group.flow_logs[0].arn : null
}

output "flow_log_iam_role_arn" {
  description = "ARN of the IAM role used by the CloudWatch Flow Log."
  value       = length(aws_iam_role.flow_logs) > 0 ? aws_iam_role.flow_logs[0].arn : null
}

output "reachability_path_ids" {
  description = "Map of logical name → Network Insights Path ID."
  value       = { for k, v in aws_ec2_network_insights_path.this : k => v.id }
}

output "reachability_path_arns" {
  description = "Map of logical name → Network Insights Path ARN."
  value       = { for k, v in aws_ec2_network_insights_path.this : k => v.arn }
}

# NOTE: network_access_scope_id and network_access_scope_arn outputs removed because
# aws_ec2_network_insights_access_scope is not supported by the AWS provider yet.
