# vpc-additional-features

Attaches advanced VPC features to an **existing** VPC: secondary CIDR blocks, VPC Flow Logs (CloudWatch and/or S3), Reachability Analyzer paths, and a Network Access Analyzer scope.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpc_ipv4_cidr_block_association` | Adds secondary IPv4 CIDRs to the VPC |
| `aws_cloudwatch_log_group` | Log group for CloudWatch Flow Logs |
| `aws_iam_role` / `aws_iam_role_policy` | IAM role allowing VPC to write to CloudWatch |
| `aws_flow_log` (CloudWatch) | Captures VPC traffic metadata to CWL |
| `aws_flow_log` (S3) | Captures VPC traffic metadata to S3 |
| `aws_ec2_network_insights_path` | Reachability Analyzer path definitions |
| `aws_ec2_network_insights_access_scope` | Network Access Analyzer scope |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `vpc_id` | `string` | — | Existing VPC ID |
| `secondary_cidr_blocks` | `list(string)` | `[]` | Additional IPv4 CIDRs to associate |
| `enable_flow_logs_cloudwatch` | `bool` | `true` | Enable CWL flow logs |
| `enable_flow_logs_s3` | `bool` | `false` | Enable S3 flow logs |
| `flow_logs_s3_bucket_arn` | `string` | `""` | Target S3 bucket ARN |
| `flow_log_traffic_type` | `string` | `"ALL"` | ACCEPT, REJECT, or ALL |
| `flow_log_retention_days` | `number` | `30` | CWL retention period |
| `reachability_paths` | `map(object)` | `{}` | Reachability Analyzer path definitions |
| `enable_network_access_scope` | `bool` | `false` | Create NAA scope |
| `tags` | `map(string)` | `{}` | Tags for all resources |

## Outputs

| Name | Description |
|------|-------------|
| `secondary_cidr_association_ids` | Map of CIDR → association ID |
| `flow_log_cloudwatch_id` | CloudWatch flow log ID |
| `flow_log_s3_id` | S3 flow log ID |
| `flow_log_cloudwatch_log_group_arn` | CWL log group ARN |
| `flow_log_iam_role_arn` | IAM role ARN |
| `reachability_path_ids` | Map of name → path ID |
| `reachability_path_arns` | Map of name → path ARN |
| `network_access_scope_id` | NAA scope ID |
| `network_access_scope_arn` | NAA scope ARN |

## Usage Example

```hcl
module "vpc_extras" {
  source = "./modules/vpc-additional-features"

  name   = "prod"
  vpc_id = module.vpc.vpc_id

  secondary_cidr_blocks = ["100.64.0.0/16"]

  enable_flow_logs_cloudwatch = true
  enable_flow_logs_s3         = true
  flow_logs_s3_bucket_arn     = "REDACTED_AWS_ARN"
  flow_log_traffic_type       = "REJECT"

  reachability_paths = {
    web-to-db = {
      source_id        = "REDACTED_AWS_RESOURCE_ID"
      destination_id   = "REDACTED_AWS_RESOURCE_ID"
      protocol         = "tcp"
      destination_port = 5432
    }
  }

  enable_network_access_scope = true

  tags = { Environment = "production" }
}
```

## Concepts

### Secondary CIDR Blocks
A VPC can have up to 5 IPv4 CIDR blocks. Useful when the primary CIDR is exhausted or when you need to connect overlapping VPCs via AWS PrivateLink. The 100.64.0.0/10 range (RFC 6598, CG-NAT) is commonly added to avoid conflicts in peered environments.

### VPC Flow Logs
Capture metadata (5-tuple, bytes, packets, action) for traffic through ENIs, subnets, or the entire VPC. Stored in CloudWatch Logs or S3. **Not** a packet capture — no payload. Key fields: `srcaddr`, `dstaddr`, `srcport`, `dstport`, `protocol`, `action`, `log-status`. Custom formats supported since 2019.

### Reachability Analyzer
Performs **static** (no traffic sent) analysis of the path between two network endpoints within a VPC. Returns hop-by-hop detail: security groups, NACLs, route tables, peering connections. Useful for validating configuration before deploying workloads.

### Network Access Analyzer
Identifies unintended network access paths at scale. You define a _scope_ (what counts as internet-reachable) and AWS evaluates all your resources against it — surfacing paths that reach IGWs, peering connections, etc.
