##############################################################################
# Secondary CIDR Blocks
##############################################################################
resource "aws_vpc_ipv4_cidr_block_association" "secondary" {
  for_each = toset(var.secondary_cidr_blocks)

  vpc_id     = var.vpc_id
  cidr_block = each.value
}

##############################################################################
# Flow Logs – CloudWatch
##############################################################################
resource "aws_cloudwatch_log_group" "flow_logs" {
  count = var.enable_flow_logs_cloudwatch ? 1 : 0

  name              = "/aws/vpc/flow-logs/${var.name}"
  retention_in_days = var.flow_log_retention_days

  tags = merge(var.tags, { Name = "${var.name}-flow-logs-cw" })
}

resource "aws_iam_role" "flow_logs" {
  count = var.enable_flow_logs_cloudwatch ? 1 : 0

  name = "${var.name}-vpc-flow-logs-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "vpc-flow-logs.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = merge(var.tags, { Name = "${var.name}-flow-logs-role" })
}

resource "aws_iam_role_policy" "flow_logs" {
  count = var.enable_flow_logs_cloudwatch ? 1 : 0

  name = "${var.name}-vpc-flow-logs-policy"
  role = aws_iam_role.flow_logs[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams"
      ]
      Resource = "*"
    }]
  })
}

resource "aws_flow_log" "cloudwatch" {
  count = var.enable_flow_logs_cloudwatch ? 1 : 0

  vpc_id          = var.vpc_id
  traffic_type    = var.flow_log_traffic_type
  iam_role_arn    = aws_iam_role.flow_logs[0].arn
  log_destination = aws_cloudwatch_log_group.flow_logs[0].arn

  tags = merge(var.tags, { Name = "${var.name}-flow-log-cw" })
}

##############################################################################
# Flow Logs – S3
##############################################################################
resource "aws_flow_log" "s3" {
  count = var.enable_flow_logs_s3 ? 1 : 0

  vpc_id               = var.vpc_id
  traffic_type         = var.flow_log_traffic_type
  log_destination_type = "s3"
  log_destination      = var.flow_logs_s3_bucket_arn

  tags = merge(var.tags, { Name = "${var.name}-flow-log-s3" })
}

##############################################################################
# Reachability Analyzer Paths
##############################################################################
resource "aws_ec2_network_insights_path" "this" {
  for_each = var.reachability_paths

  source           = each.value.source_id
  destination      = each.value.destination_id
  protocol         = each.value.protocol != null ? each.value.protocol : "tcp"
  destination_port = each.value.destination_port

  tags = merge(var.tags, { Name = "${var.name}-nip-${each.key}" })
}

# NOTE: Network Access Analyzer scope creation (aws_ec2_network_insights_access_scope)
# is not supported by the AWS provider yet. Only Reachability Analyzer paths via
# aws_ec2_network_insights_path are currently supported.
