##############################################################################
# Data – current region
##############################################################################
data "aws_region" "current" {}

locals {
  # If service_name already starts with "com." treat it as fully qualified;
  # otherwise prefix with the standard AWS pattern.
  endpoints_resolved = {
    for k, v in var.interface_endpoints : k => merge(v, {
      resolved_service_name = can(regex("^com\\.", v.service_name)) ? v.service_name : "com.amazonaws.${data.aws_region.current.name}.${v.service_name}"
    })
  }
}

##############################################################################
# Interface VPC Endpoints
##############################################################################
resource "aws_vpc_endpoint" "interface" {
  for_each = local.endpoints_resolved

  vpc_id              = var.vpc_id
  service_name        = each.value.resolved_service_name
  vpc_endpoint_type   = "Interface"
  subnet_ids          = var.subnet_ids
  security_group_ids  = var.security_group_ids
  private_dns_enabled = each.value.private_dns_enabled
  policy              = each.value.policy

  tags = merge(var.tags, { Name = "${var.name}-endpoint-${each.key}" })
}

##############################################################################
# PrivateLink Endpoint Service
##############################################################################
resource "aws_vpc_endpoint_service" "this" {
  count = var.create_endpoint_service ? 1 : 0

  acceptance_required        = var.endpoint_service_acceptance_required
  network_load_balancer_arns = var.endpoint_service_nlb_arns
  private_dns_name           = var.endpoint_service_private_dns_name

  tags = merge(var.tags, { Name = "${var.name}-endpoint-service" })
}

##############################################################################
# Endpoint Service – Allowed Principals
##############################################################################
resource "aws_vpc_endpoint_service_allowed_principal" "this" {
  for_each = var.create_endpoint_service ? toset(var.endpoint_service_allowed_principals) : toset([])

  vpc_endpoint_service_id = aws_vpc_endpoint_service.this[0].id
  principal_arn           = each.value
}
