# vpc-interface-endpoints-privatelink

Creates Interface VPC Endpoints for AWS services and/or a PrivateLink Endpoint Service backed by a Network Load Balancer for sharing your own services with other VPCs/accounts.

## Resources Created

| Resource | Description |
|----------|-------------|
| `aws_vpc_endpoint` (Interface) | ENI-based endpoint per service in selected subnets |
| `aws_vpc_endpoint_service` | PrivateLink endpoint service backed by NLB |
| `aws_vpc_endpoint_service_allowed_principal` | IAM principals permitted to create connections |

## Inputs

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `name` | `string` | — | Name prefix |
| `vpc_id` | `string` | — | Target VPC ID |
| `subnet_ids` | `list(string)` | — | Subnets for endpoint ENIs (one per AZ) |
| `security_group_ids` | `list(string)` | `[]` | SGs for endpoint ENIs |
| `interface_endpoints` | `map(object)` | `{}` | Interface endpoints to create |
| `create_endpoint_service` | `bool` | `false` | Create a PrivateLink endpoint service |
| `endpoint_service_nlb_arns` | `list(string)` | `[]` | NLB ARNs backing the service |
| `endpoint_service_acceptance_required` | `bool` | `true` | Require manual acceptance |
| `endpoint_service_allowed_principals` | `list(string)` | `[]` | Principals that may connect |
| `endpoint_service_private_dns_name` | `string` | `null` | Custom DNS name for the service |
| `tags` | `map(string)` | `{}` | Tags |

## Outputs

| Name | Description |
|------|-------------|
| `interface_endpoint_ids` | Map of name → endpoint ID |
| `interface_endpoint_arns` | Map of name → endpoint ARN |
| `interface_endpoint_dns_entries` | Map of name → DNS entries |
| `interface_endpoint_network_interface_ids` | Map of name → ENI IDs |
| `endpoint_service_id` | PrivateLink service ID |
| `endpoint_service_name` | Service name to share with consumers |
| `endpoint_service_arn` | Service ARN |
| `endpoint_service_availability_zones` | AZs the service is available in |
| `endpoint_service_private_dns_name_configuration` | DNS TXT record for domain verification |

## Usage Example

```hcl
module "interface_endpoints" {
  source = "./modules/vpc-interface-endpoints-privatelink"

  name               = "prod"
  vpc_id             = module.vpc.vpc_id
  subnet_ids         = module.vpc.private_subnet_ids
  security_group_ids = [aws_security_group.endpoints.id]

  interface_endpoints = {
    ssm = {
      service_name        = "ssm"
      private_dns_enabled = true
    }
    ssmmessages = {
      service_name        = "ssmmessages"
      private_dns_enabled = true
    }
    ec2messages = {
      service_name        = "ec2messages"
      private_dns_enabled = true
    }
    secretsmanager = {
      service_name        = "secretsmanager"
      private_dns_enabled = true
    }
  }

  tags = { Environment = "production" }
}

# PrivateLink provider side: expose an internal service
module "my_service_privatelink" {
  source = "./modules/vpc-interface-endpoints-privatelink"

  name   = "my-service"
  vpc_id = module.vpc.vpc_id
  subnet_ids = []  # not needed for service provider side

  create_endpoint_service          = true
  endpoint_service_nlb_arns        = [aws_lb.my_nlb.arn]
  endpoint_service_acceptance_required = true
  endpoint_service_allowed_principals = [
    "REDACTED_AWS_ARN",
    "REDACTED_AWS_ARN",
  ]

  tags = { Environment = "production" }
}
```

## Concepts

### Interface Endpoints
An Interface Endpoint creates one **ENI** per subnet in your VPC. Traffic to the AWS service routes to that ENI rather than the public internet. Backed by AWS PrivateLink.

**Key properties:**
- Supports ~100+ AWS services (SSM, Secrets Manager, KMS, STS, ECR, etc.)
- `private_dns_enabled = true` overrides the public DNS name (e.g., `ssm.us-east-1.amazonaws.com` resolves to the private endpoint IP)
- Supports endpoint policies (restrict which actions/resources are accessible)
- Billed per hour per AZ + per GB of data processed

### Gateway vs Interface Endpoints

| Feature | Gateway | Interface |
|---------|---------|-----------|
| Services | S3, DynamoDB only | 100+ services |
| Implementation | Route table entry | ENI in subnet |
| Cost | Free | $/hr + $/GB |
| Security groups | Not supported | Supported |
| Private DNS | Not supported | Supported |
| On-premises access | No | Yes (via VPN/DX) |

### AWS PrivateLink (Endpoint Service)
Lets you expose your own services to other VPCs or AWS accounts over private connectivity. Architecture:
1. Your service runs behind a **Network Load Balancer**.
2. You create an **Endpoint Service** linked to the NLB.
3. Consumers create **Interface Endpoints** pointing to your service name.
4. Traffic never leaves the AWS network.

Use cases: SaaS providers, internal shared services across accounts, AWS Marketplace offerings.

### Private DNS
When `private_dns_enabled = true`, AWS creates Route 53 private hosted zone records in your VPC. Requires `enableDnsHostnames = true` and `enableDnsSupport = true` on the VPC. For endpoint services, you can configure a custom domain name after verifying ownership via a TXT record.
