output "interface_endpoint_ids" {
  description = "Map of logical name → interface endpoint ID."
  value       = { for k, v in aws_vpc_endpoint.interface : k => v.id }
}

output "interface_endpoint_arns" {
  description = "Map of logical name → interface endpoint ARN."
  value       = { for k, v in aws_vpc_endpoint.interface : k => v.arn }
}

output "interface_endpoint_dns_entries" {
  description = "Map of logical name → list of DNS entry objects (dns_name, hosted_zone_id)."
  value       = { for k, v in aws_vpc_endpoint.interface : k => v.dns_entry }
}

output "interface_endpoint_network_interface_ids" {
  description = "Map of logical name → list of network interface IDs for the endpoint ENIs."
  value       = { for k, v in aws_vpc_endpoint.interface : k => v.network_interface_ids }
}

output "endpoint_service_id" {
  description = "ID of the PrivateLink endpoint service."
  value       = length(aws_vpc_endpoint_service.this) > 0 ? aws_vpc_endpoint_service.this[0].id : null
}

output "endpoint_service_name" {
  description = "Service name of the PrivateLink endpoint service (share with consumers)."
  value       = length(aws_vpc_endpoint_service.this) > 0 ? aws_vpc_endpoint_service.this[0].service_name : null
}

output "endpoint_service_arn" {
  description = "ARN of the PrivateLink endpoint service."
  value       = length(aws_vpc_endpoint_service.this) > 0 ? aws_vpc_endpoint_service.this[0].arn : null
}

output "endpoint_service_availability_zones" {
  description = "Availability zones in which the endpoint service is available."
  value       = length(aws_vpc_endpoint_service.this) > 0 ? aws_vpc_endpoint_service.this[0].availability_zones : []
}

output "endpoint_service_private_dns_name_configuration" {
  description = "Private DNS name configuration (TXT record for domain ownership verification)."
  value       = length(aws_vpc_endpoint_service.this) > 0 ? aws_vpc_endpoint_service.this[0].private_dns_name_configuration : null
}
