variable "name" {
  description = "Name prefix for all resources."
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC in which to create interface endpoints."
  type        = string
}

variable "subnet_ids" {
  description = "List of subnet IDs to create endpoint ENIs in (one per AZ for HA)."
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security group IDs to attach to endpoint ENIs."
  type        = list(string)
  default     = []
}

# ── Interface Endpoints ────────────────────────────────────────────────────────
variable "interface_endpoints" {
  description = <<-EOT
    Map of Interface VPC Endpoints to create.
    Key = short logical name (e.g. "ssm", "ec2messages")
    Value = object with:
      service_name      – full service name OR short alias (ec2, ssm, etc. — module prefixes "com.amazonaws.<region>.")
      private_dns_enabled – bool (default true)
      policy            – optional IAM policy JSON
  EOT
  type = map(object({
    service_name        = string
    private_dns_enabled = optional(bool, true)
    policy              = optional(string)
  }))
  default = {}
}

# ── PrivateLink Endpoint Service (provider side) ──────────────────────────────
variable "create_endpoint_service" {
  description = "Create a PrivateLink Endpoint Service backed by an NLB."
  type        = bool
  default     = false
}

variable "endpoint_service_nlb_arns" {
  description = "List of NLB ARNs that back the endpoint service."
  type        = list(string)
  default     = []
}

variable "endpoint_service_acceptance_required" {
  description = "Require manual acceptance for endpoint connection requests."
  type        = bool
  default     = true
}

variable "endpoint_service_allowed_principals" {
  description = "List of IAM principal ARNs (accounts, roles, users) allowed to create connections to the endpoint service."
  type        = list(string)
  default     = []
}

variable "endpoint_service_private_dns_name" {
  description = "Optional private DNS name for the endpoint service (requires Route 53 domain ownership verification)."
  type        = string
  default     = null
}

variable "tags" {
  description = "Map of tags applied to all resources."
  type        = map(string)
  default     = {}
}
