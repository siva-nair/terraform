variable "name" {
  description = "Name prefix for all VPC Lattice resources."
  type        = string
}

# ---------------------------------------------------------------------------
# Service Network
# ---------------------------------------------------------------------------
variable "auth_type" {
  description = "Authentication type for the service network and services: NONE or AWS_IAM."
  type        = string
  default     = "AWS_IAM"
  validation {
    condition     = contains(["NONE", "AWS_IAM"], var.auth_type)
    error_message = "auth_type must be 'NONE' or 'AWS_IAM'."
  }
}

# ---------------------------------------------------------------------------
# Services
# ---------------------------------------------------------------------------
variable "services" {
  description = "Map of VPC Lattice services to create. Key is a logical name."
  type = map(object({
    name                = optional(string, "")
    custom_domain_name  = optional(string, "")
    auth_type           = optional(string, "AWS_IAM")
    certificate_arn     = optional(string, "")
    port                = optional(number, 80)
    protocol            = optional(string, "HTTP")
    default_action_type = optional(string, "forward") # forward or fixed-response
    fixed_response_code = optional(number, 404)
  }))
  default = {}
}

# ---------------------------------------------------------------------------
# Target Groups
# ---------------------------------------------------------------------------
variable "target_groups" {
  description = "Map of VPC Lattice target groups. Key is a logical name."
  type = map(object({
    type                  = string # IP, LAMBDA, ALB, INSTANCE
    vpc_id                = optional(string, "")
    port                  = optional(number, 80)
    protocol              = optional(string, "HTTP")
    protocol_version      = optional(string, "HTTP1")
    health_check_enabled  = optional(bool, true)
    health_check_path     = optional(string, "/")
    health_check_protocol = optional(string, "HTTP")
  }))
  default = {}
}

# ---------------------------------------------------------------------------
# Listeners
# ---------------------------------------------------------------------------
variable "listeners" {
  description = "Map of listeners. Key format: 'service_key:listener_name'."
  type = map(object({
    service_key         = string
    port                = optional(number, 80)
    protocol            = optional(string, "HTTP")
    default_action_type = optional(string, "forward")
    target_group_key    = optional(string, "")
    fixed_response_code = optional(number, 404)
  }))
  default = {}
}

# ---------------------------------------------------------------------------
# Service-to-Service-Network Association
# ---------------------------------------------------------------------------
variable "service_network_associations" {
  description = "Map of service keys to associate with the service network."
  type        = map(string) # key = logical name, value = service key
  default     = {}
}

# ---------------------------------------------------------------------------
# VPC-to-Service-Network Association
# ---------------------------------------------------------------------------
variable "vpc_associations" {
  description = "Map of VPC IDs to associate with the service network."
  type = map(object({
    vpc_id             = string
    security_group_ids = optional(list(string), [])
  }))
  default = {}
}

# ---------------------------------------------------------------------------
# Auth Policies
# ---------------------------------------------------------------------------
variable "service_network_auth_policy" {
  description = "IAM policy JSON for the service network auth policy."
  type        = string
  default     = ""
}

variable "service_auth_policies" {
  description = "Map of service key to IAM policy JSON for service-level auth."
  type        = map(string)
  default     = {}
}

# ---------------------------------------------------------------------------
# Access Log Subscriptions
# ---------------------------------------------------------------------------
variable "access_log_subscriptions" {
  description = "Map of access log subscriptions. Value is the destination ARN (CW Logs, S3, or Firehose)."
  type = map(object({
    resource_key    = string # 'network' or a service key
    destination_arn = string
  }))
  default = {}
}

variable "tags" {
  description = "Map of tags to apply to all resources."
  type        = map(string)
  default     = {}
}
