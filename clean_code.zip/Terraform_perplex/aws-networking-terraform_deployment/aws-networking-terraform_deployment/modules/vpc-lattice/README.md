# vpc-lattice

Terraform module for **Amazon VPC Lattice** — a fully managed application networking service that connects, secures, and monitors service-to-service communication across VPCs and AWS accounts without VPC peering, Transit Gateway, or complex networking configuration.

## Resources Created

| Resource | Description |
|---|---|
| `aws_vpclattice_service_network` | Central mesh fabric for services |
| `aws_vpclattice_auth_policy` (network) | IAM-based access policy for the service network |
| `aws_vpclattice_service` | Individual service endpoints |
| `aws_vpclattice_auth_policy` (service) | Per-service IAM access policies |
| `aws_vpclattice_target_group` | Target groups (IP, Lambda, ALB, Instance) |
| `aws_vpclattice_listener` | Service listeners with default forwarding actions |
| `aws_vpclattice_service_network_service_association` | Links services to the network |
| `aws_vpclattice_service_network_vpc_association` | Links VPCs to the network |
| `aws_vpclattice_access_log_subscription` | Access logging to CloudWatch/S3/Firehose |

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| `name` | Resource name prefix | `string` | — | yes |
| `auth_type` | `NONE` or `AWS_IAM` | `string` | `AWS_IAM` | no |
| `services` | Map of service definitions | `map(object)` | `{}` | no |
| `target_groups` | Map of target group definitions | `map(object)` | `{}` | no |
| `listeners` | Map of listener definitions | `map(object)` | `{}` | no |
| `service_network_associations` | Services to associate with network | `map(string)` | `{}` | no |
| `vpc_associations` | VPCs to associate with network | `map(object)` | `{}` | no |
| `service_network_auth_policy` | Service network IAM policy JSON | `string` | `""` | no |
| `service_auth_policies` | Map of service → IAM policy JSON | `map(string)` | `{}` | no |
| `access_log_subscriptions` | Map of access log destinations | `map(object)` | `{}` | no |
| `tags` | Tags for all resources | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|---|---|
| `service_network_id` | Service network ID |
| `service_network_arn` | Service network ARN |
| `service_ids` | Map of service name → ID |
| `service_arns` | Map of service name → ARN |
| `service_dns_entries` | Map of service name → DNS entry |
| `target_group_ids` | Map of TG name → ID |
| `target_group_arns` | Map of TG name → ARN |
| `listener_arns` | Map of listener name → ARN |
| `vpc_association_ids` | Map of VPC assoc name → ID |

## Usage Example

```hcl
module "vpc_lattice" {
  source = "./modules/vpc-lattice"

  name      = "platform-mesh"
  auth_type = "AWS_IAM"

  services = {
    payment-api = {
      port     = 443
      protocol = "HTTPS"
    }
    user-api = {
      port     = 80
      protocol = "HTTP"
    }
  }

  target_groups = {
    payment-tg = {
      type     = "IP"
      vpc_id   = module.vpc.vpc_id
      port     = 8080
      protocol = "HTTP"
    }
    user-lambda-tg = {
      type = "LAMBDA"
    }
  }

  listeners = {
    payment-http = {
      service_key      = "payment-api"
      port             = 80
      protocol         = "HTTP"
      target_group_key = "payment-tg"
    }
    user-http = {
      service_key      = "user-api"
      port             = 80
      protocol         = "HTTP"
      target_group_key = "user-lambda-tg"
    }
  }

  service_network_associations = {
    payment = "payment-api"
    user    = "user-api"
  }

  vpc_associations = {
    app-vpc = {
      vpc_id             = module.app_vpc.vpc_id
      security_group_ids = [aws_security_group.lattice.id]
    }
  }

  service_network_auth_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { AWS = "REDACTED_AWS_ARN" }
      Action    = "vpc-lattice-svcs:Invoke"
      Resource  = "*"
    }]
  })

  access_log_subscriptions = {
    network-logs = {
      resource_key    = "network"
      destination_arn = "REDACTED_AWS_ARN"
    }
  }

  tags = { Environment = "prod" }
}
```

## Concepts (Exam Prep)

**Amazon VPC Lattice** replaces the need for complex VPC networking (peering, TGW, NLB with PrivateLink) for service-to-service communication. Key concepts:

- **Service Network**: The central mesh. VPCs and services are associated to it. A single service network can span multiple accounts and VPCs. Clients in associated VPCs can discover and call associated services.
- **Service**: Represents a single application endpoint. Has a generated Lattice DNS name (`<svc-id>.svc.lattice.local`). Can have a custom domain. Has one or more listeners.
- **Target Groups**: Define where traffic is sent:
  - `IP`: Specific IPs in a VPC (ECS tasks, pods)
  - `INSTANCE`: EC2 instances
  - `ALB`: Application Load Balancer (uses ALB routing)
  - `LAMBDA`: Lambda functions
- **Auth Policies**: IAM resource-based policies attached to the service network or individual services. Enable attribute-based access control (ABAC) using conditions like `vpc-lattice-svcs:SourceVpc`, `aws:PrincipalAccount`.
- **VPC Association**: Associates a VPC with the service network. Creates a Lattice managed ENI in the VPC. Traffic to Lattice DNS names routes through this ENI.
- **Service Association**: Links a service to a network. Without this, the service is not discoverable via that network.
- **Access Logs**: Capture request-level metadata (source VPC, auth result, response code, latency). Sent to CloudWatch Logs, S3, or Kinesis Firehose.
- **vs PrivateLink**: VPC Lattice doesn't require creating an NLB or endpoint service. Services are auto-discoverable and can forward to Lambda (not possible with PrivateLink). PrivateLink is still used for third-party SaaS.
- **Cross-account**: Use AWS RAM to share the service network or individual services across accounts. Consumer accounts associate their VPCs with the shared network.
