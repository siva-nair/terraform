data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  common_tags = merge(
    {
      Name      = var.name
      ManagedBy = "terraform"
    },
    var.tags
  )

  # Default service network auth policy (allow all authenticated principals)
  default_auth_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "vpc-lattice-svcs:Invoke"
        Resource  = "*"
        Condition = {
          StringEquals = {
            "vpc-lattice-svcs:RequestedAccessMode" = ["unauthenticated", "authenticated"]
          }
        }
      }
    ]
  })
}

# ---------------------------------------------------------------------------
# Service Network
# ---------------------------------------------------------------------------
resource "aws_vpclattice_service_network" "this" {
  name      = var.name
  auth_type = var.auth_type

  tags = merge(local.common_tags, { Name = var.name })
}

# ---------------------------------------------------------------------------
# Service Network Auth Policy
# ---------------------------------------------------------------------------
resource "aws_vpclattice_auth_policy" "network" {
  count = var.auth_type == "AWS_IAM" ? 1 : 0

  resource_identifier = aws_vpclattice_service_network.this.arn
  policy              = var.service_network_auth_policy != "" ? var.service_network_auth_policy : local.default_auth_policy
}

# ---------------------------------------------------------------------------
# Services
# ---------------------------------------------------------------------------
resource "aws_vpclattice_service" "this" {
  for_each = var.services

  name               = each.value.name != "" ? each.value.name : "${var.name}-${each.key}"
  auth_type          = each.value.auth_type
  custom_domain_name = each.value.custom_domain_name != "" ? each.value.custom_domain_name : null
  certificate_arn    = each.value.certificate_arn != "" ? each.value.certificate_arn : null

  tags = merge(local.common_tags, { Name = "${var.name}-${each.key}" })
}

# ---------------------------------------------------------------------------
# Service Auth Policies
# ---------------------------------------------------------------------------
resource "aws_vpclattice_auth_policy" "service" {
  for_each = {
    for k, v in var.service_auth_policies : k => v
    if contains(keys(var.services), k)
  }

  resource_identifier = aws_vpclattice_service.this[each.key].arn
  policy              = each.value
}

# ---------------------------------------------------------------------------
# Target Groups
# ---------------------------------------------------------------------------
resource "aws_vpclattice_target_group" "this" {
  for_each = var.target_groups

  name = "${var.name}-${each.key}-tg"
  type = each.value.type

  dynamic "config" {
    for_each = each.value.type != "LAMBDA" ? [1] : []
    content {
      port             = each.value.port
      protocol         = each.value.protocol
      protocol_version = each.value.protocol_version
      vpc_identifier   = each.value.vpc_id != "" ? each.value.vpc_id : null

      dynamic "health_check" {
        for_each = each.value.health_check_enabled ? [1] : []
        content {
          enabled                   = true
          path                      = each.value.health_check_path
          protocol                  = each.value.health_check_protocol
          healthy_threshold_count   = 3
          unhealthy_threshold_count = 2
        }
      }
    }
  }

  tags = merge(local.common_tags, { Name = "${var.name}-${each.key}-tg" })
}

# ---------------------------------------------------------------------------
# Listeners
# ---------------------------------------------------------------------------
resource "aws_vpclattice_listener" "this" {
  for_each = var.listeners

  service_identifier = aws_vpclattice_service.this[each.value.service_key].id
  name               = "${each.value.service_key}-${each.key}"
  port               = each.value.port
  protocol           = each.value.protocol

  default_action {
    dynamic "forward" {
      for_each = each.value.default_action_type == "forward" && each.value.target_group_key != "" ? [1] : []
      content {
        target_groups {
          target_group_identifier = aws_vpclattice_target_group.this[each.value.target_group_key].id
          weight                  = 100
        }
      }
    }

    dynamic "fixed_response" {
      for_each = each.value.default_action_type == "fixed-response" ? [1] : []
      content {
        status_code = each.value.fixed_response_code
      }
    }
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Service Network ↔ Service Associations
# ---------------------------------------------------------------------------
resource "aws_vpclattice_service_network_service_association" "this" {
  for_each = var.service_network_associations

  service_network_identifier = aws_vpclattice_service_network.this.id
  service_identifier         = aws_vpclattice_service.this[each.value].id

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Service Network ↔ VPC Associations
# ---------------------------------------------------------------------------
resource "aws_vpclattice_service_network_vpc_association" "this" {
  for_each = var.vpc_associations

  service_network_identifier = aws_vpclattice_service_network.this.id
  vpc_identifier             = each.value.vpc_id
  security_group_ids         = each.value.security_group_ids

  tags = merge(local.common_tags, { Name = "${var.name}-vpc-assoc-${each.key}" })
}

# ---------------------------------------------------------------------------
# Access Log Subscriptions
# ---------------------------------------------------------------------------
resource "aws_vpclattice_access_log_subscription" "this" {
  for_each = var.access_log_subscriptions

  resource_identifier = (
    each.value.resource_key == "network"
    ? aws_vpclattice_service_network.this.arn
    : aws_vpclattice_service.this[each.value.resource_key].arn
  )
  destination_arn = each.value.destination_arn

  tags = local.common_tags
}
