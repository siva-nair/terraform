output "service_network_id" {
  description = "ID of the VPC Lattice service network."
  value       = aws_vpclattice_service_network.this.id
}

output "service_network_arn" {
  description = "ARN of the VPC Lattice service network."
  value       = aws_vpclattice_service_network.this.arn
}

output "service_ids" {
  description = "Map of service logical name to service ID."
  value = {
    for k, v in aws_vpclattice_service.this : k => v.id
  }
}

output "service_arns" {
  description = "Map of service logical name to service ARN."
  value = {
    for k, v in aws_vpclattice_service.this : k => v.arn
  }
}

output "service_dns_entries" {
  description = "Map of service logical name to DNS entry for the service."
  value = {
    for k, v in aws_vpclattice_service.this : k => v.dns_entry
  }
}

output "target_group_ids" {
  description = "Map of target group logical name to ID."
  value = {
    for k, v in aws_vpclattice_target_group.this : k => v.id
  }
}

output "target_group_arns" {
  description = "Map of target group logical name to ARN."
  value = {
    for k, v in aws_vpclattice_target_group.this : k => v.arn
  }
}

output "listener_arns" {
  description = "Map of listener logical name to ARN."
  value = {
    for k, v in aws_vpclattice_listener.this : k => v.arn
  }
}

output "vpc_association_ids" {
  description = "Map of VPC association logical name to ID."
  value = {
    for k, v in aws_vpclattice_service_network_vpc_association.this : k => v.id
  }
}
