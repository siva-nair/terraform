# AWS Networking Terraform Lab — Deployment Guide

This guide covers every step from first-time AWS SSO configuration through tearing the lab down, for the Terraform-managed AWS networking environment under `deploy/`. The lab is structured around three cost tiers (`minimal`, `standard`, `full`) that progressively instantiate 22 Terraform modules — one per topic area on the AWS Advanced Networking Specialty (ANS-C01) exam. All state is local by default. Auth is AWS IAM Identity Center (SSO). Region default is `us-east-1`. A Budgets alarm fires at 80% forecasted and 100% actual against a $20/month cap.

---

## Table of Contents

1. [What Gets Deployed](#1-what-gets-deployed)
2. [Prerequisites](#2-prerequisites)
3. [One-Time Setup](#3-one-time-setup)
4. [First Deploy — Minimal Tier](#4-first-deploy--minimal-tier)
5. [Upgrading the Tier](#5-upgrading-the-tier)
6. [Module Reference Table](#6-module-reference-table)
7. [Tier-by-Tier Resource Inventory](#7-tier-by-tier-resource-inventory)
8. [Verifying the Deploy](#8-verifying-the-deploy)
9. [Customizing — Adding Your Own Resources](#9-customizing--adding-your-own-resources)
10. [Troubleshooting](#10-troubleshooting)
11. [Costs and Guardrails](#11-costs-and-guardrails)
12. [Tearing It Down](#12-tearing-it-down)
13. [Mapping Deploy Modules to Exam Topics](#13-mapping-deploy-modules--exam-topics)
14. [What Is Not Auto-Deployed and Why](#14-what-is-not-auto-deployed-and-why)
15. [Source and Further Reading](#15-source--further-reading)

---

## 1. What Gets Deployed

| Tier | Incremental modules enabled | Rough $/day | When to use |
|------|-----------------------------|-------------|-------------|
| **minimal** | Primary VPC (10.10.0.0/16, 2 AZs), IGW, NAT GW (single), public + private subnets, S3 + DynamoDB gateway endpoints, ALB (internet-facing, HTTP:80, no targets), NACL + SG baseline | ~$1–3 | Always-on study base |
| **standard** | Everything in minimal, plus: secondary VPC (10.20.0.0/16), TGW with two VPC attachments + cross-VPC routes, S2S VPN attached to TGW (simulated CGW — tunnels DOWN expected), VPC peering between primary and secondary (alternate path), Route 53 private zone (`lab.internal`) associated with both VPCs, DHCP options set + R53 Resolver inbound/outbound endpoints, VPC Flow Logs (CloudWatch + S3), interface endpoints for SSM/SSMMessages/EC2Messages/Logs, placement groups (cluster/spread/partition) | ~$5–15 | Deep-dive study sessions |
| **full** | Everything in standard, plus: AWS Network Firewall (public subnets) + WAFv2 Regional Web ACL (AWSManagedRulesCommonRuleSet), GWLB in inspection VPC (10.30.0.0/16) + GWLBe in primary VPC, Client VPN endpoint (only if cert ARNs supplied), EKS cluster `anslab-lab-eks` (1×t3.medium managed node group), CloudFront distribution backed by S3 origin, Cloud WAN core network + global network, VPC Lattice service network (IAM auth), Network Manager + CloudTrail + flow log group, Hybrid Networks (2 sample CGWs; no real VGW or DX-GW created) | ~$50–100+ | Exam-week full coverage; destroy same day |

> **Cost warning:** `full` tier includes an EKS cluster (~$0.10/hr control plane) and a managed NAT GW ($0.045/hr each). Do not leave `full` running overnight unless you intend to pay for it. Use `./destroy.sh` when done.

---

## 2. Prerequisites

### AWS account

Admin or near-admin permissions are required. At minimum, the IAM principal needs:

- `ec2:*`, `elasticloadbalancing:*`, `route53:*`, `logs:*`, `s3:*`
- `eks:*`, `cloudfront:*`, `wafv2:*`, `network-firewall:*`
- `networkmanager:*`, `budgets:*`, `iam:PassRole`, `iam:CreateRole`, `iam:CreatePolicy`
- `vpclattice:*`, `ec2:DescribeTransitGateway*`, `ec2:CreateTransitGateway*`

Using a role with `AdministratorAccess` is the simplest approach for a personal lab account.

### IAM Identity Center (AWS SSO)

IAM Identity Center must be enabled for the account. The profile created in Section 3 authenticates Terraform API calls via short-lived STS tokens derived from your SSO session. No long-lived IAM access keys are used.

### Terraform >= 1.9

```bash
# Linux amd64 — adjust version/arch as needed
TERRAFORM_VERSION=1.9.8
curl -fsSL \
  "https://releases.hashicorp.com/terraform/${TERRAFORM_VERSION}/terraform_${TERRAFORM_VERSION}_linux_amd64.zip" \
  -o /tmp/terraform.zip
unzip -o /tmp/terraform.zip -d /tmp/
sudo install -m 0755 /tmp/terraform /usr/local/bin/terraform
terraform version
```

### AWS CLI v2

```bash
# Linux amd64
curl -fsSL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o /tmp/awscliv2.zip
unzip -o /tmp/awscliv2.zip -d /tmp/
sudo /tmp/aws/install --update
aws --version
```

### Optional utilities

```bash
# jq — used by the cost query in Section 11
sudo apt-get install -y jq git   # Debian/Ubuntu
# or
sudo dnf install -y jq git       # Amazon Linux / RHEL
```

---

## 3. One-Time Setup

### Configure AWS CLI for SSO

Run the interactive setup once per profile:

```bash
aws configure sso

Current:
aws sts get-caller-identity              
{                                                                                                                                                                                                         
    "UserId": "REDACTED_AWS_ACCOUNT_ID",
    "Account": "REDACTED_AWS_ACCOUNT_ID",
    "Arn": "REDACTED_AWS_ARN"
}
```

Prompts and example responses:

| Prompt | Example value | Notes |
|--------|---------------|-------|
| SSO session name | `lab-session` | Arbitrary; identifies the SSO session |
| SSO start URL | `https://d-xxxxxxxxxx.awsapps.com/start` | From IAM Identity Center console |
| SSO region | `us-east-1` | Region where Identity Center is hosted |
| SSO registration scopes | `sso:account:access` | Accept default |
| AWS account ID | `REDACTED_AWS_ACCOUNT_ID` | Your account |
| Role to assume | `AdministratorAccess` | Or whatever permission set you have |
| Default output format | `json` | Recommended |
| Profile name | `lab` | **Use `lab` to match the defaults in `terraform.tfvars`** |

This writes a `~/.aws/config` entry similar to:

```ini
[profile lab]
sso_session      = lab-session
sso_account_id   = REDACTED_AWS_ACCOUNT_ID
sso_role_name    = AdministratorAccess
region           = us-east-1
output           = json

[sso-session lab-session]
sso_start_url              = https://d-xxxxxxxxxx.awsapps.com/start
sso_region                 = us-east-1
sso_registration_scopes    = sso:account:access
```

#### Refreshing the SSO session

SSO tokens are valid for 8–12 hours (configured in Identity Center). Refresh on demand:

```bash
aws sso login --profile lab
```

This opens a browser for the AWS access portal. After you approve the request, the CLI writes a cached token to `~/.aws/sso/cache/`.

#### Verify authentication

```bash
aws sts get-caller-identity --profile lab
```

Expected output:

```json
{
    "UserId": "AROA...:lab-session",
    "Account": "REDACTED_AWS_ACCOUNT_ID",
    "Arn": "REDACTED_AWS_ARN"
}
```

### Clone or extract the repo

```bash
git clone <repo-url> aws-networking-terraform
cd aws-networking-terraform/deploy
```

Or, if working from an archive:

```bash
unzip aws-networking-terraform.zip
cd aws-networking-terraform/deploy
```

### Configure `terraform.tfvars`

```bash
cp terraform.tfvars.example terraform.tfvars
```

Edit the file. The minimum set of values to review before first apply:

```hcl
aws_profile          = "lab"           # must match the profile name from aws configure sso
aws_region           = "us-east-1"
tier                 = "minimal"       # start here; change to standard or full later

primary_vpc_cidr     = "10.10.0.0/16"
single_nat_gateway   = true            # false = one NAT GW per AZ; costs more

budget_alarm_email   = "your@email.com"
monthly_budget_usd   = 20
```

`terraform.tfvars` is in `.gitignore` — it will not be committed.

---

## 4. First Deploy — Minimal Tier

### SSO login flow

The diagram below shows what happens from `aws sso login` through Terraform creating a resource:

```mermaid
sequenceDiagram
    participant You
    participant AWSCLI as AWS CLI
    participant Browser
    participant IAMIdC as IAM Identity Center
    participant TF as Terraform
    participant AWSAPI as AWS EC2/ELB API

    You->>AWSCLI: aws sso login --profile lab
    AWSCLI->>Browser: open SSO start URL
    Browser->>IAMIdC: authenticate (MFA if required)
    IAMIdC-->>AWSCLI: short-lived SSO token (8-12h)
    AWSCLI-->>You: Login succeeded

    You->>TF: ./apply.sh
    TF->>AWSCLI: read profile "lab" from ~/.aws/config
    AWSCLI->>IAMIdC: exchange SSO token → STS AssumeRoleWithWebIdentity
    IAMIdC-->>AWSCLI: temporary credentials (AccessKeyId, SecretKey, SessionToken)
    AWSCLI-->>TF: credentials injected into provider

    TF->>AWSAPI: terraform plan (DescribeVpcs, ListLoadBalancers, ...)
    AWSAPI-->>TF: current state responses

    You->>TF: confirm "Apply this plan? [y/N]"
    TF->>AWSAPI: CreateVpc, CreateSubnet, CreateInternetGateway, ...
    AWSAPI-->>TF: resource IDs
    TF-->>You: Apply complete. Resources created.
```

### Steps

```bash
cd aws-networking-terraform/deploy

# Set profile for the shell session so apply.sh picks it up automatically
export AWS_PROFILE=lab

# Ensure session is fresh (apply.sh does this automatically, but good habit)
aws sso login --profile lab

# Run the full init → validate → plan → apply workflow
./apply.sh
```

#### What `apply.sh` does, step by step

| Step | Command | Purpose |
|------|---------|---------|
| 1 | `aws sts get-caller-identity` | Checks if SSO session is valid; calls `aws sso login` if it fails |
| 2 | Prints caller identity | Confirms the role being used before any changes |
| 3 | `terraform init -upgrade` | Downloads providers (hashicorp/aws ~> 5.70, tls ~> 4.0, random ~> 3.6); writes `.terraform.lock.hcl` |
| 4 | `terraform validate` | Validates HCL syntax and provider schema compliance |
| 5 | `terraform plan -out=tfplan` | Generates and saves the execution plan with `-var aws_profile=$PROFILE` |
| 6 | Interactive prompt | Prints the plan diff and waits for `y` confirmation (pass `-auto` to skip) |
| 7 | `terraform apply tfplan` | Executes the saved plan |
| 8 | `rm -f tfplan` | Deletes the plan file to avoid stale applies |

Use `./apply.sh -auto` only in non-interactive pipelines where you have reviewed the plan output separately.

### Expected outputs after minimal apply

```bash
terraform output
```

| Output key | Example value | What it means |
|------------|---------------|---------------|
| `tier` | `"minimal"` | Active tier |
| `primary_vpc_id` | `"vpc-0abc123..."` | Primary VPC |
| `primary_vpc_cidr` | `"10.10.0.0/16"` | VPC CIDR |
| `primary_public_subnets` | `["subnet-0a...", "subnet-0b..."]` | 2 public subnets |
| `primary_private_subnets` | `["subnet-0c...", "subnet-0d..."]` | 2 private subnets |
| `secondary_vpc_id` | `null` | Not created in minimal |
| `alb_dns_name` | `"anslab-lab-alb-xxxx.us-east-1.elb.amazonaws.com"` | Public ALB |
| `transit_gateway_id` | `null` | Not created in minimal |
| `vpn_connection_id` | `null` | Not created in minimal |
| `route53_private_zone_id` | `null` | Not created in minimal |
| `cloudfront_domain` | `null` | Not created in minimal |
| `eks_cluster_endpoint` | `null` | Not created in minimal |
| `monthly_budget_alarm` | `"Budget 'anslab-lab-monthly-cap' set to $20/mo..."` | Budget details |

### Verify in the AWS Console

Direct links (substitute your account's region if different):

- VPCs: `https://console.aws.amazon.com/vpc/home?region=us-east-1#vpcs:`
- Subnets: `https://console.aws.amazon.com/vpc/home?region=us-east-1#subnets:`
- Load Balancers: `https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#LoadBalancers:`
- Endpoints (gateway): `https://console.aws.amazon.com/vpc/home?region=us-east-1#Endpoints:`
- Security Groups: `https://console.aws.amazon.com/vpc/home?region=us-east-1#SecurityGroups:`

---

## 5. Upgrading the Tier

### Tier upgrade path

```mermaid
flowchart TD
    A[minimal\nPrimary VPC + IGW + NAT GW\nS3/DDB gateway endpoints\nALB + NACL/SG baseline] --> B[standard\nAdds:]
    B --> B1[Secondary VPC 10.20.0.0/16]
    B --> B2[Transit Gateway\n2 VPC attachments + cross-VPC routes]
    B --> B3[S2S VPN → TGW\nSimulated CGW tunnels DOWN]
    B --> B4[VPC Peering\nprimary ↔ secondary alternate path]
    B --> B5[Route 53 private zone lab.internal\nDHCP options set\nR53 Resolver inbound + outbound]
    B --> B6[VPC Flow Logs\nCloudWatch + S3 7-day retention]
    B --> B7[Interface endpoints\nSSM / SSMMessages / EC2Messages / Logs]
    B --> B8[Placement groups\ncluster / spread / partition]
    B1 & B2 & B3 & B4 & B5 & B6 & B7 & B8 --> C[full\nAdds:]
    C --> C1[Network Firewall\nstateless forward-to-sfe + WAFv2 Regional]
    C --> C2[GWLB inspection VPC 10.30.0.0/16\n+ GWLBe in primary VPC]
    C --> C3[Client VPN endpoint\nonly if cert ARNs supplied]
    C --> C4[EKS cluster anslab-lab-eks\n1x t3.medium managed node group]
    C --> C5[CloudFront + S3 origin\nOAC sigv4 + WAFv2 CloudFront scope]
    C --> C6[Cloud WAN\nglobal network + core network]
    C --> C7[VPC Lattice service network\nIAM auth]
    C --> C8[Network Manager + CloudTrail\n+ flow log group]
    C --> C9[Hybrid Networks\n2 sample CGWs no real VGW/DX]
```

### Upgrade to standard

Edit `terraform.tfvars`:

```hcl
tier = "standard"
```

Then apply:

```bash
./apply.sh
```

The plan will show additions including:
- `module.secondary_vpc[0]` — second VPC
- `module.transit_gateway[0]` — TGW with 2 attachments
- `aws_route.primary_to_secondary_via_tgw[*]` — cross-VPC routes
- `module.vpc_peering[0]` — peering connection + routes
- `aws_customer_gateway.sim[0]` + `module.site_to_site_vpn[0]` — simulated CGW + VPN
- `module.route53[0]` — private hosted zone
- `module.vpc_dns_dhcp[0]` — DHCP options + Resolver endpoints
- `module.vpc_additional_features[0]` — flow logs
- `module.interface_endpoints[0]` — SSM/EC2 interface endpoints
- `module.vpc_network_performance[0]` — placement groups

Estimated additional resources in the plan: ~40–60.

### Upgrade to full

> **Cost warning:** `full` tier adds an EKS cluster, Network Firewall, GWLB, Cloud WAN, and CloudFront. Leaving it running for 24 hours will cost $50–100+. Plan your study session accordingly and run `./destroy.sh` when finished.

```hcl
tier = "full"
```

```bash
./apply.sh
```

Notable new plan additions:
- `module.inspection_vpc[0]` — third VPC
- `module.gateway_load_balancer[0]` — GWLB + endpoint service + GWLBe
- `module.network_security_baseline` — updated to also create Network Firewall + WAFv2
- `module.eks[0]` — EKS cluster + managed node group (~15–20 min to provision)
- `module.cloudfront[0]` — CloudFront distribution (~10–15 min to deploy globally)
- `module.cloud_wan[0]` — Cloud WAN core network
- `module.vpc_lattice[0]` — VPC Lattice service network
- `module.management_governance[0]` — Network Manager + CloudTrail
- `module.hybrid_networks[0]` — CGW records

CloudFront and EKS are the two slowest resources; normal apply times for `full` are 20–30 minutes.

---

## 6. Module Reference Table

| Module directory | AWS resources created | Tiers | Key outputs |
|------------------|-----------------------|-------|-------------|
| [`vpc-fundamentals`](modules/vpc-fundamentals/README.md) | `aws_vpc`, `aws_internet_gateway`, `aws_subnet` (pub+priv), `aws_eip`, `aws_nat_gateway`, `aws_route_table` ×2, `aws_default_network_acl`, `aws_default_security_group` | all | `vpc_id`, `vpc_cidr_block`, `public_subnet_ids`, `private_subnet_ids`, `public_route_table_id`, `private_route_table_ids` |
| [`vpc-gateway-endpoints`](modules/vpc-gateway-endpoints/README.md) | `aws_vpc_endpoint` ×2 (S3 + DynamoDB), `data.aws_prefix_list` ×2 | all | `s3_endpoint_id`, `dynamodb_endpoint_id`, `s3_prefix_list_id`, `dynamodb_prefix_list_id` |
| [`elastic-load-balancing`](modules/elastic-load-balancing/README.md) | `aws_lb` (ALB), `aws_lb_target_group`, `aws_lb_listener` (HTTP), optional HTTPS listener + listener rules | all | `lb_arn`, `lb_dns_name`, `lb_zone_id`, `target_group_arn` |
| [`network-security`](modules/network-security/README.md) | `aws_network_acl`, `aws_security_group` (1+), optionally `aws_networkfirewall_*` ×4, `aws_wafv2_web_acl` | all (firewall+WAF: full only) | `nacl_id`, `security_group_ids`, `firewall_arn`, `waf_web_acl_arn` |
| [`vpc-dns-dhcp`](modules/vpc-dns-dhcp/README.md) | `aws_vpc_dhcp_options`, `aws_vpc_dhcp_options_association`, `aws_route53_resolver_endpoint` ×2, `aws_route53_resolver_rule`, `aws_route53_resolver_rule_association` | standard+ | `dhcp_options_id`, `resolver_inbound_endpoint_id`, `resolver_outbound_endpoint_id` |
| [`vpc-additional-features`](modules/vpc-additional-features/README.md) | `aws_cloudwatch_log_group`, `aws_iam_role` + policy, `aws_flow_log` ×2, `aws_ec2_network_insights_path`, `aws_ec2_network_insights_access_scope` | standard+ | `flow_log_cloudwatch_id`, `flow_log_s3_id` |
| [`vpc-interface-endpoints-privatelink`](modules/vpc-interface-endpoints-privatelink/README.md) | `aws_vpc_endpoint` ×N (interface, one per service per AZ ENI), optionally `aws_vpc_endpoint_service` | standard+ | `interface_endpoint_ids`, `endpoint_service_id` |
| [`transit-gateway`](modules/transit-gateway/README.md) | `aws_ec2_transit_gateway`, `aws_ec2_transit_gateway_vpc_attachment` ×N, `aws_ec2_transit_gateway_route_table`, `aws_ec2_transit_gateway_route`, optionally `aws_ram_resource_share` | standard+ | `transit_gateway_id`, `transit_gateway_arn`, `vpc_attachment_ids` |
| [`site-to-site-vpn`](modules/site-to-site-vpn/README.md) | `aws_vpn_connection` (2 tunnels), `aws_vpn_connection_route` ×N, `aws_cloudwatch_log_group` ×2 | standard+ | `vpn_connection_id`, `tunnel1_address`, `tunnel2_address` |
| [`vpc-peering`](modules/vpc-peering/README.md) | `aws_vpc_peering_connection`, `aws_vpc_peering_connection_accepter`, `aws_route` ×N (both sides) | standard+ | `peering_connection_id`, `peering_status` |
| [`route53`](modules/route53/README.md) | `aws_route53_zone` (private, optionally public), `aws_route53_zone_association` ×N, `aws_route53_record` ×N, `aws_route53_health_check`, optionally DNSSEC + query logging | standard+ | `private_zone_id`, `public_zone_id`, `name_servers` |
| [`vpc-network-performance`](modules/vpc-network-performance/README.md) | `aws_placement_group` ×3 (cluster/spread/partition), optionally `aws_instance` (ENA) | standard+ | `placement_group_ids` |
| [`vpc-traffic-mirroring`](modules/vpc-traffic-mirroring/README.md) | `aws_ec2_traffic_mirror_target`, `aws_ec2_traffic_mirror_filter`, `aws_ec2_traffic_mirror_filter_rule` ×N, `aws_ec2_traffic_mirror_session` ×N | not auto-deployed (see Section 14) | `mirror_target_id`, `mirror_filter_id`, `mirror_session_ids` |
| [`gateway-load-balancer`](modules/gateway-load-balancer/README.md) | `aws_lb` (GWLB type), `aws_lb_target_group`, `aws_vpc_endpoint_service`, `aws_vpc_endpoint` (GWLBe in consumer VPC) | full | `gwlb_arn`, `gwlb_endpoint_service_id`, `gwlbe_id` |
| [`client-vpn`](modules/client-vpn/README.md) | `aws_ec2_client_vpn_endpoint`, `aws_ec2_client_vpn_network_association` ×N, `aws_ec2_client_vpn_authorization_rule` ×N, `aws_ec2_client_vpn_route` ×N | full (+ cert ARNs required) | `client_vpn_endpoint_id`, `vpn_dns_name` |
| [`eks-networking`](modules/eks-networking/README.md) | `aws_eks_cluster`, `aws_security_group` ×2, `aws_eks_addon` ×3, `aws_iam_openid_connect_provider`, `aws_eks_node_group` | full | `cluster_endpoint`, `cluster_ca_certificate`, `oidc_provider_arn` |
| [`cloudfront`](modules/cloudfront/README.md) | `aws_cloudfront_distribution`, `aws_cloudfront_origin_access_control`, optionally `aws_cloudfront_function`, `aws_cloudfront_key_group` | full | `domain_name`, `distribution_id`, `oac_id` |
| [`cloud-wan`](modules/cloud-wan/README.md) | `aws_networkmanager_global_network`, `aws_networkmanager_core_network`, optionally `aws_networkmanager_vpc_attachment` ×N, `aws_networkmanager_site_to_site_vpn_attachment` | full | `global_network_id`, `core_network_id`, `core_network_arn` |
| [`vpc-lattice`](modules/vpc-lattice/README.md) | `aws_vpclattice_service_network`, `aws_vpclattice_auth_policy`, optionally `aws_vpclattice_service` ×N, `aws_vpclattice_target_group` ×N, `aws_vpclattice_listener` ×N, `aws_vpclattice_service_network_vpc_association` ×N | full | `service_network_id`, `service_network_arn`, `service_ids` |
| [`management-governance`](modules/management-governance/README.md) | `aws_networkmanager_global_network`, `aws_networkmanager_transit_gateway_registration`, `aws_cloudtrail`, `aws_cloudwatch_log_group`, optionally `aws_config_*` | full | `global_network_id`, `cloudtrail_arn`, `flow_log_group_name` |
| [`hybrid-networks`](modules/hybrid-networks/README.md) | `aws_customer_gateway` ×N, optionally `aws_vpn_gateway`, `aws_vpn_gateway_attachment`, `aws_vpn_gateway_route_propagation`, `aws_dx_gateway`, `aws_dx_gateway_association` | full (CGWs only; VGW/DX skipped) | `customer_gateway_ids`, `vpn_gateway_id`, `dx_gateway_id` |
| [`direct-connect`](modules/direct-connect/README.md) | `aws_dx_connection`, `aws_dx_lag`, `aws_dx_gateway`, `aws_dx_private_virtual_interface`, `aws_dx_public_virtual_interface`, `aws_dx_transit_virtual_interface`, `aws_dx_gateway_association` | not auto-deployed (see Section 14) | `dx_connection_id`, `dx_gateway_id`, `private_vif_id` |

---

## 7. Tier-by-Tier Resource Inventory

### Minimal tier

| Resource name pattern | Type | Est. monthly cost |
|-----------------------|------|-------------------|
| `anslab-lab-primary` VPC | `aws_vpc` | $0 |
| Primary IGW | `aws_internet_gateway` | $0 |
| Primary public subnets (×2) | `aws_subnet` | $0 |
| Primary private subnets (×2) | `aws_subnet` | $0 |
| NAT Gateway EIP (×1) | `aws_eip` | ~$3.60 |
| Primary NAT Gateway (×1, single) | `aws_nat_gateway` | ~$32 + $0.045/GB |
| S3 gateway endpoint | `aws_vpc_endpoint` | $0 |
| DynamoDB gateway endpoint | `aws_vpc_endpoint` | $0 |
| ALB SG | `aws_security_group` | $0 |
| ALB (`anslab-lab-alb`) | `aws_lb` | ~$16 + LCU |
| ALB target group | `aws_lb_target_group` | $0 |
| ALB HTTP listener | `aws_lb_listener` | $0 |
| Private subnet NACL | `aws_network_acl` | $0 |
| App SG | `aws_security_group` | $0 |
| Monthly budget alarm | `aws_budgets_budget` | $0 |
| `random_id.suffix` | `random_id` | $0 |
| **Minimal total** | | **~$52–60/mo (~$1.70–2/day)** |

### Additional resources added in standard tier

| Resource name pattern | Type | Est. monthly cost |
|-----------------------|------|-------------------|
| Secondary VPC | `aws_vpc` | $0 |
| Secondary IGW | `aws_internet_gateway` | $0 |
| Secondary public/private subnets (×4) | `aws_subnet` | $0 |
| Secondary NAT GW + EIP | `aws_nat_gateway`, `aws_eip` | ~$35.60 |
| DHCP options set + association | `aws_vpc_dhcp_options` | $0 |
| R53 Resolver inbound endpoint | `aws_route53_resolver_endpoint` | ~$14.40 |
| R53 Resolver outbound endpoint | `aws_route53_resolver_endpoint` | ~$14.40 |
| Resolver SG | `aws_security_group` | $0 |
| Flow Logs CWL log group | `aws_cloudwatch_log_group` | ~$0.50 |
| Flow Logs IAM role + policy | `aws_iam_role` | $0 |
| Flow Logs to CloudWatch | `aws_flow_log` | pay-per-GB |
| Flow Logs to S3 | `aws_flow_log` | pay-per-GB |
| Flow Logs S3 bucket | `aws_s3_bucket` | ~$0.02 |
| Transit Gateway | `aws_ec2_transit_gateway` | ~$36 |
| TGW VPC attachment (primary) | `aws_ec2_transit_gateway_vpc_attachment` | ~$36 |
| TGW VPC attachment (secondary) | `aws_ec2_transit_gateway_vpc_attachment` | ~$36 |
| Cross-VPC routes (×4) | `aws_route` | $0 |
| VPC peering connection | `aws_vpc_peering_connection` | $0 (intra-AZ) |
| Peering routes (×4) | `aws_route` | $0 |
| Simulated CGW | `aws_customer_gateway` | $0 |
| S2S VPN connection | `aws_vpn_connection` | ~$36 |
| VPN static route | `aws_vpn_connection_route` | $0 |
| VPN CWL log groups (×2) | `aws_cloudwatch_log_group` | ~$0.10 |
| Route 53 private hosted zone | `aws_route53_zone` | ~$0.50 |
| R53 Zone association (secondary VPC) | `aws_route53_zone_association` | $0 |
| R53 record (ALB alias) | `aws_route53_record` | $0 |
| Interface SG | `aws_security_group` | $0 |
| Interface endpoints ×4 (SSM/SSMMsg/EC2Msg/Logs) | `aws_vpc_endpoint` | ~$28.80 (×4 × $7.20) |
| Placement groups (×3) | `aws_placement_group` | $0 |
| **Standard incremental total** | | **~$240–260/mo (~$8–9/day)** |

### Additional resources added in full tier

| Resource name pattern | Type | Est. monthly cost |
|-----------------------|------|-------------------|
| Inspection VPC + subnets + IGW | `aws_vpc` etc. | $0 |
| Inspection NAT GW + EIP | `aws_nat_gateway`, `aws_eip` | ~$35.60 |
| GWLB | `aws_lb` | ~$25 + GLCU |
| GWLB target group | `aws_lb_target_group` | $0 |
| GWLB endpoint service | `aws_vpc_endpoint_service` | $0 |
| GWLBe in primary VPC | `aws_vpc_endpoint` | ~$7.20 |
| Network Firewall | `aws_networkfirewall_firewall` | ~$130 (endpoints + data) |
| Firewall policy + rule group | `aws_networkfirewall_*` | $0 |
| WAFv2 Regional Web ACL | `aws_wafv2_web_acl` | ~$5 + $0.60/1M req |
| EKS control plane | `aws_eks_cluster` | ~$72 |
| EKS node group (1×t3.medium) | `aws_eks_node_group` | ~$30 |
| EKS addons ×3 | `aws_eks_addon` | $0 |
| EKS OIDC provider | `aws_iam_openid_connect_provider` | $0 |
| EKS SGs (×2) | `aws_security_group` | $0 |
| CloudFront distribution | `aws_cloudfront_distribution` | ~$1 + $0.0085/10k req |
| CloudFront S3 origin bucket | `aws_s3_bucket` | ~$0.02 |
| CloudFront OAC | `aws_cloudfront_origin_access_control` | $0 |
| Cloud WAN global network | `aws_networkmanager_global_network` | $0 |
| Cloud WAN core network | `aws_networkmanager_core_network` | ~$7.50/segment + edge |
| VPC Lattice service network | `aws_vpclattice_service_network` | ~$2.50 + per-req |
| VPC Lattice VPC association | `aws_vpclattice_service_network_vpc_association` | ~$7.20 |
| Network Manager global network | `aws_networkmanager_global_network` | $0 |
| TGW registration in NM | `aws_networkmanager_transit_gateway_registration` | $0 |
| CloudTrail trail | `aws_cloudtrail` | ~$2 |
| CloudTrail S3 bucket | `aws_s3_bucket` | ~$0.02 |
| CWL flow log group (mgmt) | `aws_cloudwatch_log_group` | ~$0.10 |
| Customer GWs ×2 (hybrid) | `aws_customer_gateway` | $0 |
| Client VPN endpoint (if enabled) | `aws_ec2_client_vpn_endpoint` | ~$72 |
| **Full incremental total** | | **~$400–600+/mo (~$13–20/day incremental; $50–100+/day total)** |

> All cost estimates use us-east-1 pricing as of 2024. Actual costs vary with data transfer, request volume, and regional pricing differences.

---

## 8. Verifying the Deploy

### Dump all outputs

```bash
terraform output
```

To get a specific output as a raw string (useful in scripts):

```bash
terraform output -raw alb_dns_name
terraform output -json | jq -r '.primary_vpc_id.value'
```

### VPC and subnets

```bash
# List all VPCs tagged with your project
aws ec2 describe-vpcs \
  --filters "Name=tag:Project,Values=anslab" \
  --query 'Vpcs[*].{ID:VpcId,CIDR:CidrBlock,State:State}' \
  --output table \
  --profile lab

# Subnets in the primary VPC
PRIMARY_VPC=$(terraform output -raw primary_vpc_id)
aws ec2 describe-subnets \
  --filters "Name=vpc-id,Values=$PRIMARY_VPC" \
  --query 'Subnets[*].{ID:SubnetId,CIDR:CidrBlock,AZ:AvailabilityZone,Public:MapPublicIpOnLaunch}' \
  --output table \
  --profile lab
```

### ALB

```bash
aws elbv2 describe-load-balancers \
  --query 'LoadBalancers[*].{Name:LoadBalancerName,DNS:DNSName,State:State.Code}' \
  --output table \
  --profile lab
```

Test the ALB endpoint:

```bash
ALB_DNS=$(terraform output -raw alb_dns_name)
curl -sv "http://${ALB_DNS}/"
```

This will return an HTTP 503 because no targets are registered in the target group. That is the expected behavior for this lab — the ALB is provisioned to demonstrate the resource, not to serve real traffic. The health checks will show all targets as unhealthy (empty target group), which is correct.

### Gateway endpoints

```bash
aws ec2 describe-vpc-endpoints \
  --filters "Name=vpc-id,Values=$(terraform output -raw primary_vpc_id)" \
            "Name=vpc-endpoint-type,Values=Gateway" \
  --query 'VpcEndpoints[*].{ID:VpcEndpointId,Service:ServiceName,State:State}' \
  --output table \
  --profile lab
```

### Transit Gateway (standard+)

```bash
aws ec2 describe-transit-gateways \
  --filters "Name=tag:Project,Values=anslab" \
  --query 'TransitGateways[*].{ID:TransitGatewayId,State:State,ASN:Options.AmazonSideAsn}' \
  --output table \
  --profile lab

# TGW attachments
TGW_ID=$(terraform output -raw transit_gateway_id)
aws ec2 describe-transit-gateway-attachments \
  --filters "Name=transit-gateway-id,Values=$TGW_ID" \
  --query 'TransitGatewayAttachments[*].{ID:TransitGatewayAttachmentId,Type:ResourceType,State:State}' \
  --output table \
  --profile lab
```

### S2S VPN (standard+)

```bash
aws ec2 describe-vpn-connections \
  --filters "Name=tag:Project,Values=anslab" \
  --query 'VpnConnections[*].{ID:VpnConnectionId,State:State,Tunnel1:VgwTelemetry[0].Status,Tunnel2:VgwTelemetry[1].Status}' \
  --output table \
  --profile lab
```

Both tunnels will show `DOWN`. This is expected: the CGW IP address (`203.0.113.12`) is in the IANA TEST-NET-3 reserved range and is not routable. The VPN connection exists on the AWS side for study purposes; IKE negotiation simply never completes.

### Route 53 private zone (standard+)

```bash
aws route53 list-hosted-zones \
  --query 'HostedZones[*].{ID:Id,Name:Name,Private:Config.PrivateZone}' \
  --output table \
  --profile lab
```

### Interface endpoints (standard+)

```bash
aws ec2 describe-vpc-endpoints \
  --filters "Name=vpc-id,Values=$(terraform output -raw primary_vpc_id)" \
            "Name=vpc-endpoint-type,Values=Interface" \
  --query 'VpcEndpoints[*].{ID:VpcEndpointId,Service:ServiceName,State:State}' \
  --output table \
  --profile lab
```

### EKS cluster (full)

```bash
aws eks describe-cluster \
  --name anslab-lab-eks \
  --query 'cluster.{Name:name,Status:status,Endpoint:endpoint,Version:version}' \
  --output table \
  --profile lab

# Node group
aws eks describe-nodegroup \
  --cluster-name anslab-lab-eks \
  --nodegroup-name default \
  --query 'nodegroup.{Name:nodegroupName,Status:status,DesiredSize:scalingConfig.desiredSize,InstanceType:instanceTypes[0]}' \
  --output table \
  --profile lab
```

### CloudFront (full)

```bash
aws cloudfront list-distributions \
  --query 'DistributionList.Items[*].{ID:Id,Domain:DomainName,Status:Status,Enabled:Enabled}' \
  --output table \
  --profile lab
```

Note: CloudFront distributions take 10–15 minutes to reach `Deployed` status after `terraform apply` completes. The Terraform resource is created (you have an ID) but edge propagation is still in progress.

### Cloud WAN (full)

```bash
aws networkmanager list-global-networks \
  --query 'GlobalNetworks[*].{ID:GlobalNetworkId,State:State,Description:Description}' \
  --output table \
  --profile lab
```

---

## 9. Customizing — Adding Your Own Resources

### Adding a new module call

Open `deploy/05-advanced.tf` (or a new file in `deploy/`) and add a module block. Example — enabling Traffic Mirroring once you have a source ENI:

```hcl
# deploy/99-custom.tf
module "traffic_mirroring" {
  count  = local.enable_standard ? 1 : 0
  source = "modules/vpc-traffic-mirroring"

  name              = "${local.name_prefix}-mirror"
  mirror_target_eni = "REDACTED_AWS_RESOURCE_ID"   # your source ENI

  filters = {
    all-traffic = {
      description = "Mirror all traffic"
      ingress_rules = [
        { rule_number = 100, protocol = -1, source_cidr_block = "0.0.0.0/0", destination_cidr_block = "0.0.0.0/0" }
      ]
      egress_rules = [
        { rule_number = 100, protocol = -1, source_cidr_block = "0.0.0.0/0", destination_cidr_block = "0.0.0.0/0" }
      ]
    }
  }

  sessions = {
    session1 = {
      source_eni_id   = "REDACTED_AWS_RESOURCE_ID"
      session_number  = 1
      filter_key      = "all-traffic"
    }
  }

  tags = local.common_tags
}
```

Any `.tf` file placed inside `deploy/` is automatically included in the root configuration. You do not need to register it anywhere.

### Provider alias usage for cross-region resources

`deploy/providers.tf` defines three provider configurations:

```hcl
provider "aws" { region = var.aws_region; profile = var.aws_profile }              # default
provider "aws" { alias = "secondary"; region = var.aws_secondary_region; ... }     # us-west-2 by default
provider "aws" { alias = "us_east_1"; region = "us-east-1"; ... }                  # CloudFront WAFv2
```

To use a non-default provider alias in a module call:

```hcl
module "cross_region_resource" {
  source    = "modules/vpc-fundamentals"
  providers = {
    aws = aws.secondary
  }
  # ...
}
```

The `us_east_1` alias exists specifically because WAFv2 Web ACLs for CloudFront must be created in `us-east-1` regardless of the deployment region. The `cloudfront` module receives this alias implicitly via the `aws.us_east_1` provider.

### Switching to S3 remote state

Local state is used by default and is appropriate for a single-engineer lab. To migrate to S3 + DynamoDB (necessary if you want concurrent applies or state sharing):

**Step 1:** Bootstrap the backend infrastructure once (in a separate Terraform workspace or manually):

```bash
# Create the state bucket and lock table manually or via a minimal Terraform config
aws s3api create-bucket \
  --bucket anslab-tfstate-$(aws sts get-caller-identity --query Account --output text --profile lab) \
  --region us-east-1 \
  --profile lab

aws s3api put-bucket-versioning \
  --bucket anslab-tfstate-<account-id> \
  --versioning-configuration Status=Enabled \
  --profile lab

aws dynamodb create-table \
  --table-name anslab-tfstate-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region us-east-1 \
  --profile lab
```

**Step 2:** Uncomment the backend block in `deploy/versions.tf`:

```hcl
backend "s3" {
  bucket         = "anslab-tfstate-<account-id>"
  key            = "aws-networking-lab/terraform.tfstate"
  region         = "us-east-1"
  dynamodb_table = "anslab-tfstate-lock"
  encrypt        = true
}
```

**Step 3:** Migrate existing local state:

```bash
terraform init -migrate-state
```

Terraform will prompt to copy the local state to S3. After migration, the `.terraform/` directory is updated and local `terraform.tfstate` is no longer authoritative.

---

## 10. Troubleshooting

### "failed to get shared config profile"

```
Error: failed to get shared config profile, <profile-name>
```

The AWS CLI profile named in `aws_profile` does not exist in `~/.aws/config`. Either the profile was never created or the name in `terraform.tfvars` does not match. Verify with:

```bash
aws configure list-profiles
cat ~/.aws/config | grep '\[profile'
```

Fix: run `aws configure sso` again (see Section 3) and ensure the profile name matches `aws_profile` in `terraform.tfvars`.

### "ExpiredTokenException"

```
ExpiredTokenException: The security token included in the request is expired
```

The SSO session token has expired (8–12h validity). Re-authenticate:

```bash
aws sso login --profile lab
```

`apply.sh` checks for this automatically and triggers `aws sso login` if `aws sts get-caller-identity` fails, but you may encounter this when running Terraform commands directly.

### Insufficient EIP capacity / EIP limit exceeded

```
Error: Error creating EIP: AddressLimitExceeded: The maximum number of addresses has been reached.
```

The default EIP quota in us-east-1 is 5 per region. A `full` tier deploy with multiple NAT GWs across two VPCs can hit this limit. Options:

1. Set `single_nat_gateway = true` (already the default) to minimize EIP usage.
2. Request a quota increase: `aws service-quotas request-service-quota-increase --service-code ec2 --quota-code L-0263D0A3 --desired-value 20 --region us-east-1 --profile lab`

### "ResourceLimitExceeded" on TGW or NAT GW

```
ResourceLimitExceeded: You have reached the maximum number of transit gateways allowed.
```

The default TGW quota is 5 per region. Check current usage and open a quota request via the Service Quotas console or:

```bash
aws service-quotas list-service-quotas \
  --service-code ec2 \
  --query 'Quotas[?contains(QuotaName, `Transit Gateway`) == `true`].{Name:QuotaName,Value:Value}' \
  --output table \
  --profile lab
```

### Terraform state lock errors (local backend)

```
Error acquiring the state lock: [...] lock file already exists
```

Local state uses a `.terraform.tfstate.lock.info` file. This occurs if a previous apply was interrupted without releasing the lock. If you are certain no other apply is running:

```bash
terraform force-unlock <LOCK_ID>
```

The lock ID is printed in the error message. With local state, only one `terraform apply` can run at a time per working directory.

### EKS node group stuck in CREATE_FAILED

Common cause: the VPC CNI (vpc-cni addon) cannot reach the EC2 and EKS API endpoints to initialize. The managed node group instances require outbound internet access (via NAT GW) or interface endpoints for `ec2messages` and `ssm` to pull add-on metadata.

Checks:
1. Verify the private subnet route tables have a `0.0.0.0/0 → nat-gateway-id` route: `aws ec2 describe-route-tables --filters "Name=vpc-id,Values=<vpc-id>" --query 'RouteTables[*].Routes[*].{Dest:DestinationCidrBlock,Target:NatGatewayId}' --profile lab`
2. Verify the NAT GW is in `available` state: `aws ec2 describe-nat-gateways --filter Name=state,Values=available --profile lab`
3. Check the node group failure reason: `aws eks describe-nodegroup --cluster-name anslab-lab-eks --nodegroup-name default --query 'nodegroup.health' --profile lab`

### CloudFront deployment timing

CloudFront distributions take 10–15 minutes to reach `Deployed` status because edge propagation spans ~450 PoPs globally. Terraform marks the resource created once the AWS API accepts the create request, not when propagation completes. Monitor with:

```bash
watch -n 30 'aws cloudfront list-distributions \
  --query "DistributionList.Items[*].{ID:Id,Status:Status}" \
  --output table --profile lab'
```

### "An argument named X is not expected here" after `terraform init -upgrade`

A provider minor version bump can add new required arguments or rename deprecated ones. Pin the provider to the tested version by setting `version = "= 5.70.0"` in `versions.tf` until you are ready to review the changelog.

---

## 11. Costs and Guardrails

### AWS Budgets alarm

The resource `aws_budgets_budget.monthly` (in `deploy/06-cost-controls.tf`) creates a monthly cost budget named `anslab-lab-monthly-cap`. Two SNS-backed email notifications are configured:

| Notification | Threshold | Type | Trigger |
|--------------|-----------|------|---------|
| Alert 1 | 80% of $20 = $16 | Forecasted | AWS forecasts you will exceed $16 this month |
| Alert 2 | 100% of $20 = $20 | Actual | Actual spend crosses $20 |

Both send to `budget_alarm_email` (default `ideawaves@gmail.com`). Modify `monthly_budget_usd` and `budget_alarm_email` in `terraform.tfvars` before the first apply to adjust thresholds.

Note: Budgets is evaluated once or twice per day, not in real time. A spike in spending may not trigger an alert for several hours.

### Check current spend

```bash
aws ce get-cost-and-usage \
  --time-period "Start=$(date -u -d '7 days ago' +%F),End=$(date -u +%F)" \
  --granularity DAILY \
  --metrics UnblendedCost \
  --profile lab \
  | jq -r '.ResultsByTime[] | "\(.TimePeriod.Start)  $\(.Total.UnblendedCost.Amount)"'
```

On macOS, use `date -v-7d +%F` instead of `date -u -d '7 days ago' +%F`.

### Top 5 cost levers (and how to reduce each)

| Service | Approximate driver | Mitigation |
|---------|-------------------|------------|
| **NAT Gateway** | $0.045/hr per GW + $0.045/GB processed | Set `single_nat_gateway = true` (default); use gateway endpoints for S3/DDB to avoid NAT data charges |
| **Transit Gateway** | $0.05/hr per attachment | Detach or delete attachments when not in use; stay in `minimal` tier when not studying TGW |
| **EKS** | $0.10/hr control plane + t3.medium ~$0.0416/hr node | Only deploy `full` tier during active study; minimum node count is 1 (already set) |
| **CloudFront** | $0.0085/10k HTTPS requests + data transfer | Usage-based; minimal at lab traffic levels — primary cost is if you accidentally serve large objects |
| **GWLB** | $0.008/hr + $0.004/GLCU | Full tier only; destroy promptly after studying the inspection architecture |

---

## 12. Tearing It Down

### `./destroy.sh`

```bash
export AWS_PROFILE=lab
./destroy.sh
```

What the script does:

1. Checks SSO session validity; re-authenticates if expired.
2. Iterates `terraform state list` to find all `aws_s3_bucket.*` resources in state.
3. For each bucket, runs `aws s3 rm s3://<name> --recursive` to delete all objects, then `aws s3api delete-objects` with a `list-object-versions` query to purge any versioned objects and delete markers. This is necessary because Terraform's `force_destroy = true` only handles object versions it tracks; objects created outside of Terraform (manual uploads, flow log delivery, CloudTrail records written after apply) would otherwise block bucket deletion.
4. Runs `terraform destroy -var "aws_profile=$PROFILE"` — interactive confirmation required.
5. Runs a post-destroy verification pass: checks for remaining NAT GWs, TGWs, load balancers, EKS clusters, and CloudFront distributions.

### Manual cleanup checklist

Terraform `destroy` handles all resources in state, but the following categories are commonly left behind:

| Resource | Why Terraform misses it | How to clean up |
|----------|-------------------------|-----------------|
| **Orphaned EIPs** | EIPs disassociated but not released (e.g., if a NAT GW delete fails mid-run) | `aws ec2 describe-addresses --query 'Addresses[?AssociationId==null].AllocationId' --profile lab` then `aws ec2 release-address --allocation-id <id> --profile lab` |
| **S3 buckets with new objects** | Objects created after `terraform apply` by CloudTrail, flow logs, or manual uploads | `aws s3 ls --profile lab \| grep anslab` then manually delete with `aws s3 rb s3://<name> --force --profile lab` |
| **CloudWatch Log Groups** | Log groups with `retention_days = 0` (never expire) that received data after apply | `aws logs describe-log-groups --log-group-name-prefix /aws/anslab --query 'logGroups[*].logGroupName' --output text --profile lab` then delete each |
| **Route 53 zones with manual records** | If you added records outside Terraform, the zone deletion will fail with `HostedZoneNotEmpty` | List and delete manual records before destroy, or use `aws route53 list-resource-record-sets --hosted-zone-id <id>` and delete non-NS/SOA records |
| **CloudFront key pairs / OAC** | Occasionally not cleaned up if the distribution fails to disable first | Verify via `aws cloudfront list-origin-access-controls --profile lab` |

### Post-destroy verification

```bash
# Nothing expensive should remain
echo "=== NAT Gateways ==="
aws ec2 describe-nat-gateways \
  --filter Name=state,Values=available \
  --query 'NatGateways[*].{ID:NatGatewayId,VPC:VpcId}' \
  --output table --profile lab

echo "=== Transit Gateways ==="
aws ec2 describe-transit-gateways \
  --filters "Name=tag:Project,Values=anslab" \
  --query 'TransitGateways[*].{ID:TransitGatewayId,State:State}' \
  --output table --profile lab

echo "=== Load Balancers ==="
aws elbv2 describe-load-balancers \
  --query 'LoadBalancers[*].{Name:LoadBalancerName,State:State.Code}' \
  --output table --profile lab

echo "=== EKS Clusters ==="
aws eks list-clusters --output table --profile lab

echo "=== CloudFront Distributions ==="
aws cloudfront list-distributions \
  --query 'DistributionList.Items[*].{ID:Id,Status:Status}' \
  --output table --profile lab

echo "=== Unallocated EIPs ==="
aws ec2 describe-addresses \
  --query 'Addresses[*].{AllocationId:AllocationId,AssocID:AssociationId,PublicIP:PublicIp}' \
  --output table --profile lab
```

---

## 13. Mapping Deploy Modules → Exam Topics

ANS-C01 domain weights: Network Design (30%), Network Implementation (26%), Network Management and Operations (20%), Network Security, Compliance, and Governance (24%).

| Module | Design | Implementation | Mgmt & Ops | Security |
|--------|--------|----------------|------------|----------|
| `vpc-fundamentals` | Subnetting, CIDR, AZ design, IPv6 dual-stack | VPC create, IGW, NAT GW, route tables | Flow log interpretation | Default SG lockdown, default NACL |
| `vpc-gateway-endpoints` | Routing without NAT for S3/DDB | Gateway endpoint routing, prefix list managed routes | Endpoint policy enforcement | IAM endpoint policies, no-internet S3 access |
| `elastic-load-balancing` | ALB vs NLB vs CLB selection, cross-zone | Listener rules, target groups, health checks | Access log analysis, metrics | SG on ALB, WAF integration |
| `network-security` | Defense-in-depth layering | NACL rule ordering, SG stateful vs NACL stateless | Firewall alert log analysis | Network Firewall policy, WAFv2 managed rules, Shield |
| `vpc-dns-dhcp` | Hybrid DNS split-horizon design | DHCP options, Resolver endpoint placement | Resolver query logging | Private DNS, Resolver rule isolation |
| `vpc-additional-features` | Reachability Analyzer topology | Flow log format, secondary CIDRs | Traffic analysis, Network Access Analyzer | Flow log field selection |
| `vpc-interface-endpoints` | PrivateLink vs gateway endpoint | Interface endpoint ENI, private DNS override | Endpoint health | SG on endpoint ENI, IAM endpoint policy |
| `transit-gateway` | Hub-and-spoke vs mesh, TGW route table segmentation | VPC attachment, route table association/propagation, RAM sharing | TGW flow logs, metrics | Routing isolation via separate route tables |
| `site-to-site-vpn` | BGP vs static, ECMP, redundancy | CGW config, VGW vs TGW attachment, tunnel options | Tunnel monitoring (CloudWatch), IKE logs | IKEv2 cipher suite selection, PSK management |
| `vpc-peering` | Non-transitive peering topology, CIDR overlap | Peering requester/accepter, cross-account, cross-region | Reachability debugging | Peering DNS resolution options |
| `route53` | Routing policies (latency, weighted, geolocation, failover), private zone design | Record types, alias records, health checks, DNSSEC | Query logging, resolver rule propagation | DNSSEC, private zone access control |
| `vpc-network-performance` | Placement group strategies for HPC/low-latency | Cluster/spread/partition group selection, ENA, jumbo frames | Monitoring network throughput | ENA security considerations |
| `gateway-load-balancer` | GWLB bump-in-the-wire inspection architecture | Inspection VPC design, GWLBe routing, endpoint service | Appliance health check configuration | Inline inspection, transparent firewall pattern |
| `client-vpn` | Client access design, split tunnel vs full tunnel | Endpoint subnet association, auth options, authorization rules | Connection logging, quota management | Certificate-based mutual auth, SG on endpoint |
| `eks-networking` | VPC CNI IP addressing, pod networking, secondary ENI | Node group subnet placement, IRSA, add-on lifecycle | Cluster logging (API/audit), node draining | Pod security groups, IRSA least-privilege |
| `cloudfront` | CDN origin selection, cache behavior design, OAC | Distribution config, OAC SigV4, TLS policy | Cache invalidation, real-time logs | WAFv2 CLOUDFRONT scope, geo restriction, signed URLs |
| `cloud-wan` | Global network segment design, edge location selection | Core network policy document, VPC/VPN attachment | Network Manager topology view | Segment isolation, attachment policies |
| `vpc-lattice` | Service mesh without TGW/peering, IAM auth model | Service network, VPC association, target group types | Access log subscriptions | IAM-based access policies, zero-trust service comms |
| `management-governance` | Governance at scale with Config and CloudTrail | Network Manager device/site registration, CloudTrail configuration | Config rule compliance dashboards | CloudTrail integrity validation, SCP design |
| `hybrid-networks` | VGW vs TGW vs DX GW for hybrid design | CGW parameters, route propagation, DX GW associations | VPN tunnel metric baselines | BGP route filtering, AS-PATH manipulation |
| `direct-connect` | Dedicated vs hosted, private/public/transit VIF design | DX connection ordering, LAG, BGP timers | BGP session monitoring, BFD | MACsec on dedicated connections, VIF auth key |
| `vpc-traffic-mirroring` | Out-of-band inspection, traffic copy architecture | Mirror filter/session/target placement | Mirror session scaling limits | Passive inspection use cases |

---

## 14. What Is Not Auto-Deployed and Why

### Direct Connect

**Why not auto-deployed:** A real AWS Direct Connect connection requires a physical cross-connect at a colocation facility (e.g., Equinix, Cologix) ordered through an AWS Direct Connect partner. There is no API call that provisions the physical fiber; you receive a Letter of Authorization (LOA-CFA) and then coordinate with the colo to establish the physical connection. This can take days to weeks and costs a committed port fee.

**The module exists.** To study the Terraform resource definitions without a real connection:

```hcl
# In deploy/99-dx-study.tf — creates the logical resources only
module "direct_connect" {
  source = "modules/direct-connect"

  name           = "${local.name_prefix}-dx"
  create_dx_gateway = true
  dx_gateway_asn    = 64513

  # Leave connection_id null — no physical connection
  connection_id  = null
  create_lag     = false
  create_private_vif = false
  create_transit_vif = false

  tags = local.common_tags
}
```

The `aws_dx_gateway` resource creates a logical DX Gateway at no cost. Private/transit VIF creation requires an active `aws_dx_connection` ID.

Architecture diagram: [`diagrams/13-direct-connect.drawio`](diagrams/13-direct-connect.drawio)

### Cloud WAN VPC/VPN attachments to real on-prem sites

**Why not auto-deployed:** Cloud WAN attachments (`aws_networkmanager_vpc_attachment`) that point to real on-premises sites require a functioning BGP peer at the remote end. The lab creates the Cloud WAN core network and global network but leaves `vpc_attachments = {}` and `vpn_attachments = {}` empty. Adding attachments without a real peer would result in `PENDING` attachment state indefinitely, which does not harm anything but adds attachment-hour costs (~$0.05/hr per attachment).

**To add a VPC attachment manually:**

```hcl
module "cloud_wan" {
  # ... existing config ...
  vpc_attachments = {
    primary = {
      vpc_id         = module.primary_vpc.vpc_id
      subnet_arns    = [for s in module.primary_vpc.private_subnet_ids : "REDACTED_AWS_ARN<account>:subnet/${s}"]
      segment        = "production"
    }
  }
}
```

Architecture diagram: [`diagrams/21-cloud-wan.drawio`](diagrams/21-cloud-wan.drawio)

### VPC Traffic Mirroring

**Why not auto-deployed:** Traffic Mirroring requires a known source ENI ID at `terraform apply` time. The lab does not deploy any EC2 instances (by design — instances are not required to study the control plane). Without a live source ENI, a mirror session cannot be created. The `vpc-traffic-mirroring` module is present and fully functional.

**To enable manually once you have a source ENI:**

```hcl
# deploy/99-mirroring.tf
module "traffic_mirroring" {
  count  = local.enable_standard ? 1 : 0
  source = "modules/vpc-traffic-mirroring"

  name              = "${local.name_prefix}-mirror"
  mirror_target_eni = "REDACTED_AWS_RESOURCE_ID"   # your actual source ENI
  # ... filters and sessions ...
  tags = local.common_tags
}
```

Architecture diagram: [`diagrams/05-vpc-traffic-mirroring.drawio`](diagrams/05-vpc-traffic-mirroring.drawio)

### Hybrid Networks — full DX Gateway + VGW association

**Why not auto-deployed:** The `hybrid-networks` module is instantiated in the `full` tier but with `create_vpn_gateway = false` and `create_dx_gateway = false`. Creating a VGW requires no real-world dependency, but associating it with a DX Gateway (`aws_dx_gateway_association`) requires an active DX connection ID. To avoid creating dangling association state, VGW and DX GW creation are disabled by default.

**To enable VGW-only (no DX required):**

```hcl
module "hybrid_networks" {
  # ... existing config ...
  create_vpn_gateway                    = true
  vpn_gateway_asn                       = 64512
  vgw_route_propagation_route_table_ids = module.primary_vpc.private_route_table_ids
}
```

Architecture diagram: [`diagrams/10-hybrid-networks.drawio`](diagrams/10-hybrid-networks.drawio)

---

## 15. Source and Further Reading

### Module READMEs

Each module has a full README covering all inputs, outputs, and example usage:

| Module | README |
|--------|--------|
| vpc-fundamentals | [`modules/vpc-fundamentals/README.md`](modules/vpc-fundamentals/README.md) |
| vpc-gateway-endpoints | [`modules/vpc-gateway-endpoints/README.md`](modules/vpc-gateway-endpoints/README.md) |
| vpc-dns-dhcp | [`modules/vpc-dns-dhcp/README.md`](modules/vpc-dns-dhcp/README.md) |
| vpc-additional-features | [`modules/vpc-additional-features/README.md`](modules/vpc-additional-features/README.md) |
| vpc-interface-endpoints-privatelink | [`modules/vpc-interface-endpoints-privatelink/README.md`](modules/vpc-interface-endpoints-privatelink/README.md) |
| vpc-peering | [`modules/vpc-peering/README.md`](modules/vpc-peering/README.md) |
| vpc-network-performance | [`modules/vpc-network-performance/README.md`](modules/vpc-network-performance/README.md) |
| vpc-traffic-mirroring | [`modules/vpc-traffic-mirroring/README.md`](modules/vpc-traffic-mirroring/README.md) |
| transit-gateway | [`modules/transit-gateway/README.md`](modules/transit-gateway/README.md) |
| site-to-site-vpn | [`modules/site-to-site-vpn/README.md`](modules/site-to-site-vpn/README.md) |
| hybrid-networks | [`modules/hybrid-networks/README.md`](modules/hybrid-networks/README.md) |
| direct-connect | [`modules/direct-connect/README.md`](modules/direct-connect/README.md) |
| client-vpn | [`modules/client-vpn/README.md`](modules/client-vpn/README.md) |
| elastic-load-balancing | [`modules/elastic-load-balancing/README.md`](modules/elastic-load-balancing/README.md) |
| route53 | [`modules/route53/README.md`](modules/route53/README.md) |
| network-security | [`modules/network-security/README.md`](modules/network-security/README.md) |
| gateway-load-balancer | [`modules/gateway-load-balancer/README.md`](modules/gateway-load-balancer/README.md) |
| eks-networking | [`modules/eks-networking/README.md`](modules/eks-networking/README.md) |
| cloudfront | [`modules/cloudfront/README.md`](modules/cloudfront/README.md) |
| cloud-wan | [`modules/cloud-wan/README.md`](modules/cloud-wan/README.md) |
| vpc-lattice | [`modules/vpc-lattice/README.md`](modules/vpc-lattice/README.md) |
| management-governance | [`modules/management-governance/README.md`](modules/management-governance/README.md) |

### Architecture diagrams

All 22 `.drawio` files are in [`diagrams/`](diagrams/). They can be opened in [draw.io (desktop or web)](https://app.diagrams.net/) or in the VS Code draw.io extension. Each diagram maps to one exam topic area and one Terraform module.

| Diagram file | Topic |
|--------------|-------|
| `01-vpc-fundamentals.drawio` | VPC core components |
| `02-vpc-additional-features.drawio` | Flow logs, Reachability Analyzer |
| `03-vpc-dns-dhcp.drawio` | Route 53 Resolver, DHCP options |
| `04-vpc-network-performance.drawio` | Placement groups, ENA, jumbo frames |
| `05-vpc-traffic-mirroring.drawio` | Traffic Mirroring architecture |
| `06-vpc-peering.drawio` | VPC peering non-transitive topology |
| `07-vpc-gateway-endpoints.drawio` | Gateway endpoints + prefix lists |
| `08-vpc-interface-endpoints-privatelink.drawio` | PrivateLink, Interface endpoints |
| `09-transit-gateway.drawio` | TGW hub-and-spoke, route table segmentation |
| `10-hybrid-networks.drawio` | VGW, DX GW, CGW relationships |
| `11-site-to-site-vpn.drawio` | S2S VPN tunnel architecture |
| `12-client-vpn.drawio` | Client VPN split-tunnel flow |
| `13-direct-connect.drawio` | DX connection types, VIF types |
| `14-cloudfront.drawio` | CloudFront origin + behavior routing |
| `15-elastic-load-balancing.drawio` | ALB, NLB, GWLB comparison |
| `16-route53.drawio` | Routing policies, health checks, DNSSEC |
| `17-network-security.drawio` | NACL, SG, Network Firewall, WAFv2 layering |
| `18-gateway-load-balancer.drawio` | GWLB inspection VPC bump-in-the-wire |
| `19-eks-networking.drawio` | VPC CNI, pod networking, IRSA |
| `20-management-governance.drawio` | Network Manager, Config, CloudTrail |
| `21-cloud-wan.drawio` | Cloud WAN segments and edge locations |
| `22-vpc-lattice.drawio` | VPC Lattice service network mesh |

The `diagrams/_build_diagrams.py` script can batch-export all `.drawio` files to PNG or SVG if you have the draw.io CLI installed (`drawio` package or `drawio.com` desktop app with CLI support).
