https://mfsg.awsapps.com/start/#/?tab=accounts
AWS access portal
jLrO!aANdPv

https://mfsgteam.atlassian.net/
https://mfsgteam.atlassian.net/wiki/spaces/AM/overview


```terraform
monitor dev:
$env:AWS_ACCESS_KEY_ID = "REDACTED_SECRET"
$env:AWS_SECRET_ACCESS_KEY = "REDACTED_SECRET"
```

### GitHub
[mfsg-org/monitor-terraform](https://github.com/enterprises/momentum-financial-services-group/organizations)
[momentum-financial-services-group](https://github.com/enterprises/momentum-financial-services-group)

 
core_ec2_ssrs_can_142.tf

#
 
Morning, if you get a chance:
dev and prod giving failed to retrieve alarms.

![alt text](aws-portal-mfsg.png)