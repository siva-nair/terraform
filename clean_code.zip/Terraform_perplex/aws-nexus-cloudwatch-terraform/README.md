# Cisco Nexus N9K syslog to AWS CloudWatch Logs

This Terraform deploys an EC2-based syslog collector that receives Cisco Nexus syslog on UDP/TCP 514, writes device-specific log files under `/var/log/cisco-nexus`, and ships those files into CloudWatch Logs using the Amazon CloudWatch Agent.

## Architecture

Cisco Nexus N9K in colo -> VPN/Direct Connect or restricted public path -> EC2 syslog collector -> CloudWatch Logs log group.

## Prerequisites

- Existing AWS VPC and subnet.
- Network reachability from the Cisco Nexus management VRF to the EC2 private IP, preferably through VPN or Direct Connect.
- Terraform >= 1.5.
- AWS credentials with permissions to create EC2, IAM, security group, and CloudWatch Logs resources.

## Deploy

```bash
cp terraform.tfvars.example terraform.tfvars
vi terraform.tfvars
terraform init
terraform plan
terraform apply
```

After apply, note the `collector_private_ip` output.

## Cisco Nexus NX-OS example

```bash
conf t
  logging server <collector_private_ip> 6 use-vrf management
  logging source-interface mgmt0
  logging timestamp milliseconds
  logging level local7 6
end
copy running-config startup-config
```

Verify from Nexus:

```bash
show logging server
show logging last 50
ping <collector_private_ip> vrf management
```

## AWS validation

On the collector:

```bash
sudo tail -f /var/log/cisco-nexus/*.log
sudo systemctl status rsyslog amazon-cloudwatch-agent
```

In AWS Console:

CloudWatch -> Logs -> Log groups -> `/network/cisco/nexus`

## Security notes

- Prefer private routing through VPN or Direct Connect.
- Avoid exposing UDP/514 to the internet.
- Restrict `colo_syslog_cidrs` to the smallest possible CIDR, ideally a single NAT IP `/32` or a private colo management subnet.
- For stronger transport security, use a local colo collector and forward to AWS over TLS/HTTPS, or use a private network path.
