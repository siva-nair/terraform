data "aws_caller_identity" "current" {}

output "account_id" {
  value = data.aws_caller_identity.current.account_id
}

data "aws_region" "current" {}

data "aws_kms_key" "kms_key" {
  key_id = var.key_name
}