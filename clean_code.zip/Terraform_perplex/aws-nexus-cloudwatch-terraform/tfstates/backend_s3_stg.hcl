bucket     = "monitor-stage-terraform-20260327160431482100000003"
key        = "terraformstate/stg/monitor/statefile"
region     = "us-east-1"
encrypt    = true
kms_key_id = "55520932-93a8-4735-b1bf-53bc674283fd"
