bucket     = "monitor-prod-terraform-20260327174806688600000003"
key        = "terraformstate/prd/monitor/statefile"
region     = "us-east-1"
encrypt    = true
kms_key_id = "798be0c1-3d90-4809-a955-02830e634c9b"
