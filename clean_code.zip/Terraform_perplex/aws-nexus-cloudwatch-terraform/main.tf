provider "aws" {
  region = var.aws_region
}

data "aws_ami" "amazon_linux_2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

locals {
  common_tags = merge(
    {
      Project     = var.name_prefix
      ManagedBy   = "terraform"
      Purpose     = "cisco-nexus-syslog-to-cloudwatch"
    },
    var.extra_tags
  )
}

resource "aws_cloudwatch_log_group" "nexus" {
  name              = var.log_group_name
  retention_in_days = var.log_retention_days
  tags              = local.common_tags
}

resource "aws_iam_role" "collector" {
  name = "${var.name_prefix}-collector-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "cloudwatch_logs" {
  name = "${var.name_prefix}-cloudwatch-logs-policy"
  role = aws_iam_role.collector.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogStream",
          "logs:DescribeLogStreams",
          "logs:PutLogEvents"
        ]
        Resource = "${aws_cloudwatch_log_group.nexus.arn}:*"
      },
      {
        Effect = "Allow"
        Action = [
          "logs:DescribeLogGroups"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_instance_profile" "collector" {
  name = "${var.name_prefix}-collector-profile"
  role = aws_iam_role.collector.name
}

resource "aws_security_group" "collector" {
  name        = "${var.name_prefix}-collector-sg"
  description = "Cisco Nexus syslog collector security group"
  vpc_id      = var.vpc_id

  dynamic "ingress" {
    for_each = var.syslog_udp_enabled ? [1] : []
    content {
      description = "Syslog UDP from colo"
      from_port   = 514
      to_port     = 514
      protocol    = "udp"
      cidr_blocks = var.colo_syslog_cidrs
    }
  }

  dynamic "ingress" {
    for_each = var.syslog_tcp_enabled ? [1] : []
    content {
      description = "Syslog TCP from colo"
      from_port   = 514
      to_port     = 514
      protocol    = "tcp"
      cidr_blocks = var.colo_syslog_cidrs
    }
  }

  dynamic "ingress" {
    for_each = length(var.ssh_admin_cidrs) > 0 ? [1] : []
    content {
      description = "SSH admin access"
      from_port   = 22
      to_port     = 22
      protocol    = "tcp"
      cidr_blocks = var.ssh_admin_cidrs
    }
  }

  egress {
    description = "Outbound HTTPS to AWS APIs and package repos"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "Outbound DNS UDP"
    from_port   = 53
    to_port     = 53
    protocol    = "udp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "Outbound DNS TCP"
    from_port   = 53
    to_port     = 53
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = local.common_tags
}

resource "aws_instance" "collector" {
  ami                         = data.aws_ami.amazon_linux_2023.id
  instance_type               = var.instance_type
  subnet_id                   = var.subnet_id
  associate_public_ip_address = var.assign_public_ip
  vpc_security_group_ids      = [aws_security_group.collector.id]
  iam_instance_profile        = aws_iam_instance_profile.collector.name
  key_name                    = var.key_name

  user_data_replace_on_change = true
  user_data = templatefile("${path.module}/user_data.sh.tftpl", {
    log_group_name = aws_cloudwatch_log_group.nexus.name
    aws_region     = var.aws_region
  })

  root_block_device {
    volume_size = var.root_volume_size_gb
    volume_type = "gp3"
    encrypted   = true
  }

  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "required"
  }

  tags = merge(local.common_tags, {
    Name = "${var.name_prefix}-collector"
  })
}
