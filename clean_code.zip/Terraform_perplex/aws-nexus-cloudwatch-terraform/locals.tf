locals {
  is_create_singleton = var.env == "dev" || var.env == "stg" || var.env == "prd"

  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.name

  is_non_prod_resource = var.env == "dev"

  tags = {
    Owner        = "monitor"
    Managed_By   = "Terraform"
    map-migrated = "mig9XKYW2OGFU"
    teamcode     = var.teamcode
  }

  mm_office_cidrs = [
    "10.228.0.0/16", # Harmony VPN
    "10.229.0.0/19", # VPN
    "10.88.12.0/24", # Toronto Corporate Office LAN
    "10.88.16.0/24",  # Toronto Corporate Office WiFi
    "10.226.132.64/26", # developer workspaces
    "10.226.132.128/26", # developer workspaces
    "10.226.17.141/32", # QA test machines
    "10.226.18.12/32", # QA test machines
  ]
}
