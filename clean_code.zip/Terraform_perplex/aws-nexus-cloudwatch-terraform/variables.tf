variable "aws_region" {
  description = "AWS region where the syslog collector EC2 instance will run."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  description = "Prefix used for AWS resource names."
  type        = string
  default     = "nexus-syslog"
}

variable "vpc_id" {
  description = "VPC ID for the syslog collector."
  type        = string
}

variable "subnet_id" {
  description = "Subnet ID for the syslog collector EC2 instance. Use a private subnet when reachable through VPN/Direct Connect."
  type        = string
}

variable "assign_public_ip" {
  description = "Whether to assign a public IP to the syslog collector. Prefer false when using VPN/Direct Connect."
  type        = bool
  default     = false
}

variable "colo_syslog_cidrs" {
  description = "CIDR blocks allowed to send syslog to the collector, for example colo mgmt subnet or public NAT IP /32."
  type        = list(string)
}

variable "ssh_admin_cidrs" {
  description = "CIDR blocks allowed to SSH to the collector. Keep this restricted."
  type        = list(string)
  default     = []
}

variable "key_name" {
  description = "Optional EC2 key pair name for SSH."
  type        = string
  default     = "4ba77f0f-98d5-4db0-ae37-d8636251f77e"
}

variable "instance_type" {
  description = "EC2 instance type for the syslog collector."
  type        = string
  default     = "t3.micro"
}

variable "root_volume_size_gb" {
  description = "Root EBS volume size in GB. Increase if retaining local logs for longer."
  type        = number
  default     = 30
}

variable "log_group_name" {
  description = "CloudWatch Logs log group name."
  type        = string
  default     = "/network/cisco/nexus"
}

variable "log_retention_days" {
  description = "CloudWatch Logs retention in days."
  type        = number
  default     = 90
}

variable "syslog_udp_enabled" {
  description = "Allow UDP/514 syslog from colo CIDRs."
  type        = bool
  default     = true
}

variable "syslog_tcp_enabled" {
  description = "Allow TCP/514 syslog from colo CIDRs."
  type        = bool
  default     = true
}

variable "extra_tags" {
  description = "Additional tags to apply to resources."
  type        = map(string)
  default     = {}
}

variable "env" {}

variable "teamcode" {}