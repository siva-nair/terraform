output "collector_instance_id" {
  description = "EC2 instance ID for the syslog collector."
  value       = aws_instance.collector.id
}

output "collector_private_ip" {
  description = "Private IP address to use as the Cisco Nexus syslog server target."
  value       = aws_instance.collector.private_ip
}

output "collector_public_ip" {
  description = "Public IP address, only populated when assign_public_ip is true."
  value       = aws_instance.collector.public_ip
}

output "cloudwatch_log_group_name" {
  description = "CloudWatch Logs log group receiving Cisco Nexus logs."
  value       = aws_cloudwatch_log_group.nexus.name
}

output "nexus_nxos_example_config" {
  description = "Example Cisco Nexus NX-OS syslog configuration. Replace VRF/source as needed."
  value = <<EOT
conf t
  logging server ${aws_instance.collector.private_ip} 6 use-vrf management
  logging source-interface mgmt0
  logging timestamp milliseconds
  logging level local7 6
end
copy running-config startup-config
EOT
}

# Environment variables for the syslog collector EC2 instance. These are used by the collector's startup script to configure the syslog service and CloudWatch Logs agent.
output "collector_env_vars" {
  description = "Environment variables for the syslog collector EC2 instance."
  value = {
    LOG_GROUP_NAME = var.log_group_name
    AWS_REGION     = var.aws_region
  }
}

# Variable env and teamcode are output for informational purposes, to confirm the environment and team code used for this deployment.
output "env" {
  description = "Environment for this deployment."
  value       = var.env
}
output "teamcode" {
  description = "Team code for this deployment."
  value       = var.teamcode
}



