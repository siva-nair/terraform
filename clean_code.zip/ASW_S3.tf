# main.tf

# Configure the AWS Provider
provider "aws" {
  region = "us-east-1" # Choose your desired region
}

# Create the S3 bucket to store the audio files
resource "aws_s3_bucket" "polly_destination_bucket" {
  bucket = "my-unique-polly-audio-bucket-name" # Bucket names must be globally unique

  tags = {
    Project = "PollyS3Example"
  }
}

# Block public access for the bucket (recommended security practice)
resource "aws_s3_bucket_public_access_block" "polly_destination_bucket_access_block" {
  bucket = aws_s3_bucket.polly_destination_bucket.id
  block_public_acls = true
  block_public_policy = true
  ignore_public_acls = true
  restrict_public_buckets = true
}


# Define an IAM policy that allows writing to the S3 bucket and using Polly
data "aws_iam_policy_document" "polly_s3_access_policy" {
  statement {
    effect = "Allow"
    actions = [
      "s3:PutObject",
      "s3:GetObject"
    ]
    resources = ["${aws_s3_bucket.polly_destination_bucket.arn}/*"]
  }

  statement {
    effect = "Allow"
    actions = ["s3:ListBucket"]
    resources = [aws_s3_bucket.polly_destination_bucket.arn]
  }

  statement {
    effect = "Allow"
    actions = ["polly:StartSpeechSynthesisTask"]
    resources = ["*"] # Polly tasks generally don't have resource ARNs
  }
}

# Example of how to attach this policy to an IAM role (e.g., for a Lambda function)
resource "aws_iam_role" "polly_lambda_role" {
  name = "polly_lambda_role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      },
    ]
  })
}

resource "aws_iam_role_policy" "polly_role_policy_attachment" {
  name = "polly_s3_policy"
  role = aws_iam_role.polly_lambda_role.id
  policy = data.aws_iam_policy_document.polly_s3_access_policy.json
}

# Output the bucket name and ARN to use in your application code (e.g., Lambda environment variables)
output "bucket_name" {
  value = aws_s3_bucket.polly_destination_bucket.id
}

output "role_arn" {
  value = aws_iam_role.polly_lambda_role.arn
}


#https://docs.aws.amazon.com/polly/latest/dg/API_StartSpeechSynthesisTask.html

# Source - https://stackoverflow.com/a/65082930
# Posted by Matthew
# Retrieved 2026-02-09, License - CC BY-SA 4.0

# POST /v1/synthesisTasks HTTP/1.1
#Content-type: application/json

{
   "Engine": "string",
   "LanguageCode": "string",
   "LexiconNames": [ "string" ],
   "OutputFormat": "string",
   "OutputS3BucketName": "string",
   "OutputS3KeyPrefix": "string",
   "SampleRate": "string",
   "SnsTopicArn": "string",
   "SpeechMarkTypes": [ "string" ],
   "Text": "string",
   "TextType": "string",
   "VoiceId": "string"
}


## https://terrateam.io/blog/aws-s3-import