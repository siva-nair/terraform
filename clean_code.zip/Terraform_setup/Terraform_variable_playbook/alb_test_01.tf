

provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}


###################################
# Terraform map_typ object
###################################
#Example 2 – Map of objects
variable "map_of_objects_practice" {
  description = "This is a variable of type Map of objects"
  type = map(object({
    alb_insiance_id  = list(string),
    alb_target_group_arn   = list(string)
  }))
  default = {
    #my_subnets = {
    "tg-1-attch" = {
      alb_insiance_id  = ["10.0.1.26", "10.1.1.26", "10.2.1.26"]
      alb_target_group_arn    = ["tg-1-arn"]
    },
    "tg-2-attch" = {
      alb_insiance_id  = ["11.0.1.26", "11.1.1.26", "11.2.1.26"]
      alb_target_group_arn   = ["tg-2-arn"]
    },
    "tg-3-attch" = {
      alb_insiance_id  = ["12.0.1.26", "12.1.1.26", "12.2.1.26"]
      alb_target_group_arn   = ["tg-3-arn"]
    },
    "tg-4-attch" = {
      alb_insiance_id  = ["13.0.1.26", "13.1.1.26", "13.2.1.26"]
      alb_target_group_arn   = ["tg-4-arn"]
    },
    "tg-5-attch" = {
      alb_insiance_id  = ["14.0.1.26", "14.1.1.26", "14.2.1.26"]
      alb_target_group_arn   = ["tg-5-arn"]
    }
    #}
  }
}

locals {
alb_target_group_arn = {
  group1 = {
    alb_target_name     = "example-alb1"
    alb_target_port     = "3689"
    alb_target_protocol = "TCP"
    alb_target_type     = "instance"
  },
  group2 = {
    alb_target_name     = "example-alb2"
    alb_target_port     = "53"
    alb_target_protocol = "TCP"
    alb_target_type     = "instance"
  }
}

}

locals {
 ec2sflat = [
    for key, ec2 in values(var.map_of_objects_practice)[0].alb_insiance_id: {
      ec2_id  = ec2
      ec2_key = key
    }
  ]


  albsflat = [
    for key, alb_tg in values(var.map_of_objects_practice)[0].alb_target_group_arn : {
      key                 = key
      alb_target_name     = alb_tg
    }
  ]


  alb_config = [
    for pair in setproduct(local.albsflat, local.ec2sflat) : merge(pair[0], pair[1])
  ]
}
output "alb_config" {
  value = local.alb_config
  description = "This is a variable of type Map of objects"
}


output "ec2sflat" {
  value = local.ec2sflat
  description = "This is a variable of type Map of objects"
}

output "albsflat" {
  value = local.albsflat
  description = "This is a variable of type Map of objects"
}


resource "aws_lb_target_group" "this" {

for_each = tomap({
    for t in local.alb_config :
    "${t.ec2_id}:${t.alb_target_name}" => t
  }) 
  name        = each.value.alb_target_name
  port        = "433"
  protocol    = "HTTPS"
  target_type = "instance"
  vpc_id      = "var.vpc_id"

}

resource "aws_lb_target_group_attachment" "this" {
  for_each = {
    for cfg in local.alb_config : "${cfg.key}:${cfg.ec2_key}" => cfg
  }

  target_group_arn = aws_lb_target_group.this[each.value].arn
  target_id        = each.value.ec2_id
  port             = "433"
}
