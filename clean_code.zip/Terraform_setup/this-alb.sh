import csv
import re

def update_csv_with_paragraph(csv_filepath, search_column_name, paragraph_template, output_filepath):
    """
    Finds a value from a specified column in a CSV file, and inserts a modified paragraph 
    into another column for each row.

    Args:
        csv_filepath (str): Path to the input CSV file.
        search_column_name (str): Name of the column to search for values.
        paragraph_template (str): Paragraph template with a placeholder for the found value (e.g., "The value is: {value}.").
        output_filepath (str): Path to the output CSV file.
    """

    with open(csv_filepath, 'r', newline='') as infile, open(output_filepath, 'w', newline='') as outfile:
        reader = csv.DictReader(infile)
        fieldnames = reader.fieldnames + ['modified_paragraph']
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)
        writer.writeheader()

        for row in reader:
            search_value = row.get(search_column_name)
            if search_value:
               modified_paragraph = paragraph_template.format(value=search_value)
            else:
                modified_paragraph = ""

            row['modified_paragraph'] = modified_paragraph
            writer.writerow(row)

# Example usage
csv_filepath = 'input.csv'
search_column_name = 'name'
paragraph_template = "Hello {value}! Welcome to the program."
output_filepath = 'output.csv'

# Create a sample input.csv for testing
with open(csv_filepath, 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['id', 'name', 'age'])
    writer.writerow(['1', 'Alice', '30'])
    writer.writerow(['2', 'Bob', '25'])
    writer.writerow(['3', 'Charlie', '35'])

update_csv_with_paragraph(csv_filepath, search_column_name, paragraph_template, output_filepath)