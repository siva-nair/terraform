
resource "aws_route_table" "tf_public_route_table" {
  for_each   = var.vpc_cidr  
  vpc_id = aws_vpc.staging-vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.qa-igw.id
  }
  tags       = merge(var.project_environment_qa, { Name = "public_route_table-${each.key}" })
}
#############################################################


resource "aws_route_table" "tf_private_route_table" {
   for_each   = var.vpc_cidr  
  vpc_id = aws_vpc.staging-vpc.id

 tags       = merge(var.project_environment_qa, { Name = "private_route_table-${each.key}" })
}

resource "aws_route_table_association" "private_subnet_asso" {
   for_each = var.vpc_cidr
  subnet_id      = aws_subnet.private_subnet[each.key].id
  route_table_id = aws_route_table.tf_private_route_table[each.key].id
} 
resource "aws_route_table_association" "public_subnet_asso" {
   for_each = var.vpc_cidr
  subnet_id      = aws_subnet.public_subnet[each.key].id
  route_table_id = aws_route_table.tf_public_route_table[each.key].id
}


