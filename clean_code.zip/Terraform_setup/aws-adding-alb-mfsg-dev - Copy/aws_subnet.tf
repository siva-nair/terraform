

resource "aws_subnet" "public_subnet" {
  for_each          = var.vpc_cidr
  vpc_id            = aws_vpc.staging-vpc.id
  cidr_block        = each.value.cid_pub
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "public_subnet_${each.key}" })
}
resource "aws_subnet" "private_subnet" {
  for_each          = var.vpc_cidr
  vpc_id            = aws_vpc.staging-vpc.id
  cidr_block        = each.value.cid_pri
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "private_subnet_${each.key}" })
}
