


###############################################################################
// ALB - "external_alb"
###############################################################################

resource "aws_lb" "external_alb" { 
  #for_each = { for k,v in local.ext_data[*] : k => v.subnet }  
  //add line :<need to hard code if the subnets are the same
  name               = "public-alb" // change name to the public ideawaves-ca
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.public-allow_alb_traffic.id]
  subnets            = ["${local.ext_data[0].subnet}", "${local.ext_data[1].subnet}"]
  #subnets            =  [for subnet in var.subnet_cidrs_public : subnet.id]

tags = merge(var.project_environment_qa, { Name = "external_alb-01" })

}

###############################################################################
// ALB - "internal_alb"
###############################################################################
resource "aws_lb" "internal_alb" {
  #for_each = { for k, v in local.int_data[*] : k => v.subnet }  
  name               = "private-alb" // change name to the internal Application Targets
  internal           = true
  load_balancer_type = "application"
  security_groups    = [aws_security_group.private-allow_alb_traffic.id]
  subnets            = ["${local.int_data[0].subnet}", "${local.int_data[1].subnet}"]
  #subnets            = [for subnet in var.subnet_cidrs_private : subnet.id]
tags = merge(var.project_environment_qa, { Name = "internal_alb-01" })
}