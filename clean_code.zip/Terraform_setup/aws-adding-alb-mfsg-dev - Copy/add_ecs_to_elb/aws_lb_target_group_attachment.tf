

# 3. Add the ALB Target Group attachment
#################################################################################
//  .Listener public_alb_listener
#################################################################################
resource "aws_lb_target_group_attachment" "tga-external-private-ip" {
  for_each    = { for k, v in local.ext_data[*] : k => v}  
  # covert a list of instance objects to a map with instance ID as the key, and an instance
  target_group_arn =  aws_lb_target_group.tg_external_alb.arn 
  target_id        = "${each.value.ip_address_ext}"
  port             = 80
  
}
#################################################################################
//  .aws_lb_target_group_attachment 
#################################################################################
resource "aws_lb_target_group_attachment" "tga-internal-private-ip" {
for_each    = { for k, v in local.int_data[*] : k => v }  
  # covert a list of instance objects to a map with instance ID as the key, and an instance
  # object as the value.
  target_group_arn = aws_lb_target_group.tg_internal_alb.arn 
  
  target_id        = "${each.value.ip_address_int}"
  port             = 80
}
