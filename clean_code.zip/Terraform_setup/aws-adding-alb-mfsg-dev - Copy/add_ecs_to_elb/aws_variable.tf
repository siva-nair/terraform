variable "instance_type" {
  description = "Instance type t2.micro"
  type        = string
  default     = "t2.micro"
}

variable "instance_count" {
  description = "EC2 instance count"
  type        = number
  default     = 2
}
variable "enable_public_ip" {
  description = "Enable public IP address"
  type        = bool
  default     = true
}
variable "user_names" {
  description = "IAM usernames"
  type        = list(string)
  default     = ["user1", "user2", "user3s"]
}

variable "project_environment" {
  description = "project name and environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "dev"
  }
}

// Ami ID for free tier
variable "ami_id" {
  description = "TF-ami_id"
  default     = "REDACTED_AWS_RESOURCE_ID"
}

variable "project_environment_dev" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "dev"
  }
}

variable "project_environment_qa" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "qa"
  }
}

variable "project_environment_prod" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "prod"
  }
}


variable "vpc_cidr" {
  description = "VPC Network Map"
  type = map(object({
    cidr    = string
    cid_pri = string
    cid_pub = string
    az_zone = string
  }))
  default = {
    "set_1" = {
      cidr    = "10.5.0.0/16"
      cid_pri = "10.5.5.0/24"
      cid_pub = "10.5.1.0/24"
      az_zone = "us-east-1a"
    },
    "set_2" = {
      cidr    = "11.5.0.0/16"
      cid_pri = "10.5.6.0/24"
      cid_pub = "10.5.2.0/24"
      az_zone = "us-east-1b"
    },
  }
}

variable "availability_zones" {
  type        = list(string)
  description = "List of Availability Zones (e.g. `['us-east-1a', 'us-east-1b', 'us-east-1c']`)"
  default     = ["us-east-1a", "us-east-1b"]
  #default = ["us-east-1a", "us-east-1b","us-east-1c", "us-east-1d"]
}



variable "pub_subnet" {
  description = "assign public subnet"
  type        = any
  default     = []
}

variable "vpc_ids" {
  description = "assign private subnet"
  type        = string
  default     = ""
}

variable "gateway_ids" {
  description = "assign public subnet"
  type        = string
  default     = ""
}
variable "pri_subnet" {
  description = "assign private subnet"
  type        = any
  default     = []
}

variable "prisec_group" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "pubsec_group" {
  description = "assign private subnet"
  type        = any
  default     = []
}


variable "pri_instance" {
  description = "assign public instance"
  type        = any
  default     = []
}
variable "pub_instance" {
  description = "assign private instance"
  type        = any
  default     = []
}

variable "ip_list" {
  type    = list(string)
  default = ["192.168.1.1", "192.168.1.2", "192.168.1.3"]
}


