
###############################################################################
// 2. Create an ALB Target Group
###############################################################################

resource "aws_lb_target_group" "tg_internal_alb" { // Target Group A

  #for_each    = { for k, v in local.int_data[*].name : k => v }
  name        = "tg-internal-alb"
  port        = 80
  protocol    = "HTTP"
  vpc_id      = local.ext_data[0].vpc_ids
  target_type = "ip"
  tags        = merge(var.project_environment_qa, { Name = "tg-extrnal-lb" })
}


resource "aws_lb_target_group" "tg_external_alb" { // Target Group A
  #for_each    = { for k, v in local.ext_data[*].vpc_ids : k => v }
  name        = "tg-extrnal-lb"
  port        = 80
  protocol    = "HTTP"
  vpc_id      = local.ext_data[0].vpc_ids
  target_type = "ip"
  tags        = merge(var.project_environment_qa, { Name = "tg-extrnal-lb" })
}

output "tg_external_alb" {
  #value = aws_lb_target_group.tg_external_alb
  #value = { for k, v in aws_lb_target_group.tg_external_alb[*]: k => v }
   value = aws_lb_target_group.tg_external_alb.arn
}

output "tg_internal_alb" {
  #value = aws_lb_target_group.tg_external_alb
  value = aws_lb_target_group.tg_internal_alb.arn
}