
# Output block to display the value of the "resource_info_value" variable

output "csv_output_vpc_ids_ext" {
  value = { for k, v in local.ext_data[*].vpc_ids : k => v }
}

output "csv_output_ip_ext" {
  value = { for k, v in local.ext_data[*].ip_address_ext : k => v }
}


output "csv_output_subnet_ext" {
  value = { for k, v in local.ext_data[*].subnet : k => v }
}

output "csv_output_alb_name_ext" {
  value = { for k, v in local.ext_data[*].name : k => v }
}


output "csv_output_vpc_ids_int" {
  value = { for k, v in local.int_data[*].vpc_ids : k => v }
}


output "csv_output_ip_int" {
  value = { for k, v in local.int_data[*].ip_address_int : k => v }
}


output "csv_output_subnet_int" {
  value = { for k, v in local.int_data[*].subnet : k => v }
}

output "csv_output_alb_name_int" {
  value = { for k, v in local.int_data[*].name : k => v }
}


output "external_alb" {
  #value = aws_lb_target_group.tg_external_alb
  #value = { for k, v in aws_lb_target_group.tg_external_alb[*]: k => v }
   value = aws_lb.external_alb.arn
}

output "internal_alb" {
  #value = aws_lb_target_group.tg_external_alb
  value = aws_lb.internal_alb.arn
}


output "tga-internal-private-ip" {
   value = values(aws_lb_target_group_attachment.tga-internal-private-ip)[*].id
}

output "tga-external-private-ip" {
  value = values(aws_lb_target_group_attachment.tga-external-private-ip)[*].id
}




output "certificate_config" {
   value = aws_acm_certificate.certificate_config.arn
}

output "listener_certificate" {
  value = aws_lb_listener_certificate.listener_certificate

}