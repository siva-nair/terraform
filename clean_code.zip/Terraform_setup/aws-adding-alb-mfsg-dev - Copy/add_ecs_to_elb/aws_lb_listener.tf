
#################################################################################
// 2 .Listener private_alb_listener port 60
#################################################################################
resource "aws_lb_listener" "int_alb_listener_80" {
  load_balancer_arn = aws_lb.internal_alb.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.tg_internal_alb.arn
  }
  tags = merge(var.project_environment_qa, { Name = "int_alb_listener_80" })
}

#################################################################################
// 2 .Listener oublic_alb_listener port 60
#################################################################################
resource "aws_lb_listener" "ext_alb_listener_80" {
  #for_each = { for listener in aws_lb_target_group.tg_external_alb[*] : listener => listener }
  load_balancer_arn = aws_lb.external_alb.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.tg_external_alb.arn
  }
  tags = merge(var.project_environment_qa, { Name = "ext_alb_listener_80" })
}


#################################################################################
// ext_alb_listener
#################################################################################
resource "aws_lb_listener" "ext_alb_listener_443" {
  load_balancer_arn = aws_lb.external_alb.arn
  port              = "443"
  protocol          = "HTTPS"
  certificate_arn   = aws_acm_certificate.certificate_config.arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.tg_external_alb.arn
  }
  tags = merge(var.project_environment_qa, { Name = "ext_alb_listener_443" })
}


#################################################################################
// int_alb_listener_80
#################################################################################
// Listener
resource "aws_lb_listener" "int_alb_listener_443" {

  load_balancer_arn = aws_lb.internal_alb.arn
  port              = "443"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.tg_internal_alb.arn
  }
  tags = merge(var.project_environment_qa, { Name = "int_alb_listener_443" })
}
