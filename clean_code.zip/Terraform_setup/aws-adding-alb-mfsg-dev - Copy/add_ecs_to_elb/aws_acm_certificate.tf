#################################################################################
// certificate_config.tf
#################################################################################

# Request and validate an SSL certificate from AWS Certificate Manager (ACM)

resource "aws_acm_certificate" "certificate_config" { 
  domain_name       =  "ideawaves.ca"
  validation_method = "DNS"
  tags = merge(var.project_environment_qa, { Name = "SSL_certificate" })
}

# Associate the SSL certificate with the ALB listener
resource "aws_lb_listener_certificate" "listener_certificate" {
  for_each = { for k, v in aws_acm_certificate.certificate_config[*] : k => v}  
  listener_arn    = aws_lb_listener.ext_alb_listener_443.arn
  certificate_arn = "${each.value.arn}"
  
}

