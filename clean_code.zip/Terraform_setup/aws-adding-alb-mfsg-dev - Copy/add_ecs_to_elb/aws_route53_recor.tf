//See the Terraform Route53 Record docs

resource "aws_route53_record" "alias_route53_record" {
  zone_id = "Z01292673BAW0ATHXBGRU" # Replace with your zone ID
  name    = "ideawaves.ca" # Replace with your name/domain/subdomain
  type    = "A"

  alias {
    name                   = aws_lb.external_alb.dns_name
    zone_id                = aws_lb.external_alb.zone_id
    evaluate_target_health = true

  }
}


output "aws_route53_record" {  
  value = "${aws_route53_record.alias_route53_record}"
}
