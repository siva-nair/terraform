# security_group.tf

#################################################################
# Create aws_security_group
#################################################################

################################################################

resource "aws_security_group" "all-80-443-22-sg" {
  name        = "all-80-443-22-sg"
  description = "Security group for my application"
  vpc_id      = aws_vpc.staging-vpc.id


  ingress {
    description = "ingress_rule_80"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "ingress_rule_443"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]

  }
    ingress {
    description = "ingress_rule_22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "egress_rule_all"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"] # Allow all outbound traffic
  }
  tags = {
    Name = "all-80-443-22-sg"
  }

}