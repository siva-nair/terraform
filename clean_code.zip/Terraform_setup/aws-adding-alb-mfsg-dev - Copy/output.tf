
output "pub_subnet" { 
    description = "The ID of the pub_subnet"  
    value = values(aws_subnet.public_subnet)[*].id
    }

output "vpc_ids" {   
    description = "The ID of the vpc_ids"  
    value = aws_vpc.staging-vpc.id
    }
output "gateway_ids" {  
    description = "The ID of the gateway_ids"  
    value =aws_internet_gateway.qa-igw.id
    }

output "pri_subnet" { 
    description = "The ID of the pri_subnet"
    value = values(aws_subnet.private_subnet)[*].id
    }

output "pub_int_instance" { 
    description = "The ID of the pub_int_instance"
    value = values(aws_instance.public_ec)[*].private_ip
    }

output "pri_int_instance" { 
    description = "The ID of the pri_int_instance"
    value = values(aws_instance.private_ec)[*].private_ip
    }

output "pub_ext_instance" {
    description = "The ID of the pub_ext_instance" 
    value = values(aws_instance.public_ec)[*].public_ip
    }
