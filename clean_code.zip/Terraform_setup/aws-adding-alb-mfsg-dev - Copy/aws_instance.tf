
# Create a subnet in each availability zone in the VPC. Keep in mind that at this point these subnets are private without internet access. They would need other networking resources for making them accesible

# Put an instance in each subnet
resource "aws_instance" "public_ec" {
  #count                       = length(var.availability_zones)
  for_each = aws_subnet.public_subnet
  ami                         = var.ami_id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.public_subnet[each.key].id
  vpc_security_group_ids      = [aws_security_group.all-80-443-22-sg.id]
  associate_public_ip_address = var.enable_public_ip
  key_name                    = "demo-ec2-public-keypair"
  tags                        = merge(var.project_environment_qa, { Name = "public_ec_${each.key}" })
  user_data = file("script-for-ec1s-01.sh")
}

# Put an instance in each subnet
resource "aws_instance" "private_ec" {
  #count                  = length(var.availability_zones)
  for_each = aws_subnet.private_subnet
  ami                    = var.ami_id
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.private_subnet[each.key].id
  vpc_security_group_ids = [aws_security_group.all-80-443-22-sg.id]
  key_name               = "demo-ec2-private-keypair"
  tags                   = merge(var.project_environment_qa, { Name = "private_ec_${each.key}" })
  user_data = file("script-for-ec2s-01.sh")
}
    