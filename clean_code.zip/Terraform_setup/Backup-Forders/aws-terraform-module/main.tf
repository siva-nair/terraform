#################################################################
# Create Subnets
#################################################################
provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}
provider "aws" {
   region     = var.web_region
   access_key = REDACTED_SECRET
   secret_key = REDACTED_SECRET
}

module "jhooq-webserver-1" {
  source = ".//module-1"
  
  web_instance_type = "t2.large"
}

output "public_ip_ec2" {
  value       = module.module-1.public_ip_ec2
  description = "Public IP of EC2"
}

module "jhooq-webserver-2" {
  source = ".//module-2"
}
 