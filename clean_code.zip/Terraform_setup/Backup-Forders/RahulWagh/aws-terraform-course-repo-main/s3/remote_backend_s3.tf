terraform {
  backend "s3" {
    bucket = "aws-jhooq-demo-project"
    key    = "ec2-setup/terraform.tfstate"
    region = "us-east-1"
  }
}