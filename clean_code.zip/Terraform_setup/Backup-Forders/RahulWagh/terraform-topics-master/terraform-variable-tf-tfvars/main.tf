provider "aws" {
  region     = var.location
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}

resource "aws_instance" "ec2_example" {

  ami           = "REDACTED_AWS_RESOURCE_ID"
  instance_type =  var.instance_type

  tags = {
    Name = var.tag
  }
}