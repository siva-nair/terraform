provider "aws" {
   region = "eu-central-1"
   shared_credentials_files = ["/home/ubuntu/.aws/credentials"]
}

resource "aws_instance" "ec2_example" {
   ami           = "REDACTED_AWS_RESOURCE_ID"
   instance_type =  "t2.micro"
   tags = {
           Name = "Terraform EC2"
   }
}
