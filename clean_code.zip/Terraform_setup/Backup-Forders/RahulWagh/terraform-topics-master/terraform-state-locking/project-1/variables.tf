variable "access_key" {
    default = "REDACTED_AWS_ACCESS_KEY_ID"
}

variable "secret_key" {
    default = "sxllM5d/aQQnbAB/MG4jOdkxrLTM3BHxuox4VI2M"
}
