provider "aws" {
   region     = "eu-central-1"
   access_key = REDACTED_SECRET
   secret_key = REDACTED_SECRET
}

resource "aws_instance" "ec2_example" {
    ami = "REDACTED_AWS_RESOURCE_ID"
    instance_type = "t2.micro"
    tags = {
      Name = "EC2 Instance with remote state"
    }
}

terraform {
    backend "s3" {
        bucket = "jhooq-terraform-s3-bucket"
        key    = "jhooq/terraform/remote/s3/terraform.tfstate"
        region     = "eu-central-1"
        dynamodb_table = "dynamodb-state-locking"
    }
}