provider "aws" {
  region                   = "eu-central-1"
  shared_credentials_files = ["/Users/rahulwagh/.aws/credentials"]
}

locals {
  instance_name = "${terraform.workspace}-instance" 
}

resource "aws_instance" "ec2_example" {

    ami = "REDACTED_AWS_RESOURCE_ID" 

    instance_type = var.instance_type

    tags = {
      Name = local.instance_name
    }
}