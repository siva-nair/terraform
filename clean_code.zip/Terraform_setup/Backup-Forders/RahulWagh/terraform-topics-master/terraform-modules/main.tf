provider "aws" {
   region     = var.web_region
   access_key = REDACTED_SECRET
   secret_key = REDACTED_SECRET
}

module "jhooq-webserver-1" {
  source = ".//module-1"
}

module "jhooq-webserver-2" {
  source = ".//module-2"
}