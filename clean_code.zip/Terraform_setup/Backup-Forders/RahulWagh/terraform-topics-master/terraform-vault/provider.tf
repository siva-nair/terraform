provider "vault" {
  address = var.vault_address
  token   = REDACTED_SECRET
}


provider "aws" {
  region     = var.region
  access_key = REDACTED_SECRET
  secret_key = REDACTED_SECRET
  token      = REDACTED_SECRET
}