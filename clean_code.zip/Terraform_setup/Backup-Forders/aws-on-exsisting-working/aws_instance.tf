#################################################################
# Block - EC2
#################################################################
resource "aws_instance" "ec1_private" {
  ami = "${var.ami_id}"
  subnet_id = aws_subnet.staging_subnet_private_1a.id
  instance_type =  var.instance_type
  #associate_public_ip_address = var.enable_public_ip
  vpc_security_group_ids = [aws_security_group.TF-dynamic-security-group.id]
  #tags = {Name = var.tag}
  tags = {
    Name = "TF-private-${local.staging_env}"
  }
  user_data = <<-EOF
                    #!/bin/bash

                    # Update system packages
                    sudo apt update -y

                    # Install Apache2
                    sudo apt install apache2 -y

                    # Create a directory for your website files
                    sudo mkdir -p /var/www/ideawaves.ca

                    # Create a virtual host configuration file
                    sudo nano /etc/apache2/sites-available/ideawaves.ca.conf 

                    # Paste the following configuration into the file, replacing 'ideawaves.ca' with your actual domain: 

                    <<EOF
                    <VirtualHost *:80>
                        ServerName ideawaves.ca
                        ServerAlias www.ideawaves.ca
                        DocumentRoot /var/www/ideawaves.ca
                        ErrorLog /var/log/apache2/ideawaves.ca-error_log
                        CustomLog /var/log/apache2/ideawaves.ca-access_log combined
                    </VirtualHost>
EOF
}
#################################################################
# Dynamic Block - EC2
#################################################################
resource "aws_instance" "ec2_public" {
  ami = "${var.ami_id}"
  subnet_id = aws_subnet.staging_subnet_public_1b.id
  instance_type =  var.instance_type
  #vpc_security_group_ids = [data.aws_security_group.sg-public.id]
  #vpc_security_group_ids = [aws_security_group.my_security_group.id ]
  vpc_security_group_ids = [aws_security_group.TF_security_group.id]
  associate_public_ip_address = var.enable_public_ip
  #tags = {Name = var.tag}
    tags = {
    Name = "TF-ec2_public-${local.staging_env}"
  }
    user_data = <<-EOF
                    #!/bin/bash

                    # Update system packages
                    sudo apt update -y

                    # Install Apache2
                    sudo apt install apache2 -y

                    # Create a directory for your website files
                    sudo mkdir -p /var/www/ideawaves.ca

                    # Create a virtual host configuration file
                    sudo nano /etc/apache2/sites-available/ideawaves.ca.conf 

                    # Paste the following configuration into the file, replacing 'ideawaves.ca' with your actual domain: 

                    <<EOF
                    <VirtualHost *:80>
                        ServerName ideawaves.ca
                        ServerAlias www.ideawaves.ca
                        DocumentRoot /var/www/ideawaves.ca
                        ErrorLog /var/log/apache2/ideawaves.ca-error_log
                        CustomLog /var/log/apache2/ideawaves.ca-access_log combined
                    </VirtualHost>
EOF
}

resource "aws_instance" "ec1_public" {
  ami = "${var.ami_id}"
  subnet_id = aws_subnet.staging_subnet_public_1b.id
  instance_type =  var.instance_type
  #vpc_security_group_ids = [data.aws_security_group.sg-public.id]
  #vpc_security_group_ids = [aws_security_group.my_security_group.id ]
  vpc_security_group_ids = [aws_security_group.TF_security_group.id]
  associate_public_ip_address = var.enable_public_ip
  #tags = {Name = var.tag}
    tags = {
    Name = "TF-ec1_public-${local.staging_env}"
  }
    user_data = <<-EOF
                    #!/bin/bash

                    # Update system packages
                    sudo apt update -y

                    # Install Apache2
                    sudo apt install apache2 -y

                    # Create a directory for your website files
                    sudo mkdir -p /var/www/ideawaves.ca

                    # Create a virtual host configuration file
                    sudo nano /etc/apache2/sites-available/ideawaves.ca.conf 

                    # Paste the following configuration into the file, replacing 'ideawaves.ca' with your actual domain: 

                    <<EOF
                    <VirtualHost *:80>
                        ServerName ideawaves.ca
                        ServerAlias www.ideawaves.ca
                        DocumentRoot /var/www/ideawaves.ca
                        ErrorLog /var/log/apache2/ideawaves.ca-error_log
                        CustomLog /var/log/apache2/ideawaves.ca-access_log combined
                    </VirtualHost>
EOF
}

