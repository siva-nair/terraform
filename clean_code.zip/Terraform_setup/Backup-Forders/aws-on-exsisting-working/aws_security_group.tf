#################################################################
# Create aws_security_group
#################################################################
resource "aws_security_group" "TF_security_group" {
  name        = "TF-security-group"
  description = "Security group for my application"
  vpc_id = aws_vpc.staging-vpc.id
  
  ingress {
    description = "ingress_rule_22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]  # Allow SSH from anywhere
  }

  ingress {
    description = "ingress_rule_80"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]  

  }

  ingress {
    description = "ingress_rule_443"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]  

  }
  egress {
    description = "egress_rule_all"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]  # Allow all outbound traffic
  }
      tags = {
      Name = "TF aws_security_groups"
   }

}
#################################################################
# Dynamic Block - security group - main
#################################################################
resource "aws_security_group" "TF-dynamic-security-group" {
   name   = "TF-dynamic-security-group"
   vpc_id = aws_vpc.staging-vpc.id

   dynamic "ingress" {
      for_each = local.ingress_rules

      content {
         description = ingress.value.description
         from_port   = ingress.value.port
         to_port     = ingress.value.port
         protocol    = "tcp"
         cidr_blocks = ["0.0.0.0/0"]
      }
   }
  egress {
    description = "egress_rule_all"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]  # Allow all outbound traffic
  }
   tags = {
      Name = "TF aws_security_group dynamic"
   }
}
