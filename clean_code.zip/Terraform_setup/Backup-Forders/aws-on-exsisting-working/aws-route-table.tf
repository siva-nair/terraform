
resource "aws_route_table" "tf_igw-route_table" {
  vpc_id = aws_vpc.staging-vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.tf_igw.id
  }

  tags = {
    Name = "tf_igw-route_table"
  }
}

resource "aws_route_table" "tf_igw_route_table_loop" {
  vpc_id = "${aws_vpc.staging-vpc.id}"
  tags = {
    Name = "tf_igw-route_table"
  }
}

resource "aws_route_table_association" "tf1-route_table_association" {
  subnet_id      = aws_subnet.staging_subnet_public_1b.id
  route_table_id = aws_route_table.tf_igw-route_table.id
}
resource "aws_route_table_association" "tf2-route_table_association" {
  subnet_id      = aws_subnet.staging_subnet_public_1a.id
  route_table_id = aws_route_table.tf_igw-route_table.id
}

resource "aws_route_table_association" "public" {
  count = "${length(var.subnet_cidrs_public)}"

  subnet_id      = "${element(aws_subnet.public.*.id, count.index)}"
  route_table_id = "${aws_route_table.tf_igw-route_table.id}"
  
}

resource "aws_route_table_association" "private" {
  count = "${length(var.subnet_cidrs_public)}"

  subnet_id      = "${element(aws_subnet.public.*.id, count.index)}"
  route_table_id = "${aws_route_table.tf_igw-route_table.id}"
  
}
