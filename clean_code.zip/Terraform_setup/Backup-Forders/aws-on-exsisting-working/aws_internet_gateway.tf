resource "aws_internet_gateway" "tf_igw" {
  vpc_id = aws_vpc.staging-vpc.id

  tags = {
    Name = "TF-staging-igw"
  }
}