#################################################################
#VPC
#################################################################

// Exsisting vpc
variable "vpc_id" {
  description = "TF-exsisting_vpc"
  type = string
  default = "REDACTED_AWS_RESOURCE_ID"
}
#################################################################
# Subnets
#################################################################
// Exsisting Subnet 1
variable "subnet_prv1" {
  description = "TF-private_subnet_1"
  type = string
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 2
variable "subnet_prv2" {
  description = "TF-private_subnet_2"
  type = string
  default = "REDACTED_AWS_RESOURCE_ID"
}

// Exsisting Subnet 1
variable "subnet_pub1" {
  description = "TF-public_subnet_1"
  type = string
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 2
variable "subnet_pub2" {
  description = "TF-public_subnet_2"
  type = string
  default = "REDACTED_AWS_RESOURCE_ID"
}
#################################################################
# EC2
#################################################################
// Ami ID for free tier
variable "ami_id" {
  description = "TF-ami_id"
  type = string
  default = "REDACTED_AWS_RESOURCE_ID"
}


variable "instance_count" {
  description = "TF-ec2_instance_count"
  type        = number
  default     = 1
}  
#################################################################
#ENABLE PUBLIC IP -user_names //list
#################################################################
variable "enable_public_ip" {
  description = "TF-enable_public_ip_address"
  type        = bool
  default     = true
}
#################################################################
# TAGS
#################################################################
// Tags for ec2
variable "tag" {
   type = string
   description = "The tag for the EC2 instance"
   default     = "EC2 instance"
}

#################################################################
#Create Users -user_names //list
#################################################################
variable "user_names" {
  description = "TF-iam_username"
  type        = list(string)
  default     = ["user1", "user2", "user3"]
}
#################################################################
# Project ID
#################################################################

variable "project_id" {
  type        = string
  description = "TF-the_project_id"
  default     = "TF-project_001-001-01"
}
#################################################################
# Project LOCATION
#################################################################
variable "location" {
   description = "TF-region_for_project"
   default     = "us-east-1"
   type        = string
}
#################################################################
# Project DEV //map
#################################################################
variable "project_environment_dev" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "dev"
  }
}
#################################################################
# Project QA
#################################################################
variable "project_environment_qa" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "qa"
  }
}
#################################################################
# Project PROD
#################################################################
variable "project_environment_prod" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "prod"
  }
}

#################################################################
# Project PROD
#################################################################


variable "instance_type_dev" {
  description = "TF-instance_type"
  type = string
  default = "t2.micro"
}
#variable "instance_type_qa" {}
#variable "instance_type_prod" {}
#variable "environment_name" {}
variable "instance_type" {
  description = "TF-instance_type"
  type = string
  default = "t2.micro"
}
variable "private_security_group_id" {
  description = "TF-security_group"
  type        = string
  default = "REDACTED_AWS_RESOURCE_ID"
  
}
variable "public_security_group_id" {
  description = "TF-security_group"
  type        = string
  default = "REDACTED_AWS_RESOURCE_ID"
  
}

variable "subnet_cidrs_public" {
  description = "Subnet CIDRs for public subnets (length must match configured availability_zones)"
  # this could be further simplified / computed using cidrsubnet() etc.
  # https://www.terraform.io/docs/configuration/interpolation.html#cidrsubnet-iprange-newbits-netnum-
  default = ["10.5.10.0/24", "10.5.20.0/24","10.5.30.0/24","10.5.40.0/24"]
  type = list(string)
}

variable "subnet_cidrs_private" {
  description = "Subnet CIDRs for pprivate subnets (length must match configured availability_zones)"
  # this could be further simplified / computed using cidrsubnet() etc.
  # https://www.terraform.io/docs/configuration/interpolation.html#cidrsubnet-iprange-newbits-netnum-
  default = ["10.5.15.0/24", "10.5.25.0/24","10.5.35.0/24","10.5.45.0/24"]
  type = list(string)
}