#################################################################
# Create Subnets
#################################################################
resource "aws_subnet" "staging_subnet_public_1a" {
  vpc_id = aws_vpc.staging-vpc.id
  availability_zone    = "us-east-1a"
  cidr_block = "10.5.1.0/24"

  tags = {
    Name = "TF-public-1a-${local.staging_env}"
  }
}

resource "aws_subnet" "staging_subnet_public_1b" {
  vpc_id = aws_vpc.staging-vpc.id
  availability_zone    = "us-east-1b"
  cidr_block = "10.5.2.0/24"

  tags = {
    Name = "TF-public-1b-${local.staging_env}"
  }
}

resource "aws_subnet" "staging_subnet_private_1a" {
  vpc_id = aws_vpc.staging-vpc.id
  availability_zone    = "us-east-1a"
  cidr_block = "10.5.3.0/24"

  tags = {
    Name = "TF-private-1a-${local.staging_env}"
  }
}

resource "aws_subnet" "staging_subnet_private_1b" {
  vpc_id = aws_vpc.staging-vpc.id
  availability_zone    = "us-east-1b"
  cidr_block = "10.5.4.0/24"

  tags = {
    Name = "TF-private-1c-${local.staging_env}-subnet-tag"
  }
}


###############################################################################
resource "aws_subnet" "public" {
  count = "${length(var.subnet_cidrs_public)}"

  vpc_id = "${aws_vpc.staging-vpc.id}"
  cidr_block = "${var.subnet_cidrs_public[count.index]}"
  availability_zone = "${var.availability_zones[count.index]}"
    tags = {
  Name = "TF-public-1c-${local.staging_env}-${count.index}"
  }
}

resource "aws_subnet" "private" {
  count = "${length(var.subnet_cidrs_private)}"

  vpc_id = "${aws_vpc.staging-vpc.id}"
  cidr_block = "${var.subnet_cidrs_private[count.index]}"
  availability_zone = "${var.availability_zones[count.index]}"
    tags = {
    Name = "TF-private-1c-${local.staging_env}-${count.index}"
  }
}
###############################################################################
