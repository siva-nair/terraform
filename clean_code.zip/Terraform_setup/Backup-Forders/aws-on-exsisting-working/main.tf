
#################################################################
# Dynamic Block - locals
#################################################################

locals {
   ingress_rules = [
    {
      port        = 443
      description = "Ingress rules for port 443"
   },
   {
      port        = 80
      description = "Ingree rules for port 80"
   },
   {
      port        = 22
      description = "Ingree rules for port 22"
   }   
   ]
}
