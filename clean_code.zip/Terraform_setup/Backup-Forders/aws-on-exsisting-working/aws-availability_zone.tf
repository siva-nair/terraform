
variable "availability_zones" {
  type        = list(string)
  description = "List of Availability Zones (e.g. `['us-east-1a', 'us-east-1b', 'us-east-1c']`)"
  default = ["us-east-1a", "us-east-1b", "us-east-1c", "us-east-1d"]
}
