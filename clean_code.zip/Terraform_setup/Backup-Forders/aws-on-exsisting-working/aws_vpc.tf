#################################################################
# Create VPC
#################################################################

resource "aws_vpc" "staging-vpc" {
  cidr_block = "10.5.0.0/16"
  enable_dns_hostnames = true
  tags = {
    Name = "TF-${local.staging_env}-vpc"
  }
}