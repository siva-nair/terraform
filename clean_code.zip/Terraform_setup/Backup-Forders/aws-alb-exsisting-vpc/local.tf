# aws_vpc.tf
locals {
  staging_env = "staging"
}

