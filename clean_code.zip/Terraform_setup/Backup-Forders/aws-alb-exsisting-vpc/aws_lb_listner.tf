locals {

  lb_listener_rules = {

    "rule1" = {

      condition = {

        path_pattern = "/api/v1/*"

      },

      action = {

        type = "forward",

        target_group_arn = "REDACTED_AWS_ARN"

      }

    },

    "rule2" = {

      condition = {

        host_header = "www.example.com"

      },

      action = {

        type = "forward",

        target_group_arn = "REDACTED_AWS_ARN"

      }

    }

  }

}

# aws_lb_listner.tf

# Create a listener for the ALB
resource "aws_lb_listener" "https_listener" {
  load_balancer_arn = aws_lb.my_alb.arn
  protocol          = "HTTPS"
  port              = "443"
  certificate_arn = aws_acm_certificate.ideawaves_com.arn

  default_action {
    type = "forward"
    target_group_arn = aws_lb_target_group.https_tg.arn
  }

}

resource "aws_lb_listener_rule" "static_https" {
  listener_arn = aws_lb_listener.https_listener.arn
  priority     = 100

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.https_tg.arn
  }

  condition {
    path_pattern {
      values = ["/static_https/*"]
    }
  }

  condition {
    host_header {
      values = ["ideawaves.ca"]
    }
  }
}


resource "aws_lb_listener" "http_listener" {
  load_balancer_arn = aws_lb.my_alb.arn
  protocol          = "HTTP"
  port              = "80"
  #certificate_arn = aws_acm_certificate.ideawaves_com.arn

  default_action {
    type = "forward"
    target_group_arn = aws_lb_target_group.http_tg.arn
  }
 
} 

resource "aws_lb_listener_rule" "static_http" {
  listener_arn = aws_lb_listener.http_listener.arn
  priority     = 100

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.http_tg.arn
  }

  condition {
    path_pattern {
      values = ["/static_http/*"]
    }
  }

  condition {
    host_header {
      values = ["ideawaves.ca"]
    }
  }
}