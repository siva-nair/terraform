variable "instance_type" {
   description = "Instance type t2.micro"
   type        = string
   default     = "t2.micro"
} 

variable "instance_count" {
  description = "EC2 instance count"
  type        = number
  default     = 2
}  
variable "enable_public_ip" {
  description = "Enable public IP address"
  type        = bool
  default     = true
}
variable "user_names" {
  description = "IAM usernames"
  type        = list(string)
  default     = ["user1", "user2", "user3s"]
}

variable "project_environment" {
  description = "project name and environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "dev"
  }
}

// Exsisting Subnet 1
variable "subnet_pub1a" {
  description = "TF-public_subnet_1"
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 2
variable "subnet_prv1a" {
  description = "TF-private_subnet_1"
  default = "REDACTED_AWS_RESOURCE_ID"
}

// Exsisting Subnet 1
variable "subnet_pub1b" {
  description = "TF-public_subnet_2"
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 2
variable "subnet_prv1b" {
  description = "TF-prvate_subnet_2"
  default = "REDACTED_AWS_RESOURCE_ID"
}


variable "security_group_id_public" {
  default = "REDACTED_AWS_RESOURCE_ID"
}
variable "security_group_id_private" {
  default = "REDACTED_AWS_RESOURCE_ID"
}

// Exsisting vpc
variable "vpc_id" {
  description = "TF-exsisting_vpc"
  default = "REDACTED_AWS_RESOURCE_ID"
}

variable "my_certificate" {
  description = "ideawaves.ca SSL certificate"
  type        = map(string)
  default     = {
  domain_name       = "ideawaves.ca"
  validation_method = "DNS"
  arn = "aREDACTED_AWS_ARN"
  }
}
variable "https_tg" {
  description = "https_tg Groups"
  type        = map(string)
  default     = {  
    name     = "https-tg"
    port         = "443"
    protocol     = "HTTPS"
    vpc_id       = "REDACTED_AWS_RESOURCE_ID"
    target_type  = "ip"
}
  
}
variable "ssh_tg" {
  description = "ssh_tg Groups"
  type        = map(string)
  default     = {  
    name     = "ssh-tg"
    port         = "80"
    protocol     = "HTTPS"
    vpc_id       = "REDACTED_AWS_RESOURCE_ID"
    target_type  = "ip"
}
  
}
variable "http_tg" {
  description = "http_tg Groups"
  type        = map(string)
  default     = {  
    name     = "http-tg"
    port         = "80"
    protocol     = "TCP"
    vpc_id       = "REDACTED_AWS_RESOURCE_ID"
    target_type  = "ip"
}
  
}
variable "instance1" {
  description = "Target instance"
  default = "public_ec1"
}
