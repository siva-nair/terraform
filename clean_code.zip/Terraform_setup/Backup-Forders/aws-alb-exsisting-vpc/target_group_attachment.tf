#################################################################
# aws_lb_target_group_attachment
#################################################################

locals {
  target_groups = ["1", "2", "3"]
}


resource "aws_lb_target_group_attachment" "target_group_attachments_https" {

  for_each = { 

    "instance1" = { target_id = "11.5.1.80", port = "443" },
    "instance2" = { target_id = "11.5.2.80", port = "443" },
   
  }


  target_group_arn = aws_lb_target_group.https_tg.arn
  target_id = each.value.target_id
  port = each.value.port

}

resource "aws_lb_target_group_attachment" "target_group_attachments_http" {

  for_each = { 

    "instance1" = { target_id = "11.5.1.80", port = "80" },
    "instance2" = { target_id = "11.5.2.80", port = "80" },
    
  }


  target_group_arn = aws_lb_target_group.http_tg.arn
  target_id = each.value.target_id
  port = each.value.port

}

resource "aws_lb_target_group_attachment" "target_group_attachments_ssh" {

  for_each = { 

    "instance1" = { target_id = "11.5.1.80", port = "22" },
    "instance2" = { target_id = "11.5.2.80", port = "22" },     
  }


  target_group_arn = aws_lb_target_group.ssh_tg.arn
  target_id = each.value.target_id
  port = each.value.port

}

resource "aws_lb_target_group_attachment" "target_group_attachments_mix" {

  for_each = { 

    "instance1" = { target_id = "11.5.1.80", port = "80" },
    "instance2" = { target_id = "11.5.2.80", port = "80" },
    "instance1" = { target_id = "11.5.1.80", port = "22" },
    "instance2" = { target_id = "11.5.2.80", port = "22" }, 
    "instance1" = { target_id = "11.5.1.80", port = "443" },
    "instance2" = { target_id = "11.5.2.80", port = "443" },        
  }


  target_group_arn = aws_lb_target_group.https_tg.arn
  target_id = each.value.target_id
  port = each.value.port

}