#################################################################
# aws_lb_target_group
#################################################################
// Target groups
resource "aws_lb_target_group" "https_tg" { // Target Group A
 name     = "https-tg"
    port         = "443"
    protocol     = "HTTPS"
    vpc_id       = "REDACTED_AWS_RESOURCE_ID"
    target_type  = "ip"
}

resource "aws_lb_target_group" "http_tg" { // Target Group A
 name     = "http-tg"
    port         = "80"
    protocol     = "HTTP"
    vpc_id       = "REDACTED_AWS_RESOURCE_ID"
    target_type  = "ip"
}
// Target groups
resource "aws_lb_target_group" "ssh_tg" { // Target Group A
 name     = "ssh-tg"
    port         = "22"
    protocol     = "TCP"
    vpc_id       = "REDACTED_AWS_RESOURCE_ID"
    target_type  = "ip"
}

