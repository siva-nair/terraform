# certificate_config.tf

# Request and validate an SSL certificate from AWS Certificate Manager (ACM)

# Associate the SSL certificate with the ALB listener
resource "aws_lb_listener_certificate" "my_certificate" {
  listener_arn = aws_lb_listener.https_listener.arn
  certificate_arn = aws_acm_certificate.ideawaves_com.arn
}


resource "aws_acm_certificate" "ideawaves_com" {
  domain_name       = "ideawaves.ca"
  validation_method = "DNS"
}


