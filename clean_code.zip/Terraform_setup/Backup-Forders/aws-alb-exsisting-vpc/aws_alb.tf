# Create an ALB
resource "aws_lb" "my_alb" {
  name            = "my-alb"
  internal        = false
  load_balancer_type = "application"
  security_groups = [var.security_group_id_public]
  subnets         = [var.subnet_pub1a, var.subnet_pub1b]

  tags = {
    Name = "my_alb"
  }
}