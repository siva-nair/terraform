output "instance_ip" {
    
   value = [aws_instance.public_ec1.public_ip,
   aws_instance.public_ec1.private_ip,
   aws_instance.private_ec1.private_ip]


}