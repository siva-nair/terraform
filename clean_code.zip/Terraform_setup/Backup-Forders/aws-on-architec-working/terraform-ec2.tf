
// "ec2_aws_subnet 1" "pre_exist_vpc"
resource "aws_instance" "public_ec1" {
  ami = "${var.ami_id}"
  instance_type = "${var.instance_type}"
  subnet_id = "${var.subnet_pub1a}"
  #count = var.instance_count
  security_groups = [var.security_group_id_public]
  associate_public_ip_address = var.enable_public_ip
  key_name      = "demo-ec2-public-keypair"  
  #tags = var.project_environment_prod
  tags = merge(var.project_environment_prod, {Name = "public_ec1"})
user_data = <<-EOF
                    #!/bin/bash

                    # Update system packages
                    sudo apt update -y

                    # Install Apache2
                    sudo apt install apache2 -y
                    sudo systemctl start apache2
                    sudo systemctl enable apache2                    
					
					cd /var/www/html/
					sudo rm -f index.html
					# Create a basic "index.html" file
					sudo touch index.html
					sudo echo "<html><head><title>Apache Test Page</title></head><body><h1>public_ec1 - It's working</h1></body></html>" | sudo tee /var/www/html/index.html


					# Create a test web page directory
					sudo mkdir -p /var/www/html/foo

					cd /var/www/html/foo

					# Create a basic "index.html" file
					sudo touch index.html
					sudo echo "<html><head><title>Apache Test Page Foo</title></head><body><h1>public_ec1/Foo - It's working</h1></body></html>" | sudo tee /var/www/html/foo/index.html



					# Create a test web page directory
					sudo mkdir -p /var/www/html/bar
					cd /var/www/html/bar				
					sudo touch index.html
					# Create a basic "index.html" file
					sudo echo "<html><head><title>Apache Test Page Bar</title></head><body><h1>public_ec1/Bar - It's working</h1></body></html>" | sudo tee /var/www/html/bar/index.html

					# Restart Apache service
					sudo systemctl restart apache2                     
					EOF
}



resource "aws_instance" "public_ec2" {
  ami = "${var.ami_id}"
  instance_type = "${var.instance_type}"
  subnet_id = "${var.subnet_pub1a}"
  #count = var.instance_count
  security_groups = [var.security_group_id_public]
  associate_public_ip_address = var.enable_public_ip
  key_name      = "demo-ec2-public-keypair"  
  #tags = var.project_environment_prod
  tags = merge(var.project_environment_prod, {Name = "public_ec2"})
user_data = <<-EOF
                    #!/bin/bash

                    # Update system packages
                    sudo apt update -y

                    # Install Apache2
                    sudo apt install apache2 -y
                    sudo systemctl start apache2
                    sudo systemctl enable apache2
					
					cd /var/www/html/
					sudo rm -f index.html
					# Create a basic "index.html" file
					sudo touch index.html
               
					sudo echo "<html><head><title>Apache Test Page</title></head><body><h1>public_ec2 - It's working</h1></body></html>" | sudo tee /var/www/html/index.html


					# Create a test web page directory
					sudo mkdir -p /var/www/html/foo

					cd /var/www/html/foo

					# Create a basic "index.html" file
					sudo touch index.html
					sudo echo "<html><head><title>Apache Test Page Foo</title></head><body><h1>public_ec2/Foo - It's working</h1></body></html>" | sudo tee /var/www/html/foo/index.html



					# Create a test web page directory
					sudo mkdir -p /var/www/html/bar
					cd /var/www/html/bar				
					sudo touch index.html
					# Create a basic "index.html" file
					sudo echo "<html><head><title>Apache Test Page Bar</title></head><body><h1>public_ec2/Bar - It's working</h1></body></html>" | sudo tee /var/www/html/bar/index.html

					# Restart Apache service
					sudo systemctl restart apache2                     
					EOF
}
// "ec2_aws_subnet 2" "pre_exist_vpc"
resource "aws_instance" "private_ec1" {
  instance_type = "${var.instance_type}"
  ami = "${var.ami_id}"
  subnet_id = "${var.subnet_prv1a}"
  security_groups = [var.security_group_id_private]
  key_name      = "demo-ec2-private-keypair"  
  #count = var.instance_count
  #associate_public_ip_address = var.enable_public_ip
  #tags = var.project_environment_qa
  tags = merge(var.project_environment_qa, {Name = "private_ec1"})
user_data = <<-EOF
                    #!/bin/bash

                    # Update system packages
                    sudo apt update -y

                    # Install Apache2
                    sudo apt install apache2 -y
                    sudo systemctl start apache2
                    sudo systemctl enable apache2                    
					
					cd /var/www/html/
					sudo rm -f index.html
					# Create a basic "index.html" file
					sudo touch index.html
					sudo echo "<html><head><title>Apache Test Page</title></head><body><h1>private_ec1 - It's working</h1></body></html>" | sudo tee /var/www/html/index.html


					# Create a test web page directory
					sudo mkdir -p /var/www/html/foo

					cd /var/www/html/foo

					# Create a basic "index.html" file
					sudo touch index.html
					sudo echo "<html><head><title>Apache Test Page Foo</title></head><body><h1>private_ec1/Foo - It's working</h1></body></html>" | sudo tee /var/www/html/foo/index.html



					# Create a test web page directory
					sudo mkdir -p /var/www/html/bar
					cd /var/www/html/bar				
					sudo touch index.html
					# Create a basic "index.html" file
					sudo echo "<html><head><title>Apache Test Page Bar</title></head><body><h1>private_ec1/Bar - It's working</h1></body></html>" | sudo tee /var/www/html/bar/index.html

					# Restart Apache service
					sudo systemctl restart apache2                     
					EOF
}

