// Ami ID for free tier
variable "ami_id" {
  description = "TF-ami_id"
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 1
variable "subnet_pub1a" {
  description = "TF-public_subnet_1"
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 2
variable "subnet_prv1a" {
  description = "TF-private_subnet_1"
  default = "REDACTED_AWS_RESOURCE_ID"
}

// Exsisting Subnet 1
variable "subnet_pub1b" {
  description = "TF-public_subnet_2"
  default = "REDACTED_AWS_RESOURCE_ID"
}
// Exsisting Subnet 2
variable "subnet_prv1b" {
  description = "TF-prvate_subnet_2"
  default = "REDACTED_AWS_RESOURCE_ID"
}

// Exsisting instance_type
variable "instance_type" {
  description = "TF-instance_type"
  default = "t2.micro"
}
#variable "instance_type_dev" {}
#variable "instance_type_qa" {}
#variable "instance_type_prod" {}
// Tags for ec2
variable "tag" {
   type = string
   description = "The tag for the EC2 instance"
   default = "The tag for the EC2 instance"
}

variable "tag_names" {
  default = {
    environment = "Environment"
    application = "Application"
    team        = "Team"
    costcenter  = "CostCenter"
  }
}
// Exsisting vpc
variable "vpc_id" {
  description = "TF-exsisting_vpc"
  default = "REDACTED_AWS_RESOURCE_ID"
}

variable "instance_count" {
  description = "TF-ec2_instance_count"
  type        = number
  default     = 1
}  

variable "enable_public_ip" {
  description = "TF-enable_public_ip_address"
  type        = bool
  default     = true
}

variable "user_names" {
  description = "TF-iam_username"
  type        = list(string)
  default     = ["user1", "user2", "user3"]
}


variable "project_environment_dev" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "dev"
  }
}

variable "project_environment_qa" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "qa"
  }
}

variable "project_environment_prod" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default     = {
    project     = "project-alpha",
    environment = "prod"
  }
}

variable "security_group_id_public" {
  default = "REDACTED_AWS_RESOURCE_ID"
}
variable "security_group_id_private" {
  default = "REDACTED_AWS_RESOURCE_ID"
}

variable "project_id" {
  type        = string
  description = "TF-the_project_id"
  default = "Project-001"
}

variable "location" {
   description = "TF-region_for_project"
   default     = "us-east-1"
   type        = string
}

