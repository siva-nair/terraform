#############################################################
resource "aws_subnet" "public_subnet_staging" {
  for_each          = { for i, v in var.subnet_staging : i => v }
  vpc_id            = aws_vpc.staging.id
  cidr_block        = each.value.cid_pub
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "public_subnet_${each.key}" })
}

resource "aws_subnet" "private_subnet_staging" {
  for_each          = { for i, v in var.subnet_staging : i => v }
  vpc_id            = aws_vpc.staging.id
  cidr_block        = each.value.cid_pri
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "private_subnet_${each.key}" })
}

resource "aws_subnet" "public_subnet_staging1" {
  for_each          = { for i, v in var.subnet_staging1 : i => v }
  vpc_id            = aws_vpc.staging1.id
  cidr_block        = each.value.cid_pub
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "public_subnet_${each.key}" })
}

resource "aws_subnet" "private_subnet_staging1" {
  for_each          = { for i, v in var.subnet_staging1 : i => v }
  vpc_id            = aws_vpc.staging1.id
  cidr_block        = each.value.cid_pri
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "private_subnet_${each.key}" })
}
####################################################################


resource "aws_subnet" "public_subnet_staging2" {
  for_each          = { for i, v in var.subnet_staging2 : i => v }
  vpc_id            = aws_vpc.staging2.id
  cidr_block        = each.value.cid_pub
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "public_subnet_${each.key}" })
}

resource "aws_subnet" "private_subnet_staging2" {
  for_each          = { for i, v in var.subnet_staging2 : i => v }
  vpc_id            = aws_vpc.staging2.id
  cidr_block        = each.value.cid_pri
  availability_zone = each.value.az_zone

  tags = merge(var.project_environment_qa, { Name = "private_subnet_${each.key}" })
}
####################################################################
