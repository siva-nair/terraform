#output "ec2_public_ips" {  value = aws_instance.public_ec[*].private_ip}


#output "vpc_id" {  value = toset([ for v in aws_vpc.staging : v.id ])}
#output "pub_subnet" {  value = toset([ for v in aws_subnet.public_subnet : v.id ])}
#output "pri_subnet" {  value = toset([ for v in aws_subnet.private_subnet : v.id ])}
#output "gateway_id" {  value = toset([ for v in aws_internet_gateway.qa-igw : v.id ])}

output "public_subnet_staging" { value = values(aws_subnet.public_subnet_staging)[*].id }
output "public_subnet_staging1" { value = values(aws_subnet.public_subnet_staging1)[*].id }
output "public_subnet_staging2" { value = values(aws_subnet.public_subnet_staging2)[*].id }
output "private_subnet_staging" { value = values(aws_subnet.private_subnet_staging)[*].id }
output "private_subnet_staging1" { value = values(aws_subnet.private_subnet_staging1)[*].id }
output "private_subnet_staging2" { value = values(aws_subnet.private_subnet_staging2)[*].id }

output "vpc_ids-1" { value = aws_vpc.staging.id }
output "vpc_ids-2" { value = aws_vpc.staging1.id }
output "vpc_ids-3" { value = aws_vpc.staging2.id }

output "gateway_ids-1" { value = aws_internet_gateway.qa-igw.id }
output "gateway_ids-2" { value = aws_internet_gateway.qa-igw-1.id }
output "gateway_ids-3" { value = aws_internet_gateway.qa-igw-2.id }

