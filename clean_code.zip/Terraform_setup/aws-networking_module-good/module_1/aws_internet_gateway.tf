

resource "aws_internet_gateway" "qa-igw" {
  vpc_id = aws_vpc.staging.id

  tags = merge(var.project_environment_qa, { Name = "qa-igw" })
}

resource "aws_internet_gateway" "qa-igw-1" {
  vpc_id = aws_vpc.staging1.id

  tags = merge(var.project_environment_qa, { Name = "qa-igw-1" })
}


resource "aws_internet_gateway" "qa-igw-2" {
  vpc_id = aws_vpc.staging2.id

  tags = merge(var.project_environment_qa, { Name = "qa-igw-2" })
}
