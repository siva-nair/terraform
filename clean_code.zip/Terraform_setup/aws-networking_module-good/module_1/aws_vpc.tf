resource "aws_vpc" "staging" {
  cidr_block = "11.5.0.0/16"
    enable_dns_hostnames = true
  enable_dns_support   = true
  tags       = merge(var.project_environment_qa, { Name = "staging-1" })
  #cidr_block = "10.5.0.0/16"
}

resource "aws_vpc" "staging1" {
  cidr_block = "12.5.0.0/16"
    enable_dns_hostnames = true
  enable_dns_support   = true
  tags       = merge(var.project_environment_qa, { Name = "staging-2" })
  #cidr_block = "10.5.0.0/16"
}


resource "aws_vpc" "staging2" {
  cidr_block = "13.5.0.0/16"
    enable_dns_hostnames = true
  enable_dns_support   = true
  tags       = merge(var.project_environment_qa, { Name = "staging-3" })
  #cidr_block = "10.5.0.0/16"
}


