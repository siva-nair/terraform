#############################################################
resource "aws_route_table_association" "public_subnet_asso_staging" {
  for_each       = { for i, v in aws_subnet.public_subnet_staging : i => v }
  subnet_id      = aws_subnet.public_subnet_staging[each.key].id
  route_table_id = aws_route_table.tf_public_route_table_staging.id
}
resource "aws_route_table_association" "private_subnet_asso_staging" {
  for_each       = { for i, v in aws_subnet.private_subnet_staging : i => v }
  subnet_id      = aws_subnet.private_subnet_staging[each.key].id
  route_table_id = aws_route_table.tf_private_route_table_staging.id
}

#############################################################
resource "aws_route_table_association" "public_subnet_asso_staging1" {
  for_each       = { for i, v in aws_subnet.public_subnet_staging1 : i => v }
  subnet_id      = aws_subnet.public_subnet_staging1[each.key].id
  route_table_id = aws_route_table.tf_public_route_table_staging1.id
}
resource "aws_route_table_association" "private_subnetasso_staging1" {
  for_each       = { for i, v in aws_subnet.private_subnet_staging1 : i => v }
  subnet_id      = aws_subnet.private_subnet_staging1[each.key].id
  route_table_id = aws_route_table.tf_private_route_table_staging1.id
}


#############################################################
resource "aws_route_table_association" "private_subnet_asso_staging2" {
  for_each       = { for i, v in aws_subnet.private_subnet_staging2 : i => v }
  subnet_id      = aws_subnet.private_subnet_staging2[each.key].id
  route_table_id = aws_route_table.tf_private_route_table_staging2.id
}
resource "aws_route_table_association" "public_subnetasso_staging2" {
  for_each       = { for i, v in aws_subnet.public_subnet_staging2 : i => v }
  subnet_id      = aws_subnet.public_subnet_staging2[each.key].id
  route_table_id = aws_route_table.tf_public_route_table_staging2.id
}
