
resource "aws_route_table" "tf_public_route_table_staging" {
  vpc_id = aws_vpc.staging.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.qa-igw.id
  }

  tags = merge(var.project_environment_qa, { Name = "public_route_table-1" })

}

resource "aws_route_table" "tf_public_route_table_staging1" {
  vpc_id = aws_vpc.staging1.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.qa-igw-1.id
  }

  tags = merge(var.project_environment_qa, { Name = "public_route_table-2" })

}

resource "aws_route_table" "tf_public_route_table_staging2" {
  vpc_id = aws_vpc.staging2.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.qa-igw-2.id
  }

  tags = merge(var.project_environment_qa, { Name = "public_route_table-3" })

}
###################################################################################
resource "aws_route_table" "tf_private_route_table_staging" {
  vpc_id = aws_vpc.staging.id
  tags   = merge(var.project_environment_qa, { Name = "private_route_table-1" })

}


resource "aws_route_table" "tf_private_route_table_staging1" {
  vpc_id = aws_vpc.staging1.id
  tags   = merge(var.project_environment_qa, { Name = "private_route_table-2" })

}


resource "aws_route_table" "tf_private_route_table_staging2" {
  vpc_id = aws_vpc.staging2.id
  tags   = merge(var.project_environment_qa, { Name = "private_route_table-3" })

}