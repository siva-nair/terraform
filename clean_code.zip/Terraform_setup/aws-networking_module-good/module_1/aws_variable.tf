

variable "enable_public_ip" {
  description = "Enable public IP address"
  type        = bool
  default     = true
}
variable "user_names" {
  description = "IAM usernames"
  type        = list(string)
  default     = ["user1", "user2", "user3s"]
}

variable "project_environment" {
  description = "project name and environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "dev"
  }
}


variable "project_environment_dev" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "dev"
  }
}

variable "project_environment_qa" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "qa"
  }
}

variable "project_environment_prod" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "prod"
  }
}


variable "subnet_staging" {
  description = "VPC Network Map"
  type = map(object({
    cidr    = string
    cid_pri = string
    cid_pub = string
    az_zone = string
  }))
  default = {
    "0" = {
      cidr    = "11.5.0.0/16"
      cid_pri = "11.5.2.0/24"
      cid_pub = "11.5.1.0/24"
      az_zone = "us-east-1a"
    },
    "1" = {
      cidr    = "11.5.0.0/16"
      cid_pri = "11.5.3.0/24"
      cid_pub = "11.5.4.0/24"
      az_zone = "us-east-1b"
    }
  }
}


variable "subnet_staging1" {
  description = "VPC Network Map"
  type = map(object({
    cidr    = string
    cid_pri = string
    cid_pub = string
    az_zone = string
  }))
  default = {
    "0" = {
      cidr    = "12.5.0.0/16"
      cid_pri = "12.5.2.0/24"
      cid_pub = "12.5.1.0/24"
      az_zone = "us-east-1c"
    },
    "1" = {
      cidr    = "12.5.0.0/16"
      cid_pri = "12.5.3.0/24"
      cid_pub = "12.5.4.0/24"
      az_zone = "us-east-1d"
    }
  }
}


variable "subnet_staging2" {
  description = "VPC Network Map"
  type = map(object({
    cidr    = string
    cid_pri = string
    cid_pub = string
    az_zone = string
  }))
  default = {
    "0" = {
      cidr    = "13.5.0.0/16"
      cid_pri = "13.5.2.0/24"
      cid_pub = "13.5.1.0/24"
      az_zone = "us-east-1e"
    },
    "1" = {
      cidr    = "13.5.0.0/16"
      cid_pri = "13.5.3.0/24"
      cid_pub = "13.5.4.0/24"
      az_zone = "us-east-1f"
    }
  }
}

variable "instance_type" {
  description = "Instance type t2.micro"
  type        = string
  default     = "t2.micro"
}

// Ami ID for free tier
variable "ami_id" {
  description = "TF-ami_id"
  type        = string
  default     = "REDACTED_AWS_RESOURCE_ID"
}

// Ami ID for free tier
variable "ec2_instace_name" {
  type        = string
  description = "TF-ami_id"
  default     = "ami-name"
}
variable "instance_count" {
  description = "EC2 instance count"
  type        = number
  default     = 2
}

variable "public_subnet_staging" {
  description = "assign public subnet"
  type        = any
  default     = []
}

variable "public_subnet_staging1" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "public_subnet_staging2" {
  description = "assign public subnet"
  type        = any
  default     = []
}

variable "private_subnet_staging" {
  description = "assign public subnet"
  type        = any
  default     = []
}

variable "private_subnet_staging1" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "private_subnet_staging2" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "vpc_ids-1" {
  description = "assign private subnet"
  type        = any
  default     = []
}

variable "vpc_ids-2" {
  description = "assign private subnet"
  type        = any
  default     = []
}

variable "vpc_ids-3" {
  description = "assign private subnet"
  type        = any
  default     = []
}
variable "gateway_ids-1" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "gateway_ids-2" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "gateway_ids-3" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "pri_subnet" {
  description = "assign private subnet"
  type        = any
  default     = []
}