	#3. Terraform Configuration Examples:
	#transit gateway.

	    resource "aws_ec2_transit_gateway" "example" {
	description = "Example Transit Gateway"
	tags = {
	Name = "example-tgw"
	}
	}

	#Direct Connect Gateway.

	    resource "aws_dx_gateway" "example" {
	name = "example-dx-gateway"
	tags = {
	Name = "example-dx-gateway"
	}
	}
	#Direct Connect Gateway Association.
	
	resource "aws_dx_gateway_association" "example" {
	dx_gateway_id = aws_dx_gateway.example.id
	associated_gateway_id = aws_ec2_transit_gateway.example.id
	associated_gateway_type = "transitGateway"
	}
	#transit virtual interface.
	
	resource "aws_dx_transit_virtual_interface" "example" {
	address_family = "ipv4"
	bgp_asn = 65432
	connection_id = "dxcon-0123456789abcdef" # Replace with your connection ID
	dx_gateway_id = aws_dx_gateway.example.id
	name = "example-transit-vi"
	vlan = 100
	amazon_address = "10.0.0.1/32"
	customer_address = "10.0.0.2/32"
	}
