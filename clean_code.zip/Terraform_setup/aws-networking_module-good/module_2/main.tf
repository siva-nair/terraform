provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}


module "modlue_1_output" {
  source  = "../module_1"
  
  public_subnet_staging   = module.modlue_1_output.public_subnet_staging
  public_subnet_staging1  = module.modlue_1_output.public_subnet_staging1
  public_subnet_staging2  = module.modlue_1_output.public_subnet_staging2
  private_subnet_staging  = module.modlue_1_output.private_subnet_staging
  private_subnet_staging1 = module.modlue_1_output.private_subnet_staging1
  private_subnet_staging2 = module.modlue_1_output.private_subnet_staging2

  vpc_ids-1 = module.modlue_1_output.vpc_ids-1
  vpc_ids-2 = module.modlue_1_output.vpc_ids-2
  vpc_ids-3 = module.modlue_1_output.vpc_ids-3


  gateway_ids-1 = module.modlue_1_output.gateway_ids-1
  gateway_ids-2 = module.modlue_1_output.gateway_ids-2
  gateway_ids-3 = module.modlue_1_output.gateway_ids-3
}


resource "aws_instance" "public_ec2_staging" {
  for_each                    = { for i, v in module.modlue_1_output.public_subnet_staging : i => v }
  ami                         = var.ami_id
  instance_type               = var.instance_type
  subnet_id                   = each.value
  associate_public_ip_address = var.enable_public_ip
  key_name                    = "demo-ec2-public-keypair"
  tags                        = merge(var.project_environment_qa, { Name = "public_ec2_staging_${each.key}" })
  #user_data     = file("../script-for-ec1s-01.sh")
  #user_data = file("./script-for-ec1s-0${each.key+1}.sh")

}


resource "aws_instance" "private_ec2_staging" {
  for_each      = { for i, v in module.modlue_1_output.private_subnet_staging : i => v }
  ami           = var.ami_id
  instance_type = var.instance_type
  subnet_id     = each.value
  key_name      = "demo-ec2-private-keypair"
  tags          = merge(var.project_environment_qa, { Name = "public_ec2_staging-${each.key}" })
  #user_data     = file("../script-for-ec2s-01.sh")
  #user_data = file("./script-for-ec2s-0${each.key+1}.sh")

}


resource "aws_instance" "public_ec2_staging1" {
  for_each                    = { for i, v in module.modlue_1_output.public_subnet_staging1 : i => v }
  ami                         = var.ami_id
  instance_type               = var.instance_type
  subnet_id                   = each.value
  associate_public_ip_address = var.enable_public_ip
  key_name                    = "demo-ec2-public-keypair"
  tags                        = merge(var.project_environment_qa, { Name = "public_ec2_staging1_${each.key}" })
  #user_data     = file("../script-for-ec1s-01.sh")
  #user_data = file("./script-for-ec1s-0${each.key+1}.sh")

}


resource "aws_instance" "private_ec2_staging1" {
  for_each      = { for i, v in module.modlue_1_output.private_subnet_staging1 : i => v }
  ami           = var.ami_id
  instance_type = var.instance_type
  subnet_id     = each.value
  key_name      = "demo-ec2-private-keypair"
  tags          = merge(var.project_environment_qa, { Name = "public_ec2_staging1-${each.key}" })
  #user_data     = file("../script-for-ec2s-01.sh")
  #user_data = file("./script-for-ec2s-0${each.key+1}.sh")

}



resource "aws_instance" "public_ec2_staging2" {
  for_each                    = { for i, v in module.modlue_1_output.public_subnet_staging2 : i => v }
  ami                         = var.ami_id
  instance_type               = var.instance_type
  subnet_id                   = each.value
  associate_public_ip_address = var.enable_public_ip
  key_name                    = "demo-ec2-public-keypair"
  tags                        = merge(var.project_environment_qa, { Name = "public_ec2_staging2_${each.key}" })
  #user_data     = file("../script-for-ec1s-01.sh")
  #user_data = file("./script-for-ec1s-0${each.key+1}.sh")

}


resource "aws_instance" "private_ec2_staging2" {
  for_each      = { for i, v in module.modlue_1_output.private_subnet_staging2 : i => v }
  ami           = var.ami_id
  instance_type = var.instance_type
  subnet_id     = each.value
  key_name      = "demo-ec2-private-keypair"
  tags          = merge(var.project_environment_qa, { Name = "public_ec2_staging2-${each.key}" })
  #user_data     = file("../script-for-ec2s-01.sh")
  #user_data = file("./script-for-ec2s-0${each.key+1}.sh")

}
