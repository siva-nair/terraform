# Set the output (this output will be used as a reference as input later from another module)
