provider "aws" {
  region     = var.aws_cred[0]
  access_key = REDACTED_SECRET]
  secret_key = REDACTED_SECRET]
}

#module "loadbalance" {source = "./load-balance"}