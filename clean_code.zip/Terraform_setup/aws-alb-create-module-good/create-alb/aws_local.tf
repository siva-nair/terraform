
locals {
  target_app_arn = {
    "tg1" = ["10.0.0.1", "10.0.0.2"]
    "tg2" = ["10.0.1.1", "10.0.1.2", "10.0.1.3"]
  }
}

locals {
    target_web_arn = {
    "tg3" = ["11.0.0.1", "11.0.0.2"]
    "tg4" = ["11.0.1.1", "11.0.1.2", "11.0.1.3"]
  }
}

locals {
 association-list-app1 =  flatten([
    for targetgroup, instamsids in local.target_web_arn : [
      for instamsid in instamsids : {
        "${targetgroup}-${instamsid}" = {
          "instamsid" = instamsid
          "targetgroup" = targetgroup
          }
      }
    ]
 ])

  association-list-web1 = flatten([
      for targetgroup, instamsids in local.target_web_arn : [
        for instamsid in instamsids : {
          "${targetgroup}-${instamsid}" = {
            "instamsid" = instamsid
            "targetgroup" = targetgroup
            }
        }
      ]
  ])

 association-map-web1 = { for item in local.association-list-web1: 
     keys(item)[0] => values(item)[0]
   }
 association-map-app1 = { for item in local.association-list-app1: 
     keys(item)[0] => values(item)[0]
   }
  
  }
locals {
  target_groups_web = [
    for name, ips in local.target_web_arn : {
      name = name
      ips  = ips
    }
  ]
    target_groups_app = [
    for name, ips in local.target_app_arn : {
      name = name
      ips  = ips
    }
  ]
}

