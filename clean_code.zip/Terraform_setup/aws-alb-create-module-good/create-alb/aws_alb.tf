
###############################################################################
// ALB - "public_alb"
###############################################################################

resource "aws_lb" "public_alb" {
  for_each           = { for idx, tg in local.target_groups_web : idx => tg }
  name               = "${each.value.name}" // change name to the public ideawaves-ca
  internal           = true
  load_balancer_type = "application"
  security_groups    = [module.create-network.pubsec_group.id]
  subnets            = [for subnet in module.create-network.pub_subnet : subnet]

  tags = merge(var.project_environment_qa, { Name = "alb-web-${each.value.name}" })

}

resource "aws_lb" "private_alb" {
  for_each           = { for idx, tg in local.target_groups_app : idx => tg }
  name               = "${each.value.name}" // change name to the public ideawaves-ca
  internal           = true
  load_balancer_type = "application"
  security_groups    = [module.create-network.prisec_group.id]
  subnets            = [for subnet in module.create-network.pri_subnet : subnet]
  tags               = merge(var.project_environment_qa, { Name = "alb-app-${each.value.name}" })

}


