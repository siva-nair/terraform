/**
provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}
**/

#module "loadbalance" {source = "./load-balance"}

/**

module "create-network" {
  source = "../create-network"

  #pub_subnet   = module.global_output.pub_subnet
  #pri_subnet   = module.global_output.pri_subnet
  vpc_ids      = module.create-network.vpc_ids
  #gateway_ids  = module.global_output.gateway_ids
  #pubsec_group = module.global_output.pubsec_group
  #prisec_group = module.global_output.prisec_group
  pri_instance = module.create-network.pri_instance
  pub_instance = module.create-network.pub_instance
}

module "create-network" {
  source = "../create-network"
} 
**/