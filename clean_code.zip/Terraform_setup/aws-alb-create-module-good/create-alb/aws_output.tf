/**
output "target_groups_app" {   value = values(aws_lb_target_group.target_groups_app)[*].arn}
output "target_groups_web" {   value = values(aws_lb_target_group.target_groups_web)[*].arn}

output "aws_lb_web" {   value = values(aws_lb.public_alb)[*].arn}
output "aws_lb_app" {   value = values(aws_lb.private_alb)[*].arn}

output "vpc_ids" {   value = module.create-network.vpc_ids}

output "local_target_groups_web" {   value = local.target_groups_web}
output "local_target_groups_app" {   value = local.target_groups_app}


output "pub_instance" {   value = module.create-network.pub_instance[*]}
output "pri_instance" {   value = module.create-network.pri_instance[*]}

**/