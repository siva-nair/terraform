

resource "aws_lb_listener" "alb_listener_web" {
  for_each          = aws_lb_target_group.target_groups_web
  load_balancer_arn = aws_lb.public_alb[each.key].arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "public_alb_listener-${each.key}" })
}

resource "aws_lb_listener" "alb_listener_app" {
  for_each          = aws_lb_target_group.target_groups_app
  load_balancer_arn = aws_lb.private_alb[each.key].arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "private_alb_listener-${each.key}" })
}
