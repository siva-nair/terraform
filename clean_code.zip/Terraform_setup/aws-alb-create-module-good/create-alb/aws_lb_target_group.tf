

resource "aws_lb_target_group" "target_groups_web" {
  for_each    = { for idx, tg in local.target_groups_web : idx => tg }
  name        = each.value.name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = module.create-network.vpc_ids
}

#output "target_groups_web" {   value = values(aws_lb_target_group.target_groups_web)[*].id}

resource "aws_lb_target_group" "target_groups_app" {
  for_each    = { for idx, tg in local.target_groups_app : idx => tg }
  name        = each.value.name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = module.create-network.vpc_ids
}

