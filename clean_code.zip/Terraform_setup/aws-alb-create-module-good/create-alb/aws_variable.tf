variable "instance_type" {
  description = "Instance type t2.micro"
  type        = string
  default     = "t2.micro"
}

variable "isubnet_private" {
  description = "Instance type t2.micro"
  type        = string
  default     = "aws_subnet.private_subnet[*].id"
}

variable "isubnet_public" {
  description = "Instance type t2.micro"
  type        = string
  default     = "aws_subnet.public_subnet[*].id"
}
variable "instance_count" {
  description = "EC2 instance count"
  type        = number
  default     = 2
}
variable "enable_public_ip" {
  description = "Enable public IP address"
  type        = bool
  default     = true
}
variable "user_names" {
  description = "IAM usernames"
  type        = list(string)
  default     = ["user1", "user2", "user3s"]
}

variable "project_environment" {
  description = "project name and environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "dev"
  }
}

// Ami ID for free tier
variable "ami_id" {
  description = "TF-ami_id"
  default     = "REDACTED_AWS_RESOURCE_ID"
}

variable "project_environment_dev" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "dev"
  }
}

variable "project_environment_qa" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "qa"
  }
}

variable "project_environment_prod" {
  description = "TF-project_name_and_environment"
  type        = map(string)
  default = {
    project     = "project-alpha",
    environment = "prod"
  }
}


variable "subnet_cidrs_public" {
  description = "Subnet CIDRs for public subnets (length must match configured availability_zones)"
  # this could be further simplified / computed using cidrsubnet() etc.
  # https://www.terraform.io/docs/configuration/interpolation.html#cidrsubnet-iprange-newbits-netnum-
  default = ["10.5.1.0/24", "10.5.2.0/24"]
  type    = list(string)
}

variable "subnet_cidrs_private" {
  description = "Subnet CIDRs for pprivate subnets (length must match configured availability_zones)"
  # this could be further simplified / computed using cidrsubnet() etc.
  # https://www.terraform.io/docs/configuration/interpolation.html#cidrsubnet-iprange-newbits-netnum-
  default = ["10.5.5.0/24", "10.5.6.0/24"]
  type    = list(string)
}

variable "availability_zones" {
  type        = list(string)
  description = "List of Availability Zones (e.g. `['us-east-1a', 'us-east-1b', 'us-east-1c']`)"
  default     = ["us-east-1a", "us-east-1b"]
  #default = ["us-east-1a", "us-east-1b","us-east-1c", "us-east-1d"]
}


variable "aws_cred" {
  type        = list(string)
  description = "Provider availability zones (e.g. `['us-east-1a', 'us-east-1b', 'us-east-1c']`)"
  default     = ["us-east-1", "REDACTED_AWS_ACCESS_KEY_ID", "rTlM1Y1Cd8pRziVqXwAj4O/JlKSOKILWipMxr2sP"]
  #default = ["us-east-1a", "us-east-1b","us-east-1c", "us-east-1d"]
}

variable "pub_subnet" {
  description = "assign public subnet"
  type        = any
  default     = []
}

variable "vpc_ids" {
  description = "assign private subnet"
  type        = any
  default     = []
}

variable "gateway_ids" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "pri_subnet" {
  description = "assign private subnet"
  type        = any
  default     = []
}


variable "prisec_group" {
  description = "assign public subnet"
  type        = any
  default     = []
}
variable "pubsec_group" {
  description = "assign private subnet"
  type        = any
  default     = []
}


variable "pri_instance" {
  description = "assign public instance"
  type        = any
  default     = []
}
variable "pub_instance" {
  description = "assign private instance"
  type        = any
  default     = []
}
