// https://jhooq.com/terraform-guide-alb-ssl/
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0" # Change this from 5.0
    }
  }
}
/**

module "create-alb" {
  source = "./create-alb"
  #source = "../create-alb" 
  vpc_ids      = module.create-network.vpc_ids
  pri_instance = module.create-network.pri_instance
  pub_instance = module.create-network.pub_instance


}


module "craete-attachment" {
source = "./craete-attachment"
  #source = "../create-network"  
}


**/


module "create-alb" {
  source = "./create-alb"
  #source = "../create-alb" 
  vpc_ids      = module.create-network.vpc_ids
  pri_instance = module.create-network.pri_instance
  pub_instance = module.create-network.pub_instance
  pubsec_group = module.create-network.pubsec_group
  prisec_group = module.create-network.prisec_group
  pub_subnet = module.create-network.pub_subnet
  pri_subnet = module.create-network.pri_subnet

}




module "create-network" {
source = "./create-network"
}

output "vpc_ids" { value = module.create-network.vpc_ids }
output "pri_instance" { value = module.create-network.pri_instance[*] }
output "pub_instance" { value = module.create-network.pub_instance[*] }
output "pubsec_group" { value = module.create-network.pubsec_group }
output "prisec_group" { value = module.create-network.prisec_group}
output "pub_subnet" { value = module.create-network.pub_subnet }
output "pri_subnet" { value = module.create-network.pri_subnet}

variable "db_password" {
  description = "The password for the database"
  type        = string
  sensitive   = true  # Recommended for passwords so they don't show in logs
}
