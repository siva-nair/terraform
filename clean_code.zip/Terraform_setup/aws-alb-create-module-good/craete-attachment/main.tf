/**
provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}
**/
#module "loadbalance" {source = "./load-balance"}
provider "aws" {
  region     = var.aws_cred[0]
  access_key = REDACTED_SECRET]
  secret_key = REDACTED_SECRET]
}

/**
module "create_alb_output" {
  #source = "../create-network"  
  source = "../create-alb"
}
**/