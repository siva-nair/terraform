

#output "target_groups_app_arn" { value = module.create_alb_output.target_groups_app[*] }
#output "target_groups_web_arn" { value = module.create_alb_output.target_groups_web[*] }

#output "aws_lb_app1" { value = module.create_alb_output.aws_lb_app[*] }
#output "aws_lb_web1" { value = module.create_alb_output.aws_lb_web[*] }

#output "vpc_ids1" { value = module.create_alb_output.vpc_ids }

#output "local_target_groups_web1" { value = module.create_alb_output.local_target_groups_web[*] }
#output "local_target_groups_app1" { value = module.create_alb_output.local_target_groups_app[*] }

#output "local_web_instance" { value = module.create_alb_output.pub_instance }
#output "local_app_instance" { value = module.create_alb_output.pri_instance }


#output "target_groups_app2" { value = local.target_groups_web[*] }
#output "target_groups_web2" { value = local.target_groups_app[*] }


