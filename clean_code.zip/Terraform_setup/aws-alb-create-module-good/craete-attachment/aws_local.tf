
locals {
  target_app_arn = {
    "REDACTED_AWS_ARN" = ["10.5.5.172", "10.5.6.47"]
    "REDACTED_AWS_ARN" = ["10.5.5.172", "10.5.6.47"]
  }
}

locals {
  target_web_arn = {
    "REDACTED_AWS_ARN" = ["10.5.1.241", "10.5.2.80"]
    "REDACTED_AWS_ARN" = ["10.5.1.241", "10.5.2.80"]
  }
}

locals {
  association-list-app = flatten([
    for targetgroup, instamsids in local.target_web_arn : [
      for instamsid in instamsids : {
        "${targetgroup}-${instamsid}" = {
          "instamsid"   = instamsid
          "targetgroup" = targetgroup
        }
      }
    ]
  ])

  association-list-web = flatten([
    for targetgroup, instamsids in local.target_web_arn : [
      for instamsid in instamsids : {
        "${targetgroup}-${instamsid}" = {
          "instamsid"   = instamsid
          "targetgroup" = targetgroup
        }
      }
    ]
  ])

  association-map-web = { for item in local.association-list-web :
    keys(item)[0] => values(item)[0]
  }
  association-map-app = { for item in local.association-list-app :
    keys(item)[0] => values(item)[0]
  }

}

locals {
  target_groups_web = [
    for name, ips in local.target_web_arn : {
      name = name
      ips  = ips
    }
  ]
  target_groups_app = [
    for name, ips in local.target_app_arn : {
      name = name
      ips  = ips
    }
  ]
}

