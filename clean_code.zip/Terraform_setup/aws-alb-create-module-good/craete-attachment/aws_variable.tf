variable "aws_cred" {
  type        = list(string)
  description = "Provider availability zones (e.g. `['us-east-1a', 'us-east-1b', 'us-east-1c']`)"
  default     = ["us-east-1", "REDACTED_AWS_ACCESS_KEY_ID", "rTlM1Y1Cd8pRziVqXwAj4O/JlKSOKILWipMxr2sP"]
  #default = ["us-east-1a", "us-east-1b","us-east-1c", "us-east-1d"]
}