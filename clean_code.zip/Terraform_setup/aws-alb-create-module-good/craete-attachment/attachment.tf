
/**
resource "aws_lb_target_group_attachment" "tgr_attachment-web" {
for_each = local.association-map-web

  target_group_arn = each.value.targetgroup
  target_id        = each.value.instamsid
  #port             = each.value.target_group.target_port
}

resource "aws_lb_target_group_attachment" "tgr_attachment-app" {
for_each = local.association-map-app

  target_group_arn = each.value.targetgroup
  target_id        = each.value.instamsid
  #port             = each.value.target_group.target_port
}


**/
