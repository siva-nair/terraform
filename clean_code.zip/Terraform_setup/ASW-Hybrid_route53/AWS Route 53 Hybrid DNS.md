<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLKblTWkKbMhWv6OqjC9OJOrLPSzIoLu_PwQ&s" style="height:64px;margin-right:32px"/>

# provide information below:

1. How to delegate a subdomain from on‑prem to Route 53 Resolver
2. Configure Route 53 Resolver inbound and outbound endpoints step by step
3. Best practices for Route 53 Profiles in multi-account setups
4. Automate Resolver rules and private hosted zones with Terraform
5. Design a hub‑and‑spoke DNS architecture for hybrid networks

Now I'll create a comprehensive professional report addressing all five requested topics:

## AWS Route 53 Hybrid DNS: Comprehensive Implementation Guide


***

### Executive Summary

Amazon Route 53 Resolver provides a managed, scalable DNS infrastructure for hybrid cloud environments, enabling seamless DNS resolution between AWS VPCs and on-premises networks. This guide synthesizes authoritative AWS documentation, recent feature releases (including the June 2025 DNS delegation capability), and production architecture patterns to deliver actionable guidance on subdomain delegation, endpoint configuration, multi-account governance, infrastructure-as-code automation, and hub-and-spoke topology design. Organizations implementing these patterns can eliminate self-managed DNS infrastructure, reduce operational overhead, and achieve unified namespace management across hybrid environments while maintaining security and high availability.

***

## 1. Subdomain Delegation from On-Premises to Route 53 Resolver

The June 2025 Route 53 Resolver feature release introduced DNS delegation support, fundamentally simplifying hybrid DNS management by eliminating the need for self-managed DNS infrastructure.[^1]

### Delegation Architecture

Subdomain delegation enables authoritative DNS responsibility transfer from on-premises parent domain to AWS-hosted subdomains via **inbound delegation endpoints**. This pattern allows, for example, an on-premises team maintaining `example.com` to delegate `aws.example.com` authority to Route 53, while a regional on-premises team can delegate `berlin.example.com` back to Route 53 from a parent zone hosted on Route 53.

### Step-by-Step Implementation

**Phase 1: AWS Infrastructure Setup**

1. **Create Private Hosted Zone**
Create a Route 53 private hosted zone for the delegated subdomain (e.g., `aws.healthtech.example.com`) in the VPC where your AWS workloads run. Associate this zone with the target VPC(s).
2. **Create Resource Records**
Populate the private hosted zone with A, AAAA, CNAME, or other records for your AWS resources (e.g., `app1.aws.healthtech.example.com` pointing to an ALB or EC2 instance IP).
3. **Create Inbound Delegation Endpoint**
In Route 53 Resolver, create an **inbound delegation endpoint** within the VPC. This endpoint is distinct from standard inbound endpoints—it is optimized for delegation queries. Allocate at least two Elastic Network Interfaces (ENIs) across different Availability Zones for redundancy. Document the endpoint IP addresses (AWS will assign or allow you to specify static IPs).

**Phase 2: On-Premises DNS Configuration**

4. **Add NS Glue Records**
On your on-premises authoritative DNS server (e.g., BIND, Microsoft Active Directory DNS), create **NS (Name Server) records** for the subdomain pointing to the inbound delegation endpoint IP addresses. For example:[^2]

```
aws.example.com  IN  NS  10.0.1.100
aws.example.com  IN  NS  10.0.1.101
```

These IPs are the private addresses of your inbound delegation endpoint ENIs (no public IPs needed). Ensure your on-premises DNS resolver has network connectivity to these IPs over AWS Direct Connect or Site-to-Site VPN.
5. **Verify Connectivity**
Test DNS query propagation: from an on-premises client, run `dig app1.aws.healthtech.example.com @<on-prem-dns-ip>`. The on-premises resolver should forward the query to the inbound endpoint, which responds with the private hosted zone record.

### Query Resolution Flow

When an on-premises client queries `app1.aws.healthtech.example.com`:

- The on-premises recursive resolver performs a standard iterative query (no special forwarding rules needed).
- It discovers the NS glue records pointing to the inbound delegation endpoint.
- The query is sent to the inbound endpoint IP over the VPN/Direct Connect connection.
- The inbound endpoint forwards the query to VPC Resolver (at VPC+2 address), which resolves the record from the private hosted zone.
- The response is returned through the delegation chain back to the client.[^3][^2]


### Best Practices for Delegation

- **Namespace clarity**: Use distinct subdomains (e.g., `aws.example.com`, `cloud.example.com`) to avoid confusion with on-premises zones and simplify troubleshooting.
- **Multi-AZ IP allocation**: Always provision inbound delegation endpoint IPs in at least two AZs to maintain HA during zone failures.
- **Static IP assignment**: If possible, assign static private IPs to the delegation endpoint rather than auto-assignment, as this simplifies on-premises DNS configuration and reduces risk of misconfiguration during endpoint recreation.
- **Avoid split-horizon conflicts**: Do not host the same domain name with different records in both Route 53 and on-premises DNS, as this creates client confusion and breaks application functionality.

***

## 2. Configure Route 53 Resolver Inbound and Outbound Endpoints: Step-by-Step

Resolver endpoints are Elastic Network Interfaces that sit in your VPC and mediate DNS traffic between AWS and external networks.

### Overview of Endpoint Types

| Endpoint Type | Direction | Purpose | Use Case |
| :-- | :-- | :-- | :-- |
| **Inbound** | On-prem → AWS | Accepts DNS queries from on-premises resolvers; forwards to VPC Resolver | On-prem clients querying Route 53 private hosted zones |
| **Inbound Delegation** | On-prem → AWS | Delegates subdomain authority from on-prem to Route 53 via NS records (new 2025) | Hierarchical zone management; avoids conditional forwarding overhead |
| **Outbound** | AWS → On-prem | Originates DNS queries from VPC; forwards to on-premises resolvers via forwarding rules | AWS clients querying on-prem AD, LDAP, internal services |
| **System** | Automatic | Default recursive resolver; handles public DNS and fallback resolution | All VPCs (no configuration needed) |

### Inbound Endpoint Configuration

**Prerequisites:**

- VPC with at least two private subnets in different AZs.
- Security group permitting inbound TCP/UDP on port 53 from on-premises CIDR blocks.
- Network connectivity (VPN or Direct Connect) from on-premises to VPC.
- DNS hostnames and DNS support enabled on the VPC.

**Step 1: Create Security Group**

Create a security group within the VPC with the following inbound rule:

```
Protocol: TCP, UDP
Port: 53
Source: <on-premises-network-cidr> (e.g., 192.168.0.0/16)
```

**Step 2: Navigate to Route 53 Resolver Endpoints**

In the AWS Management Console:

1. Go to **Route 53** → **Resolver** (left navigation pane).
2. Choose **Endpoints** → **Create inbound endpoint**.

**Step 3: Configure Endpoint Details**


| Field | Value | Notes |
| :-- | :-- | :-- |
| **Name** | e.g., `prod-inbound-endpoint` | Descriptive identifier for logs and management |
| **VPC** | Select your hub or shared-services VPC | Inbound endpoint must be in a VPC associated with the private hosted zones it serves |
| **Security Group** | Select the group created in Step 1 | Must allow inbound TCP/UDP 53 |

**Step 4: Allocate IP Addresses**

For each AZ (minimum 2, recommended 3):


| Field | Value | Notes |
| :-- | :-- | :-- |
| **Availability Zone** | e.g., `us-east-1a` | Distribute across different AZs |
| **Subnet** | Select a private subnet in the AZ | Must be in the same VPC |
| **IP Address** | Manually specify (e.g., `10.0.1.100`) OR auto-assign | Static IPs recommended for on-prem DNS configuration stability |

Example configuration:

```
AZ: us-east-1a, Subnet: REDACTED_AWS_RESOURCE_ID, IP: 10.0.1.100
AZ: us-east-1b, Subnet: REDACTED_AWS_RESOURCE_ID, IP: 10.0.2.100
AZ: us-east-1c, Subnet: subnet-0ghi9012, IP: 10.0.3.100
```

**Step 5: Tags and Create**

Add environment, cost-center, and owner tags. Click **Create inbound endpoint**. AWS will provision the ENIs (status transitions from "Creating" → "Operational" in ~2–3 minutes).

### Outbound Endpoint Configuration

**Prerequisites:**

- VPC with at least two private subnets in different AZs.
- Security group permitting outbound TCP/UDP on port 53 to on-premises DNS server IPs.
- On-premises DNS server IPs and network connectivity.
- VPCs that need to resolve on-premises domains.

**Step 1: Create Security Group**

Create a security group with outbound rules:

```
Protocol: TCP, UDP
Port: 53
Destination: <on-premises-dns-server-ips> (e.g., 192.168.1.10/32, 192.168.1.11/32)
```

**Step 2: Create Outbound Endpoint**

1. Go to **Route 53** → **Resolver** → **Endpoints** → **Create outbound endpoint**.

**Step 3: Configure Endpoint Details**


| Field | Value |
| :-- | :-- |
| **Name** | e.g., `prod-outbound-endpoint` |
| **VPC** | Select the VPC containing workloads |
| **Security Group** | Select the group with outbound rules |

**Step 4: Allocate IP Addresses**

For outbound endpoints, AWS automatically selects IPs from the specified subnets (you cannot pre-specify IPs for outbound, but can optionally tag them). Allocate in at least two AZs:

```
AZ: us-east-1a, Subnet: REDACTED_AWS_RESOURCE_ID
AZ: us-east-1b, Subnet: REDACTED_AWS_RESOURCE_ID
```

**Step 5: Create and Verify**

Click **Create outbound endpoint**. Once operational, note the endpoint ID (used in Resolver rules, next step).

### Resolver Rule Configuration (Forwarding)

After endpoints are operational, create **Resolver rules** to forward queries.

**For Outbound Forwarding (AWS → On-Prem):**

1. Go to **Route 53** → **Resolver** → **Rules** → **Create rule**.
2. Configure:


| Field | Value | Example |
| :-- | :-- | :-- |
| **Rule Name** | Descriptive name | `forward-corp-domain` |
| **Rule Type** | Forwarding rule | (select this option) |
| **Domain Name** | Domain to forward | `corp.example.com.` (note trailing dot) |
| **Outbound Endpoint** | Select endpoint from Step 4 | `prod-outbound-endpoint` |
| **Target IP Addresses** | On-prem DNS server IPs | `192.168.1.10`, `192.168.1.11` |

3. **Associate with VPCs**: Select all VPCs that should forward queries for this domain (e.g., all workload VPCs).
4. Click **Create rule**.

**For Inbound Acceptance (On-Prem → AWS):**

Inbound endpoints do not require explicit Resolver rules—they automatically accept queries and forward to VPC Resolver. However, you may optionally create **delegation rules** (new in 2025) to handle delegated subdomains.

### Testing Connectivity

**From an on-premises DNS server:**

```bash
# Test query for Route 53 private hosted zone record
nslookup app1.aws.example.com 10.0.1.100

# Using dig for more detail
dig app1.aws.example.com @10.0.1.100 +short
```

**From an AWS EC2 instance (to on-premises):**

```bash
# Test query forwarded to on-prem DNS
nslookup internal-service.corp.example.com

# Using dig
dig internal-service.corp.example.com +short
```

Both should return the expected IP addresses. If queries fail, verify security group rules, network routing, and DNS server configuration on both ends.

***

## 3. Best Practices for Route 53 Profiles in Multi-Account Setups

Route 53 Profiles (released April 2024) centralize DNS governance across multiple AWS accounts and VPCs, addressing the operational burden of managing disparate DNS configurations at scale.[^4][^5]

### Profile Architecture and Governance Model

A Route 53 Profile is a **logical container** that groups:

- **Private Hosted Zones (PHZs)**: Internal domain records.
- **Resolver Forwarding Rules**: Conditional DNS forwarding to on-premises or third-party DNS servers.
- **DNS Firewall Rule Groups**: Threat prevention and policy enforcement.

Profiles are **regional** (active within one AWS Region but can be deployed identically across regions) and **immutable** after creation—you add/remove contained resources, but the profile itself does not change structure.

### Multi-Account Profile Strategy

**Scenario: Cross-Account, Multi-Workload Organization**

Assume an organization with:

- **Central Networking Account** (Hub): Hosts shared-services VPC with Resolver endpoints and centralized Route 53 configuration.
- **Workload Accounts** (Spokes): Multiple business units with development, staging, and production VPCs.
- **DNS Requirements**:
    - Consumer app VPCs (prod \& dev) need access to shared backend services.
    - Data platform VPCs need dedicated DNS firewall rules.
    - Legacy workloads require on-premises connectivity.

**Profile Design:**


| Profile Name | Contents | Scope | Rationale |
| :-- | :-- | :-- | :-- |
| **Consumer-Prod** | PHZ: `api.apps.internal`, `data.apps.internal`; DNS Firewall: general threat rules | Prod consumer VPCs | Ensures consistent DNS for production traffic; enforces org-wide threat policies |
| **Consumer-Dev** | Same PHZs as Consumer-Prod; permissive DNS Firewall rules | Dev consumer VPCs | Reuses production PHZs to avoid configuration drift; relaxes security for development velocity |
| **Data-Platform** | PHZ: `data.internal`, `analytics.internal`; DNS Firewall: data-specific rules (e.g., block external SaaS resolvers) | Data platform VPCs | Isolated configuration prevents data team configuration from affecting other workloads |
| **Legacy-OnPrem** | PHZ: `legacy.internal`; Resolver Forwarding Rule for `corp.example.com` → on-prem DNS | Legacy workload VPCs + hub VPC | Centralizes on-premises connectivity; prevents accidental misconfiguration of forwarding across workloads |

### Implementation Steps

**Step 1: Create Profiles in Central Account**

In the Central Networking Account (e.g., `REDACTED_AWS_ACCOUNT_ID`):

1. Go to **Route 53** → **Profiles** → **Create profile**.
2. Name: `consumer-prod-profile`.
3. Add existing or create new PHZs (e.g., `api.apps.internal`).
4. Add Resolver Forwarding Rules (if on-prem integration is needed).
5. Add DNS Firewall rule groups.
6. Click **Create profile**.

Repeat for additional profiles.

**Step 2: Share Profiles via Resource Access Manager (RAM)**

1. Go to **Resource Access Manager** (separate AWS service).
2. Click **Create resource share**.
3. Select **Route 53 Profiles** as the resource type.
4. Select the profiles you created in Step 1.
5. Choose **Recipients**:
    - **AWS Accounts**: List specific account IDs (e.g., `REDACTED_AWS_ACCOUNT_ID`, `REDACTED_AWS_ACCOUNT_ID`).
    - **Organization**: Share with all accounts in AWS Organization (requires AWS Organizations integration).
6. Click **Create resource share**.

Workload accounts receive a resource share notification. They must **accept** the share before profiles are usable.

**Step 3: Accept Profile Share (Workload Accounts)**

In each spoke/workload account:

1. Go to **Resource Access Manager** → **Shared with me**.
2. Find the Route 53 Profile resource share.
3. Click **Accept resource share**.

The profile is now available in that account's Route 53 console.

**Step 4: Associate Profiles with VPCs**

In each workload account, for each VPC that needs DNS configuration:

1. Go to **Route 53** → **Profiles** → Select the shared profile (e.g., `consumer-prod-profile`).
2. Click **Associate VPCs**.
3. Select VPCs to associate (e.g., all production consumer app VPCs).
4. Click **Associate**.

The profile's contained PHZs, Resolver rules, and DNS Firewall rules are immediately active on the associated VPCs.

### Governance and Operational Benefits

| Benefit | Mechanism | Example |
| :-- | :-- | :-- |
| **Configuration Consistency** | Single profile applied to multiple VPCs eliminates manual rule replication | Create `consumer-prod-profile` once; associate with 50 production VPCs across accounts. Updating the PHZ impacts all 50 VPCs instantly. |
| **Least Privilege** | Read-only access for consumers; central account retains write control | Workload teams can associate/disassociate VPCs but cannot modify underlying DNS rules; prevents accidental configuration drift. |
| **Cross-Account DNS Access** | PHZs in profiles automatically resolve in associated VPCs, even cross-account | Central account creates `api.apps.internal` PHZ in `consumer-prod-profile`; spoke accounts associate their VPCs—no explicit zone association needed. |
| **Centralized On-Prem Integration** | Single Resolver forwarding rule shared across all spoke VPCs | Create rule `corp.example.com` → on-prem DNS in `legacy-onprem-profile`; all legacy VPCs inherit it without individual rule creation. |
| **Dynamic Scaling** | New VPCs are associated with profile via API/CloudFormation; DNS is immediately active | AWS Control Tower provisions a new account with VPC; CloudFormation automatically associates the appropriate Profiles—no manual DNS setup. |

### Caveats and Considerations

- **Regional scope**: Profiles are active only in the region they are created. For multi-region deployments, replicate profiles (with same configuration) in each region.
- **PHZ single-VPC association**: Although a PHZ can be contained in a profile and associated with many VPCs through the profile, the PHZ itself must have a single "primary" VPC association. Cross-account VPC associations are managed separately via the `aws_route53_zone_association` Terraform resource (not through the profile).
- **Read-only consumer default**: Workload accounts cannot modify profiles; all DNS policy changes flow from the central account. If decentralized DNS ownership is desired, this model requires alternative approaches (e.g., account-specific profiles).
- **CloudFormation integration**: Use AWS CloudFormation to automatically associate profiles with newly created VPCs during account provisioning (via AWS Control Tower or similar automation).

***

## 4. Automate Resolver Rules and Private Hosted Zones with Terraform

Infrastructure-as-Code (IaC) ensures repeatable, auditable, and scalable Route 53 Resolver deployments. The official **terraform-aws-modules/route53** provides modular, production-ready submodules for Resolver endpoints, rules, and zones.[^6]

### Terraform Module Architecture

The `terraform-aws-modules/route53` module is organized into submodules:


| Submodule | Purpose | Example |
| :-- | :-- | :-- |
| `zones` | Create and manage Route 53 hosted zones (public and private) | Private hosted zone for `apps.internal` |
| `records` | Manage DNS records within zones (A, AAAA, CNAME, MX, etc.) | A record `web.apps.internal` → ALB IP |
| `resolver-endpoints` | Create inbound and outbound Resolver endpoints | Endpoints for hybrid DNS forwarding |
| `resolver-rules` | Create and associate Resolver forwarding/delegation rules | Rule: forward `corp.example.com` to on-prem DNS |
| `resolver-rule-associations` | Associate Resolver rules with VPCs | Bind rule to workload VPCs |
| `zone-cross-account-vpc-association` | Associate PHZs with VPCs in different AWS accounts | Cross-account DNS resolution |

### Complete Example: Hybrid DNS with Terraform

The following example deploys:

1. A private hosted zone (`aws.internal`).
2. An inbound Resolver endpoint (accepts queries from on-premises).
3. An outbound Resolver endpoint (forwards queries to on-premises).
4. Resolver forwarding rules (conditional forwarding to on-prem DNS).

**File: `main.tf`**

```hcl
# Define variables for flexibility
variable "vpc_id" {
  description = "VPC ID for Resolver endpoints"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Resolver endpoints (at least 2)"
  type        = list(string)
}

variable "on_prem_dns_ips" {
  description = "On-premises DNS server IP addresses"
  type        = list(string)
  default     = ["192.168.1.10", "192.168.1.11"]
}

variable "on_prem_dns_domain" {
  description = "On-premises domain to forward queries for"
  type        = string
  default     = "corp.example.com"
}

# Create security group for inbound endpoint
resource "aws_security_group" "resolver_inbound" {
  name        = "resolver-inbound-sg"
  description = "Security group for Route 53 Resolver inbound endpoint"
  vpc_id      = var.vpc_id

  ingress {
    from_port   = 53
    to_port     = 53
    protocol    = "tcp"
    cidr_blocks = ["192.168.0.0/16"]  # On-premises CIDR
  }

  ingress {
    from_port   = 53
    to_port     = 53
    protocol    = "udp"
    cidr_blocks = ["192.168.0.0/16"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "resolver-inbound-sg"
  }
}

# Create security group for outbound endpoint
resource "aws_security_group" "resolver_outbound" {
  name        = "resolver-outbound-sg"
  description = "Security group for Route 53 Resolver outbound endpoint"
  vpc_id      = var.vpc_id

  egress {
    from_port   = 53
    to_port     = 53
    protocol    = "tcp"
    cidr_blocks = ["192.168.0.0/16"]  # On-premises CIDR
  }

  egress {
    from_port   = 53
    to_port     = 53
    protocol    = "udp"
    cidr_blocks = ["192.168.0.0/16"]
  }

  tags = {
    Name = "resolver-outbound-sg"
  }
}

# Create private hosted zone
resource "aws_route53_zone" "internal" {
  name = "aws.internal"

  vpc {
    vpc_id = var.vpc_id
  }

  tags = {
    Name = "aws-internal-zone"
  }
}

# Create sample A record in the private hosted zone
resource "aws_route53_record" "web_server" {
  zone_id = aws_route53_zone.internal.zone_id
  name    = "web.aws.internal"
  type    = "A"
  ttl     = 300
  records = ["10.0.1.50"]  # Internal ALB or EC2 IP
}

# Create inbound Resolver endpoint
resource "aws_route53_resolver_endpoint" "inbound" {
  name            = "prod-inbound-endpoint"
  direction       = "INBOUND"
  security_group_ids = [aws_security_group.resolver_inbound.id]

  ip_address {
    subnet_id = var.private_subnet_ids[^0]
    ip        = "10.0.1.100"  # Static IP for on-prem DNS configuration
  }

  ip_address {
    subnet_id = var.private_subnet_ids[^1]
    ip        = "10.0.2.100"
  }

  tags = {
    Name = "prod-inbound-endpoint"
  }
}

# Create outbound Resolver endpoint
resource "aws_route53_resolver_endpoint" "outbound" {
  name               = "prod-outbound-endpoint"
  direction          = "OUTBOUND"
  security_group_ids = [aws_security_group.resolver_outbound.id]

  ip_address {
    subnet_id = var.private_subnet_ids[^0]
  }

  ip_address {
    subnet_id = var.private_subnet_ids[^1]
  }

  tags = {
    Name = "prod-outbound-endpoint"
  }
}

# Create Resolver forwarding rule (AWS → On-Prem)
resource "aws_route53_resolver_rule" "forward_to_on_prem" {
  name                 = "forward-corp-domain"
  domain_name          = "${var.on_prem_dns_domain}."
  rule_type            = "FORWARD"
  resolver_endpoint_id = aws_route53_resolver_endpoint.outbound.id

  target_ip {
    ip   = var.on_prem_dns_ips[^0]
    port = 53
  }

  target_ip {
    ip   = var.on_prem_dns_ips[^1]
    port = 53
  }

  tags = {
    Name = "forward-corp-domain"
  }
}

# Associate forwarding rule with workload VPCs
resource "aws_route53_resolver_rule_association" "workload_vpc" {
  name             = "forward-corp-domain-association"
  resolver_rule_id = aws_route53_resolver_rule.forward_to_on_prem.id
  vpc_id           = var.vpc_id
}

# Outputs
output "inbound_endpoint_ips" {
  description = "IP addresses of the inbound Resolver endpoint (for on-prem DNS configuration)"
  value       = aws_route53_resolver_endpoint.inbound.ip_address[*].ip
}

output "outbound_endpoint_id" {
  description = "ID of the outbound Resolver endpoint"
  value       = aws_route53_resolver_endpoint.outbound.id
}

output "private_zone_id" {
  description = "ID of the private hosted zone"
  value       = aws_route53_zone.internal.zone_id
}

output "forwarding_rule_id" {
  description = "ID of the Resolver forwarding rule"
  value       = aws_route53_resolver_rule.forward_to_on_prem.id
}
```

**File: `terraform.tfvars`**

```hcl
vpc_id             = "REDACTED_AWS_RESOURCE_IDg7h8"
private_subnet_ids = ["REDACTED_AWS_RESOURCE_ID", "REDACTED_AWS_RESOURCE_ID"]
on_prem_dns_ips    = ["192.168.1.10", "192.168.1.11"]
on_prem_dns_domain = "corp.example.com"
```


### Cross-Account Resolver Rule Sharing (with RAM)

To share Resolver rules across accounts:

```hcl
# In the central account, create the Resolver rule (as above)

# Share the rule via Resource Access Manager
resource "aws_ram_resource_share" "resolver_rules" {
  name                      = "shared-resolver-rules"
  allow_external_principals = false

  tags = {
    Name = "shared-resolver-rules"
  }
}

resource "aws_ram_resource_association" "resolver_rule" {
  resource_arn       = aws_route53_resolver_rule.forward_to_on_prem.arn
  resource_share_arn = aws_ram_resource_share.resolver_rules.arn
}

resource "aws_ram_principal_association" "spoke_accounts" {
  principal          = "REDACTED_AWS_ACCOUNT_ID"  # Spoke account ID
  resource_share_arn = aws_ram_resource_share.resolver_rules.arn
}

# In the spoke account, accept the share and associate with VPC
resource "aws_route53_resolver_rule_association" "spoke_vpc" {
  provider         = aws.spoke  # Assume role in spoke account
  resolver_rule_id = aws_route53_resolver_rule.forward_to_on_prem.id
  vpc_id           = var.spoke_vpc_id
}
```


### Module Usage (Simplified with terraform-aws-modules)

Alternatively, use the official module directly:

```hcl
module "route53" {
  source  = "terraform-aws-modules/route53/aws"
  version = "~> 3.0"

  zones = {
    "aws.internal" = {
      vpc = [{
        vpc_id = var.vpc_id
      }]
      records = {
        "web.aws.internal" = {
          name    = "web.aws.internal"
          type    = "A"
          ttl     = 300
          records = ["10.0.1.50"]
        }
      }
    }
  }
}

module "resolver_endpoints" {
  source  = "terraform-aws-modules/route53/aws//modules/resolver-endpoints"
  version = "~> 3.0"

  inbound_endpoints = {
    prod = {
      name               = "prod-inbound-endpoint"
      vpc_id             = var.vpc_id
      security_group_ids = [aws_security_group.resolver_inbound.id]
      ip_addresses = {
        subnet_1 = {
          subnet_id = var.private_subnet_ids[^0]
          ip        = "10.0.1.100"
        }
        subnet_2 = {
          subnet_id = var.private_subnet_ids[^1]
          ip        = "10.0.2.100"
        }
      }
    }
  }

  outbound_endpoints = {
    prod = {
      name               = "prod-outbound-endpoint"
      vpc_id             = var.vpc_id
      security_group_ids = [aws_security_group.resolver_outbound.id]
      ip_addresses = {
        subnet_1 = {
          subnet_id = var.private_subnet_ids[^0]
        }
        subnet_2 = {
          subnet_id = var.private_subnet_ids[^1]
        }
      }
    }
  }
}
```


### CI/CD Integration Best Practices

- **State Management**: Use remote Terraform state (S3 + DynamoDB lock) in the central networking account; spoke accounts should assume read-only roles to access shared resources.
- **Plan \& Apply Separation**: Use `terraform plan` in CI to validate changes before `terraform apply` in CD; this prevents accidental DNS misconfigurations.
- **Tagging Strategy**: Tag all resources with environment, owner, cost-center, and automation tags for cost allocation and auditing.
- **Drift Detection**: Run `terraform plan` on a schedule (e.g., weekly) to detect manual AWS console changes; integrate with SNS for alerting.

***

## 5. Design a Hub-and-Spoke DNS Architecture for Hybrid Networks

Hub-and-spoke topology centralizes DNS infrastructure, reducing operational overhead and ensuring consistent policy enforcement across multi-account AWS organizations connected to on-premises networks.

### Reference Architecture

```
                        On-Premises Network
                     (corp.example.com DNS)
                              |
                              |
                      [Site-to-Site VPN]
                      [or Direct Connect]
                              |
                              v
    ┌─────────────────────────────────────────────────────┐
    │    Central Networking Account (Hub)                 │
    │                                                     │
    │  ┌─────────────────────────────────────────────┐   │
    │  │   Shared-Services VPC (10.0.0.0/16)         │   │
    │  │                                              │   │
    │  │  ┌──────────────────────────────────────┐   │   │
    │  │  │ Inbound Resolver Endpoint            │   │   │
    │  │  │ IPs: 10.0.1.100, 10.0.2.100         │   │   │
    │  │  │ (Accepts on-prem queries)            │   │   │
    │  │  └──────────────────────────────────────┘   │   │
    │  │                                              │   │
    │  │  ┌──────────────────────────────────────┐   │   │
    │  │  │ Outbound Resolver Endpoint           │   │   │
    │  │  │ (Forwards to on-prem DNS)            │   │   │
    │  │  └──────────────────────────────────────┘   │   │
    │  │                                              │   │
    │  │  ┌──────────────────────────────────────┐   │   │
    │  │  │ Route 53 Private Hosted Zones:       │   │   │
    │  │  │ • api.internal                        │   │   │
    │  │  │ • db.internal                         │   │   │
    │  │  │ • shared.internal                     │   │   │
    │  │  └──────────────────────────────────────┘   │   │
    │  │                                              │   │
    │  │  ┌──────────────────────────────────────┐   │   │
    │  │  │ Resolver Forwarding Rules:           │   │   │
    │  │  │ • corp.example.com → on-prem DNS    │   │   │
    │  │  └──────────────────────────────────────┘   │   │
    │  └─────────────────────────────────────────────┘   │
    │                           |                         │
    │        [AWS Transit Gateway (Central Hub)]          │
    │                           |                         │
    └─────────────────────────────────────────────────────┘
                                |
                    ┌───────────┼───────────┐
                    |           |           |
                    v           v           v
    ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
    │  Workload Acct  │ │  Workload Acct  │ │  Workload Acct  │
    │  (Spoke)        │ │  (Spoke)        │ │  (Spoke)        │
    │                 │ │                 │ │                 │
    │ [Prod VPCs]     │ │ [Dev VPCs]      │ │ [Data VPCs]     │
    │ 10.1.0.0/16     │ │ 10.2.0.0/16     │ │ 10.3.0.0/16     │
    │                 │ │                 │ │                 │
    │ ┌─────────────┐ │ │ ┌─────────────┐ │ │ ┌─────────────┐ │
    │ │ TGW Attach  │ │ │ │ TGW Attach  │ │ │ │ TGW Attach  │ │
    │ │ (VPC Rte    │ │ │ │ (VPC Rte    │ │ │ │ (VPC Rte    │ │
    │ │  to TGW)    │ │ │ │  to TGW)    │ │ │ │  to TGW)    │ │
    │ └─────────────┘ │ │ └─────────────┘ │ │ └─────────────┘ │
    │                 │ │                 │ │                 │
    │ Resolver Rules  │ │ Resolver Rules  │ │ Resolver Rules  │
    │ (Shared):       │ │ (Shared):       │ │ (Shared):       │
    │ • corp.ex.com   │ │ • corp.ex.com   │ │ • corp.ex.com   │
    │ • api.internal  │ │ • api.internal  │ │ • api.internal  │
    └─────────────────┘ └─────────────────┘ └─────────────────┘
```


### Key Design Principles

| Principle | Implementation | Benefit |
| :-- | :-- | :-- |
| **Centralization** | Inbound/outbound endpoints + PHZs in hub VPC; shared via RAM to spokes | Single point of on-prem integration; reduced endpoint costs; consistent policy enforcement |
| **Segmentation** | Separate Resolver rules for different workload types (prod, dev, data); different DNS Firewall policies per segment | Reduces blast radius of misconfigurations; enables workload-specific threat policies |
| **Redundancy** | Inbound/outbound endpoints in multiple AZs; secondary region with replica configuration | HA if endpoint or AZ fails; disaster recovery capability |
| **Connectivity** | AWS Transit Gateway for VPC-to-VPC and hub attachment; Direct Connect or VPN for on-prem integration | Simplifies routing; avoids full-mesh VPC peering complexity |
| **Scalability** | Route 53 Profiles group rules/zones; shared via RAM to new accounts automatically | Adding new account/VPC requires only profile association, not manual rule replication |

### Step-by-Step Implementation

**Phase 1: Hub VPC Setup (Central Networking Account)**

1. **Create Shared-Services VPC**

```hcl
resource "aws_vpc" "hub" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "hub-shared-services-vpc"
  }
}

# Private subnets for Resolver endpoints (multi-AZ)
resource "aws_subnet" "hub_private_1a" {
  vpc_id            = aws_vpc.hub.id
  cidr_block        = "10.0.1.0/24"
  availability_zone = "us-east-1a"
  tags = { Name = "hub-private-1a" }
}

resource "aws_subnet" "hub_private_1b" {
  vpc_id            = aws_vpc.hub.id
  cidr_block        = "10.0.2.0/24"
  availability_zone = "us-east-1b"
  tags = { Name = "hub-private-1b" }
}
```

2. **Deploy Resolver Endpoints** (as shown in Section 4).
3. **Create Central Private Hosted Zones**

```hcl
resource "aws_route53_zone" "internal" {
  name = "internal"

  vpc {
    vpc_id = aws_vpc.hub.id
  }

  tags = { Name = "internal-phz" }
}

# Records for centralized services
resource "aws_route53_record" "api_server" {
  zone_id = aws_route53_zone.internal.zone_id
  name    = "api.internal"
  type    = "A"
  ttl     = 300
  records = ["10.0.1.50"]  # Shared API service
}
```

4. **Create Transit Gateway**

```hcl
resource "aws_ec2_transit_gateway" "hub_tgw" {
  description                     = "Hub and Spoke Transit Gateway"
  default_route_table_association = "enable"
  default_route_table_propagation = "enable"

  tags = { Name = "hub-tgw" }
}

# Attach hub VPC to TGW
resource "aws_ec2_transit_gateway_vpc_attachment" "hub" {
  transit_gateway_id = aws_ec2_transit_gateway.hub_tgw.id
  vpc_id             = aws_vpc.hub.id
  subnet_ids         = [aws_subnet.hub_private_1a.id, aws_subnet.hub_private_1b.id]

  tags = { Name = "hub-tgw-attachment" }
}
```

5. **Create Resolver Forwarding Rules and Share via RAM**

```hcl
# Forwarding rule for on-prem domain
resource "aws_route53_resolver_rule" "forward_to_on_prem" {
  name                 = "forward-corp-domain"
  domain_name          = "corp.example.com."
  rule_type            = "FORWARD"
  resolver_endpoint_id = aws_route53_resolver_endpoint.outbound.id

  target_ip {
    ip   = "192.168.1.10"
    port = 53
  }

  target_ip {
    ip   = "192.168.1.11"
    port = 53
  }

  tags = { Name = "forward-corp-domain" }
}

# Share rule via RAM
resource "aws_ram_resource_share" "resolver_rules_share" {
  name                      = "shared-resolver-rules"
  allow_external_principals = false

  tags = { Name = "resolver-rules-share" }
}

resource "aws_ram_resource_association" "forward_rule" {
  resource_arn       = aws_route53_resolver_rule.forward_to_on_prem.arn
  resource_share_arn = aws_ram_resource_share.resolver_rules_share.arn
}

# Share with all accounts in AWS Organization
resource "aws_ram_principal_association" "organization" {
  principal          = aws_organizations_organization.org.arn
  resource_share_arn = aws_ram_resource_share.resolver_rules_share.arn
}
```


**Phase 2: Spoke VPC Setup (Workload Accounts)**

1. **Create Spoke VPC**

```hcl
resource "aws_vpc" "spoke" {
  cidr_block           = "10.1.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = { Name = "spoke-prod-vpc" }
}

resource "aws_subnet" "spoke_private" {
  vpc_id     = aws_vpc.spoke.id
  cidr_block = "10.1.1.0/24"
  tags = { Name = "spoke-prod-private" }
}
```

2. **Attach Spoke VPC to Transit Gateway**

```hcl
resource "aws_ec2_transit_gateway_vpc_attachment" "spoke" {
  provider           = aws.workload_account
  transit_gateway_id = data.aws_ec2_transit_gateway.hub_tgw.id
  vpc_id             = aws_vpc.spoke.id
  subnet_ids         = [aws_subnet.spoke_private.id]

  tags = { Name = "spoke-tgw-attachment" }
}
```

3. **Associate Shared Resolver Rules with Spoke VPC**

```hcl
# After accepting the RAM share (manual step or automated via API)
resource "aws_route53_resolver_rule_association" "spoke_rule" {
  provider         = aws.workload_account
  resolver_rule_id = data.aws_route53_resolver_rule.forward_rule.id
  vpc_id           = aws_vpc.spoke.id
}
```

4. **Associate Private Hosted Zones (Cross-Account)**

```hcl
# Hub account: Create zone association for spoke VPC
resource "aws_route53_zone_association" "hub_zone_to_spoke" {
  zone_id = aws_route53_zone.internal.zone_id
  vpc_id  = data.aws_vpc.spoke.id
  # VPC is in a different account; requires authorization
}

# Spoke account: Authorize the zone association
resource "aws_route53_vpc_association_authorization" "spoke_zone_authz" {
  provider = aws.workload_account
  zone_id  = data.aws_route53_zone.internal.zone_id
  vpc_id   = aws_vpc.spoke.id
}
```


**Phase 3: Testing and Validation**

1. **From Spoke EC2 Instance** (verify on-prem connectivity):

```bash
$ nslookup server.corp.example.com
Name: server.corp.example.com
Address: 192.168.100.50
```

2. **From On-Prem Host** (verify Route 53 PHZ access):

```bash
$ nslookup api.internal 10.0.1.100
Name: api.internal
Address: 10.0.1.50
```

3. **Resolver Query Logging** (CloudWatch):
Enable Route 53 Resolver query logging to CloudWatch Logs; query logs show resolution path and latency, useful for troubleshooting.

### Multi-Region Disaster Recovery

For organizations requiring multi-region failover:

1. **Replicate Hub Architecture**
Deploy identical shared-services VPC, Resolver endpoints, and PHZs in a secondary region (e.g., us-west-2).
2. **Cross-Region PHZ Association**
Use Route 53 health checks to detect primary region outage; route to secondary Resolver endpoints on failover.
3. **Transit Gateway Peering**
Peer Transit Gateways in primary and secondary regions for cross-region spoke-to-spoke communication.

### Operational Excellence

- **Monitoring**: Use CloudWatch metrics for Resolver endpoint capacity, query counts, and response times. Set alarms on endpoint health.
- **Logging**: Enable Resolver query logging to CloudWatch Logs; export to S3 for forensic analysis and compliance audits.
- **Documentation**: Maintain a DNS runbook in Confluence/wiki with endpoint IPs, forwarding rules, and on-prem DNS contact information.
- **Automation**: Use AWS Config to detect deviations in Resolver endpoint configuration; trigger remediation via Lambda.

***

## Summary and Takeaways

AWS Route 53 Resolver hybrid DNS is a mature, production-grade service for bridging on-premises and cloud DNS namespaces. Key takeaways for hybrid DNS architecture:

1. **Subdomain Delegation** (new in 2025) eliminates self-managed DNS burden; use inbound delegation endpoints with NS glue records for clean namespace separation.
2. **Endpoint Configuration** requires careful security group, subnet, and IP planning; static IP allocation for inbound endpoints simplifies on-prem DNS configuration.
3. **Route 53 Profiles** centralize multi-account DNS governance, reducing manual rule replication and enabling self-service spoke account onboarding.
4. **Terraform Automation** with `terraform-aws-modules/route53` ensures repeatable, auditable deployments; integrate with CI/CD for drift detection.
5. **Hub-and-Spoke Architecture** with Transit Gateway and centralized endpoints scales to 100+ accounts while maintaining single point of on-prem integration and policy enforcement.

For a telecom/networking engineer with coding interests, this architecture mirrors service provider DNS models—where a central hub (analogous to a regional NOC) distributes DNS policy to distributed edge sites (spoke VPCs). Implementing this in Terraform enables you to build trading infrastructure with hybrid cloud resilience, as well as experiment with LSTM-based anomaly detection on DNS query patterns (Resolver query logs in CloudWatch).
<span style="display:none">[^10][^11][^12][^13][^14][^15][^16][^17][^18][^19][^20][^21][^22][^23][^24][^25][^26][^27][^28][^29][^30][^31][^32][^33][^34][^35][^36][^37][^38][^39][^40][^41][^7][^8][^9]</span>

<div align="center">⁂</div>

[^1]: https://aws.amazon.com/about-aws/whats-new/2025/06/amazon-route-53-resolver-endpoints-dns-delegation-private-hosted-zones/

[^2]: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-forwarding-inbound-queries.html

[^3]: https://aws.amazon.com/blogs/networking-and-content-delivery/streamline-hybrid-dns-management-using-amazon-route-53-resolver-endpoints-delegation/

[^4]: https://aws.amazon.com/blogs/aws/unify-dns-management-using-amazon-route-53-profiles-with-multiple-vpcs-and-aws-accounts/

[^5]: https://community.aws/content/2ZxIbTRrIAuGIwPxv5crGaaQygs/route53-profile?lang=en

[^6]: https://github.com/terraform-aws-modules/terraform-aws-route53

[^7]: https://www.youtube.com/watch?v=jdj-EnTVYMA

[^8]: https://www.reddit.com/r/aws/comments/c6hvem/route_53_private_zone_mirroring_to_internal/

[^9]: https://aws.plainenglish.io/configuring-route53-resolver-inbound-and-outbound-endpoints-cc159c12999?gi=084d989f60a2

[^10]: https://aws.amazon.com/blogs/networking-and-content-delivery/using-amazon-route-53-profiles-for-scalable-multi-account-aws-environments/

[^11]: https://stackoverflow.com/questions/77219845/how-does-one-delegate-a-subdomain-of-a-domain-in-route53-to-a-dns-server-outside

[^12]: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/outpost-resolver-add-outbound-endpoints.html

[^13]: https://intuitive.cloud/index.php/blog/achieving-cross-account-dns-resolution-on-aws-using-route-53

[^14]: https://www.linkedin.com/posts/ninad-sawant-ab3260b_aws-route53-dns-activity-7343842950797221888-o1sj

[^15]: https://www.jeeviacademy.com/beginners-guide-to-creating-inbound-endpoints-in-aws-route-53/

[^16]: https://intuitive.cloud/blog/achieving-cross-account-dns-resolution-on-aws-using-route-53

[^17]: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-routing-traffic-for-subdomains.html

[^18]: https://www.youtube.com/watch?v=1t1xaekzADo

[^19]: https://registry.terraform.io/modules/terraform-aws-modules/route53/aws/latest/examples/complete

[^20]: https://aws.amazon.com/blogs/architecture/using-route-53-private-hosted-zones-for-cross-account-multi-region-architectures/

[^21]: https://www.tecracer.com/blog/2023/08/hybrid-dns-resolution-using-route-53-endpoints.html

[^22]: https://www.rhythmictech.com/blog/route-53-resolvers-revisited/

[^23]: https://aws.amazon.com/blogs/networking-and-content-delivery/centralized-dns-management-of-hybrid-cloud-with-amazon-route-53-and-aws-transit-gateway/

[^24]: https://lgallardo.com/2020/02/29/terraform-module-for-route53-resolver-rules

[^25]: https://www.sls.guru/blog/custom-dns-resolution-across-vpcs-with-route53-private-hosted-zones-step-by-step-tutorial---2

[^26]: https://aws.amazon.com/blogs/networking-and-content-delivery/scaling-your-hybrid-dns-setup-with-amazon-route-53-resolver-endpoint-metrics/

[^27]: https://docs.gruntwork.io/reference/modules/terraform-aws-vpc/vpc-dns-forwarder/

[^28]: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_resolver_endpoint.html

[^29]: https://www.reddit.com/r/aws/comments/1hn8l3q/your_dns_design/

[^30]: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-overview-forward-vpc-to-network-using-rules.html

[^31]: https://www.geeksforgeeks.org/devops/how-to-create-aws-route-53-using-terraform/

[^32]: https://www.youtube.com/watch?v=_Z5jAs2gvPA

[^33]: https://www.reddit.com/r/aws/comments/1lcxy6h/route_53_private_hosted_zones_and_multiaccount/

[^34]: https://www.reddit.com/r/aws/comments/15gpflq/route_53_private_hosted_zones_across_multiple/

[^35]: https://www.javierinthecloud.com/associating-a-route-53-private-hosted-zone-across-accounts/

[^36]: https://github.com/aws-samples/hub-and-spoke-with-shared-services-vpc-terraform

[^37]: https://docs.aws.amazon.com/cli/latest/reference/route53resolver/create-resolver-endpoint.html

[^38]: http://i-cloudconsulting.com/aws-transit-gateway-hub-and-spoke-model/

[^39]: https://docs.aws.amazon.com/Route53/latest/APIReference/API_route53resolver_CreateResolverEndpoint.html

[^40]: https://www.reddit.com/r/aws/comments/115agt8/route_53_across_accounts/

[^41]: https://www.reddit.com/r/Terraform/comments/eceqvc/managing_dns_in_route53/

