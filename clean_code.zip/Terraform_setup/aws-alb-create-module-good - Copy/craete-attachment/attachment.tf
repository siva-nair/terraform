locals {
  target_app_arn = {
    "tg1" = ["10.0.0.1", "10.0.0.2"]
    "tg2" = ["10.0.1.1", "10.0.1.2", "10.0.1.3"]
  }
}

locals {
    target_web_arn = {
    "tg3" = ["11.0.0.1", "11.0.0.2"]
    "tg4" = ["11.0.1.1", "11.0.1.2", "11.0.1.3"]
  }
}

locals {
 association-list-app1 =  flatten([
    for targetgroup, instamsids in local.target_app_arn : [
      for instamsid in instamsids : {
        "${targetgroup}-${instamsid}" = {
          "instamsid" = instamsid
          "targetgroup" = targetgroup
          }
      }
    ]
 ])

  association-list-web1 = flatten([
      for targetgroup, instamsids in local.target_web_arn : [
        for instamsid in instamsids : {
          "${targetgroup}-${instamsid}" = {
            "instamsid" = instamsid
            "targetgroup" = targetgroup
            }
        }
      ]
  ])

 association-map-web1 = { for item in local.association-list-web1: 
     keys(item)[0] => values(item)[0]
   }
 association-map-app1 = { for item in local.association-list-app1: 
     keys(item)[0] => values(item)[0]
   }
  
  }

locals {
  target_groups_web1 = [
    for tg in module.create_alb_output.target_groups_web : {
      target_group  = tg
    }
  ]
    target_groups_app1 = [
    for tg in module.create_alb_output.target_groups_app : {
      target_group  = tg
    }
  ]
}

output "target_groups_app2" {   value = local.target_groups_web1[*]}
output "target_groups_web2" {   value = local.target_groups_app1[*]}

/*
resource "aws_lb_target_group_attachment" "tgr_attachment-web" {
for_each = local.association-map-web1

  target_group_arn = each.value.targetgroup
  target_id        = each.value.instamsid
  #port             = each.value.target_group.target_port
}

resource "aws_lb_target_group_attachment" "tgr_attachment-app" {
for_each = local.association-map-app1

  target_group_arn = each.value.targetgroup
  target_id        = each.value.instamsid
  #port             = each.value.target_group.target_port
}
*/


