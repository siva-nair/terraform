provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}

#module "loadbalance" {source = "./load-balance"}

module "create_alb_output" {
  #source = "../create-network"  
  source = "../create-alb"
}

output "target_groups_app1" {   value = module.create_alb_output.target_groups_app[*]}
output "target_groups_web1" {   value = module.create_alb_output.target_groups_web[*]}

output "aws_lb_app1" {   value = module.create_alb_output.aws_lb_app[*]}
output "aws_lb_web1" {   value = module.create_alb_output.aws_lb_web[*]}

output "vpc_ids1" {   value = module.create_alb_output.vpc_ids}

output "local_target_groups_web1" {   value = module.create_alb_output.local_target_groups_web[*]}
output "local_target_groups_app1" {   value = module.create_alb_output.local_target_groups_web[*]}