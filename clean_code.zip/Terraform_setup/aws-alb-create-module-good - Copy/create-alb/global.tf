#module "global" {    source = "../global"}
