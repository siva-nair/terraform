
locals {
  target_app_arn = {
    "tg1" = ["10.0.0.1", "10.0.0.2"]
    "tg2" = ["10.0.1.1", "10.0.1.2", "10.0.1.3"]
  }
}

locals {
    target_web_arn = {
    "tg3" = ["11.0.0.1", "11.0.0.2"]
    "tg4" = ["11.0.1.1", "11.0.1.2", "11.0.1.3"]
  }
}

locals {
 association-list-app1 =  flatten([
    for targetgroup, instamsids in local.target_web_arn : [
      for instamsid in instamsids : {
        "${targetgroup}-${instamsid}" = {
          "instamsid" = instamsid
          "targetgroup" = targetgroup
          }
      }
    ]
 ])

  association-list-web1 = flatten([
      for targetgroup, instamsids in local.target_web_arn : [
        for instamsid in instamsids : {
          "${targetgroup}-${instamsid}" = {
            "instamsid" = instamsid
            "targetgroup" = targetgroup
            }
        }
      ]
  ])

 association-map-web1 = { for item in local.association-list-web1: 
     keys(item)[0] => values(item)[0]
   }
 association-map-app1 = { for item in local.association-list-app1: 
     keys(item)[0] => values(item)[0]
   }
 
  target_groups_web1 = [
    for name, ips in local.target_web_arn : {
      name = name
      ips  = ips
    }
  ]
    target_groups_app1 = [
    for name, ips in local.target_app_arn : {
      name = name
      ips  = ips
    }
  ] 
  }

locals {
  target_groups_web = [
    for name, ips in local.target_web_arn : {
      name = name
      ips  = ips
    }
  ]
    target_groups_app = [
    for name, ips in local.target_app_arn : {
      name = name
      ips  = ips
    }
  ]
}


resource "aws_lb_target_group" "target_groups_web" {
  for_each    = { for idx, tg in local.target_groups_web : idx => tg }
  name        = each.value.name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = module.global_output.vpc_ids
}

#output "target_groups_web" {   value = values(aws_lb_target_group.target_groups_web)[*].id}

resource "aws_lb_target_group" "target_groups_app" {
  for_each    = { for idx, tg in local.target_groups_app : idx => tg }
  name        = each.value.name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = module.global_output.vpc_ids
}

resource "aws_lb_listener" "alb_listener_web" {
  for_each          = aws_lb_target_group.target_groups_web
  load_balancer_arn = aws_lb.public_alb[each.key].arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "public_alb_listener-${each.key}" })
}

resource "aws_lb_listener" "alb_listener_app" {
  for_each          = aws_lb_target_group.target_groups_app
  load_balancer_arn = aws_lb.private_alb[each.key].arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "private_alb_listener-${each.key}" })
}

###############################################################################
// ALB - "public_alb"
###############################################################################

resource "aws_lb" "public_alb" {
  for_each           = { for idx, tg in local.target_groups_web : idx => tg }
  name               = "alb-web-${each.value.name}" // change name to the public ideawaves-ca
  internal           = true
  load_balancer_type = "application"
  security_groups    = [module.global_output.pubsec_group.id]
  subnets            = [for subnet in module.global_output.pub_subnet : subnet]

  tags = merge(var.project_environment_qa, { Name = "alb-web-${each.value.name}" })

}

resource "aws_lb" "private_alb" {
  for_each           = { for idx, tg in local.target_groups_app : idx => tg }
  name               = "alb-app-${each.value.name}" // change name to the public ideawaves-ca
  internal           = true
  load_balancer_type = "application"
  security_groups    = [module.global_output.prisec_group.id]
  subnets            = [for subnet in module.global_output.pri_subnet : subnet]
  tags               = merge(var.project_environment_qa, { Name = "alb-app-${each.value.name}" })

}



locals {
  target_groups_web-tg = { for idx, tg in aws_lb_target_group.target_groups_web : idx => tg }
  target_groups_app-tg = { for idx, tg in aws_lb_target_group.target_groups_app : idx => tg }

  target_groups_web-tg-1 = [
    for name, ips in local.target_groups_web-tg : {
      name = name
      ips  = ips
    }
  ]
  target_groups_app-tg-1 = [
    for name, ips in local.target_groups_app-tg : {
      name = name
      ips  = ips
    }
  ]
  product_web_tg = setproduct(keys(local.target_groups_web-tg), values(local.target_web_arn))
  product_app_tg = setproduct(keys(local.target_groups_app-tg), values(local.target_app_arn))
}


/**

resource "aws_lb_target_group_attachment" "web" {
  count = length(local.product_web_tg)

  target_group_arn = aws_lb_target_group.target_groups_web[local.product_web_tg[count.index][0]].arn
  #port             = aws_lb_target_group.main[local.roduct_app_tg[count.index][0]].port
  port = "80"
  target_id        = "${local.product_web_tg[count.index][1]}"
}

resource "aws_lb_target_group_attachment" "app" {
  count = length(local.product_app_tg)

  target_group_arn = aws_lb_target_group.target_groups_app[local.product_app_tg[count.index][0]].arn
  port = "80"
  #port             = aws_lb_target_group.main[local.roduct_app_tg[count.index][0]].port
  target_id        = "${local.product_app_tg[count.index][1]}"
}
**/

output "local_product_web_tg"{value = local.product_web_tg}
output "local_product_app_tg" {value = local.product_app_tg}
output "local_target_groups_web" {value = local.target_groups_web}
output "local_target_groups_app" {value = local.target_groups_app}

/*
resource "aws_lb_target_group_attachment" "tgr_attachment-web" {
for_each = local.association-map-web1

  target_group_arn = each.value.targetgroup
  target_id        = each.value.instamsid
  #port             = each.value.target_group.target_port
}

resource "aws_lb_target_group_attachment" "tgr_attachment-app" {
for_each = local.association-map-app1

  target_group_arn = each.value.targetgroup
  target_id        = each.value.instamsid
  #port             = each.value.target_group.target_port
}
*/
