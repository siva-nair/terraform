// https://jhooq.com/terraform-guide-alb-ssl/

provider "aws" {
  region     = "us-east-1"
  access_key = "REDACTED_SECRET"
  secret_key = "REDACTED_SECRET"
}

module "loadbalance" {
source = "./create-alb"
}
