
output "pub_subnet" {   value = values(aws_subnet.public_subnet)[*].id}

output "vpc_ids" {   value = aws_vpc.staging-vpc.id}

output "gateway_ids" {   value =aws_internet_gateway.qa-igw.id}

output "pri_subnet" { value = values(aws_subnet.private_subnet)[*].id}

output "pubsec_group" { value = aws_security_group.public-allow_alb_traffic}

output "prisec_group" { value = aws_security_group.private-allow_alb_traffic}


output "pub_instance" { value = values(aws_instance.public_ec)[*].private_ip}

output "pri_instance" { value = values(aws_instance.private_ec)[*].private_ip}

