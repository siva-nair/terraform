variable "vpc_ids" {
  description = "assign vpc"
  type        = string
  default     = "REDACTED_AWS_RESOURCE_ID"
}

variable "zone_id" {
  description = "assign zone_id"
  type        = string
  default     = "Z01292673BAW0ATHXBGRU"
}
variable "with_acm_certificates" {
  description = "VPC Network Map"
  type = map(object({
    domain_name    = string
    acm_validation_method = string
    alb_name = string
    target = list(string)    
  }))
  default = {
    "0" = {
      domain_name    = "previewc.ideawaves.ca"
      acm_validation_method = "DNS"
      alb_name = "alb-previewc"
      target = ["10.5.5.8", "10.5.6.107"]
    },
    "1" = {
      domain_name    = "previewm.ideawaves.ca"
      acm_validation_method = "DNS"
      alb_name = "alb-previewm"
      target = ["10.5.5.12", "10.5.6.117"]
    }
  }
}
variable "without_acm_certificates" {
  description = "VPC Network Map"
  type = map(object({
    domain_name    = string
    acm_validation_method = string
    alb_name = string
    target = list(string)    
  }))
  default = {
    "0" = {
      domain_name    = "previewc.ideawaves.ca"
      acm_validation_method = "DNS"
      alb_name = "alb-previewc-qa"
      target = ["10.5.1.232", "10.5.2.220"]
    },
    "1" = {
      domain_name    = "previewm.ideawaves.ca"
      acm_validation_method = "DNS"
      alb_name = "alb-previewm-qa"
      target = ["10.5.1.224", "10.5.2.178"] 
    }
  }
}

locals {
  with_acm_certificates = {
    "alb-previewc-dev"                = {
      domain_name                       = "previewc.ideawaves.ca"
      acm_validation_method             = "DNS"
      alb_name = "alb-previewc"
      target      = ["10.5.5.141", "10.5.6.208"] 
      subject_alternative_names         = []
      tags = {}
    },
    "alb-previewm-dev"                = {
      domain_name                       = "previewm.ideawaves.ca"
      acm_validation_method             = "DNS"
      alb_name = "alb-previewm"
      target = ["10.5.5.12", "10.5.6.117"] 

      subject_alternative_names         = []
      tags = {}
    }
   }
  }

  locals {
  without_acm_certificates = {
    "alb-previewc-qa"                = {
      target      = ["10.5.1.222", "10.5.2.78"]
      alb_name = "alb-previewc-qa" 
      subject_alternative_names         = []
      tags = {}
    },
    "alb-previewm-qa"                = {
      target = ["10.5.1.224", "10.5.2.178"] 
      alb_name = "alb-previewm-qa"
      subject_alternative_names         = []
      tags = {}
    }
   }
  }

resource "aws_lb_target_group" "target_groups_external" {
  for_each = local.with_acm_certificates
  name     = each.value.alb_name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_ids
  tags = merge(var.project_environment_qa, { Name = "tg_${each.value.alb_name}" })
}

resource "aws_lb_target_group" "target_groups_internal" {
      for_each = local.without_acm_certificates
  name     = each.value.alb_name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_ids
tags = merge(var.project_environment_qa, { Name = "tg_${each.value.alb_name}" })
}

# 3. Add the ALB Target Group attachment


#################################################################################
// 2 .Listener private_alb_listener port 80
#################################################################################
resource "aws_lb_listener" "int_alb_listener_80" {
for_each    = { for idx, tg in aws_lb_target_group.target_groups_internal : idx => tg }  
  load_balancer_arn = aws_lb.internal_alb[each.key].arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "int_alb_listener_${each.key}_80" })
}



#################################################################################
// 2 .Listener public_alb_listener port 80
#################################################################################
resource "aws_lb_listener" "ext_alb_listener_80" {
  #for_each = { for listener in aws_lb_target_group.tg_external_alb[*] : listener => listener }
for_each    = { for idx, tg in aws_lb_target_group.target_groups_external : idx => tg }  
  load_balancer_arn = aws_lb.external_alb[each.key].arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "ext_alb_listener_${each.key}_80" })
}
  

#################################################################################
// certificate_config.tf
#################################################################################

# Request and validate an SSL certificate from AWS Certificate Manager (ACM)

resource "aws_acm_certificate" "certificate_config" { 
  #for_each = toset(var.cert_to_use)
  for_each = local.with_acm_certificates
  domain_name       =  each.value.domain_name
  validation_method = "DNS"
  tags = merge(var.project_environment_qa, { Name = "SSL_cert-${each.value.domain_name}" })
}


# Associate the SSL certificate with the ALB listener
resource "aws_lb_listener_certificate" "listener_certificate" {
  for_each = { for k, v in aws_acm_certificate.certificate_config : k => v}  
  listener_arn    = aws_lb_listener.ext_alb_listener_443[each.key].arn
  certificate_arn = each.value.arn
}
###########################################################################################
variable "aws_lb_target_group" {
  description = "aws_lb_target_group"
  type        = map(any)
  default = {
    http = {
      name                 = "http"
      target_type          = "ip"
      port                 = 80
      protocol             = "TCP"
      protocol_version     = "HTTP1"
      type                 = "source_ip"
      enabled              = false
      path_health_check    = "/health.html"
      matcher_health_check = "200" # has to be HTTP 200 or fails
    },
    https = {
      name                 = "https"
      target_type          = "ip"
      port                 = 443
      protocol             = "TCP"
      protocol_version     = "HTTP2"
      type                 = "source_ip"
      enabled              = false
      path_health_check    = "/health.html"
      matcher_health_check = "200" # has to be HTTP 200 or fails
    }
  }
}

variable "http_tcp_listeners" {
  description = "aws_lb_listener"
  type        = map(any)
  default = {
    http = {
      port        = "80"
      protocol    = "TCP"
      action_type = "forward"
      alpn_policy = "HTTP1Only"
    },
    https = {
      port        = "443"
      protocol    = "TCP"
      action_type = "forward"
      certificate_arn = "data.terraform_remote_state.acm.outputs.acm_certificate_arn"
      alpn_policy     = "HTTP2Preferred"
    }
  }
}

resource "aws_lb_target_group" "target_groups_external" {
  for_each         = var.aws_lb_target_group
  name             = "test-group-${each.value.name}"
  target_type      = each.value.target_type
  port             = each.value.port
  protocol         = each.value.protocol
  protocol_version = each.value.protocol_version
  vpc_id           = local.vpc_id

  stickiness {
    type    = "source_ip"
    enabled = false
  }

  health_check {
    path                = each.value.path_health_check
    port                = each.value.port
    healthy_threshold   = 3
    unhealthy_threshold = 3
    interval            = 30
  }

  depends_on = [
    aws_lb.main,
  ]
}


resource "aws_lb_target_group" "target_groups_external" {
  for_each = local.with_acm_certificates
  name     = each.value.alb_name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_ids
  tags = merge(var.project_environment_qa, { Name = "tg_${each.value.alb_name}" })
}

resource "aws_lb_target_group" "target_groups_internal" {
      for_each = local.without_acm_certificates
  name     = each.value.alb_name
  port        = 80
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_ids
tags = merge(var.project_environment_qa, { Name = "tg_${each.value.alb_name}" })
}


resource "aws_lb_listener" "frontend_http_tcp" {
  for_each          = var.http_tcp_listeners
  load_balancer_arn = aws_lb.main.arn
  port              = each.value.port
  protocol          = each.value.protocol
  certificate_arn   = data.terraform_remote_state.acm.outputs.acm_certificate_arn
  alpn_policy       = each.value.alpn_policy

  dynamic "default_action" {
    for_each = aws_lb_target_group.main

    content {
      type             = "forward"
      target_group_arn = each.value.arn
    }
  }

  depends_on = [
    aws_lb.main,
    aws_lb_target_group.main,
  ]
}
###########################################################################################
###########################################################################################
locals {
  target_groups = ["1", "2", "3"]
}


resource "aws_lb_listener" "https_to_target_group" {
  count = length(local.with_acm_certificates)

  certificate_arn   = aws_acm_certificate.cd.arn
  load_balancer_arn = aws_lb.cd.arn

  port              = var.alb.port
  protocol          = var.alb.protocol
  ssl_policy        = var.alb.ssl_policy

  default_action {

    type             = "forward"
    forward {
      dynamic "target_group" {
        for_each = local.target_groups
        content {
          arn = aws_lb_target_group.cd[target_group.key].arn
        }
      }
    }
  }

###########################################################################################


#################################################################################
// ext_alb_listener
#################################################################################
resource "aws_lb_listener" "ext_alb_listener_443" {
for_each    = { for idx, tg in aws_lb_target_group.target_groups_external : idx => tg }  
  load_balancer_arn = aws_lb.external_alb[each.key].arn
  port              = "443"
  protocol          = "HTTPS"
  certificate_arn   = aws_acm_certificate.certificate_config[each.key].arn

  default_action {
    type             = "forward"
    target_group_arn = each.value.arn
  }
  tags = merge(var.project_environment_qa, { Name = "alb_listner-${each.key}_443" })
}



###############################################################################
// ALB - "external_alb"
###############################################################################

resource "aws_lb" "external_alb" { 
  #for_each = { for k,v in local.ext_data[*] : k => v.subnet }  
  //add line :<need to hard code if the subnets are the same
  for_each = local.with_acm_certificates
  name               = "public-${each.value.alb_name}" // change name to the public ideawaves-ca
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.public-allow_alb_traffic.id]
  subnets            = ["REDACTED_AWS_RESOURCE_ID", "REDACTED_AWS_RESOURCE_ID"]
  #subnets            =  [for subnet in var.subnet_cidrs_public : subnet.id]

tags = merge(var.project_environment_qa, { Name = "${each.value.alb_name}" })

}

###############################################################################
// ALB - "internal_alb"
###############################################################################
resource "aws_lb" "internal_alb" {
for_each = local.without_acm_certificates
  #for_each = { for k, v in local.int_data[*] : k => v.subnet }  
  name               = "private-${each.value.alb_name}" // change name to the internal Application Targets
  internal           = true
  load_balancer_type = "application"
  security_groups    = [aws_security_group.private-allow_alb_traffic.id]
  subnets            = ["REDACTED_AWS_RESOURCE_ID","REDACTED_AWS_RESOURCE_ID"]
  #subnets            = [for subnet in var.subnet_cidrs_private : subnet.id]
tags = merge(var.project_environment_qa, { Name = "${each.value.alb_name}" })
}

