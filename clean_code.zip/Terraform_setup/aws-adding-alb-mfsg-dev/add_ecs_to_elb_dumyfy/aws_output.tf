
# Output block to display the value of the "resource_info_value" variable



output "external_alb" {
  #value = aws_lb_target_group.tg_external_alb
  #value = { for k, v in aws_lb_target_group.tg_external_alb[*]: k => v }
  value = values(aws_lb.external_alb)[*].arn
}

output "internal_alb" {
  #value = aws_lb_target_group.tg_external_alb
  value = values(aws_lb.internal_alb)[*].arn
}


#output "tga-internal-private-ip" {  value = values(aws_lb_target_group_attachment.tga-internal-private-ip)[*].id}

#output "tga-external-private-ip" { value = values(aws_lb_target_group_attachment.tga-external-private-ip)[*].id}





#output "certificate_config" {value = values(aws_acm_certificate.certificate_config)[*].arn}

#output "listener_certificate" {  value = aws_lb_listener_certificate.listener_certificate}