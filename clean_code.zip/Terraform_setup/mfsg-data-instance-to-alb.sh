import pandas as pd
import os

def replace_words_from_excel(excel_file, paragraph_text, output_dir="output_files"):
    """
    Replaces words in a paragraph based on an Excel file and creates new files.

    Args:
        excel_file (str): Path to the Excel file.
        paragraph_text (str): The text where replacements will be made.
        output_dir (str, optional): Directory to save new files. Defaults to "output_files".
    """
    try:
        df = pd.read_excel(excel_file)
    except FileNotFoundError:
        print(f"Error: Excel file '{excel_file}' not found.")
        return
    except Exception as e:
         print(f"An error occurred while reading the Excel file: {e}")
         return

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    for index, row in df.iterrows():
        new_text = paragraph_text
        filename = f"output_{index + 1}.txt"

        for col in df.columns:
          if col != "filename":
            new_text = new_text.replace(str(col), str(row[col]))

        filepath = os.path.join(output_dir, filename)
        try:
          with open(filepath, "w") as file:
            file.write(new_text)
          print(f"File '{filename}' created successfully in '{output_dir}'.")
        except Exception as e:
          print(f"An error occurred while writing to file '{filepath}': {e}")


# Example usage:
excel_file_path = "replace_words.xlsx"
paragraph = "This is a sample paragraph. Word1 needs to be replaced, and so does Word2."

# Create a sample Excel file (replace with your actual file)
data = {'Word1': ['Replacement1A', 'Replacement1B'],
        'Word2': ['Replacement2A', 'Replacement2B']}
df = pd.DataFrame(data)
df.to_excel(excel_file_path, index=False)

replace_words_from_excel(excel_file_path, paragraph)